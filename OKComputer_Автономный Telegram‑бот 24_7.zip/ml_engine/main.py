"""
ML Engine Main Module
Главный модуль машинного обучения для анализа и оптимизации
"""

import asyncio
import signal
import sys
from typing import Dict, List, Any, Optional
import logging
from pathlib import Path
from datetime import datetime, timedelta

from config import config
from analyzer import MLAnalyzer
from optimizer import MLOptimizer
from predictor import MLPredictor

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOGS_DIR / 'ml_engine.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class MLEngineService:
    """Сервис машинного обучения"""
    
    def __init__(self):
        self.is_running = False
        self.analyzer = MLAnalyzer()
        self.optimizer = MLOptimizer()
        self.predictor = MLPredictor()
        
        # Модели ML
        self.models: Dict[str, Any] = {}
        self.model_performance: Dict[str, float] = {}
        
        # Данные для обучения
        self.training_data: List[Dict[str, Any]] = []
        self.data_buffer: List[Dict[str, Any]] = []
        
        # Настройки
        self.training_interval = 3600  # 1 час
        self.prediction_interval = 300  # 5 минут
        self.min_training_samples = 100
        self.model_update_threshold = 0.1  # 10% улучшение для обновления
        
        # Статистика
        self.stats = {
            'models_trained': 0,
            'predictions_made': 0,
            'accuracy_improvements': 0,
            'data_points_processed': 0,
            'training_time_avg': 0.0
        }
        
        # Флаги управления
        self._shutdown_event = asyncio.Event()
        
        logger.info("ML Engine Service инициализирован")
    
    async def start(self):
        """Запуск сервиса машинного обучения"""
        try:
            logger.info("Запуск ML Engine Service...")
            
            # Инициализация компонентов
            await self.analyzer.initialize()
            await self.optimizer.initialize()
            await self.predictor.initialize()
            
            # Загрузка существующих моделей
            await self._load_models()
            
            # Обновление статуса
            self.is_running = True
            
            # Запуск рабочих циклов
            asyncio.create_task(self._training_loop())
            asyncio.create_task(self._prediction_loop())
            asyncio.create_task(self._optimization_loop())
            
            logger.info("ML Engine Service успешно запущен")
            
            # Ожидание завершения
            await self._shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"Ошибка при запуске ML Engine Service: {e}")
            raise
    
    async def stop(self):
        """Остановка сервиса машинного обучения"""
        logger.info("Остановка ML Engine Service...")
        self.is_running = False
        self._shutdown_event.set()
        
        # Сохранение моделей
        await self._save_models()
        
        # Очистка ресурсов
        await self.analyzer.cleanup()
        await self.optimizer.cleanup()
        
        logger.info("ML Engine Service остановлен")
    
    async def add_training_data(self, data_point: Dict[str, Any]):
        """Добавление данных для обучения"""
        self.data_buffer.append(data_point)
        
        # Автоматическая обработка при накоплении данных
        if len(self.data_buffer) >= 100:
            await self._process_data_buffer()
        
        logger.debug(f"Добавлена точка данных для обучения. Буфер: {len(self.data_buffer)}")
    
    async def make_prediction(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Получение предсказания от ML модели"""
        try:
            # Определение типа предсказания
            prediction_type = input_data.get('type', 'engagement')
            
            # Выбор подходящей модели
            model = self.models.get(prediction_type)
            if not model:
                # Использование базового предсказателя
                prediction = await self.predictor.basic_predict(input_data)
            else:
                # Использование обученной модели
                prediction = await self.predictor.predict_with_model(model, input_data)
            
            # Обновление статистики
            self.stats['predictions_made'] += 1
            
            return prediction
            
        except Exception as e:
            logger.error(f"Ошибка при получении предсказания: {e}")
            # Возврат безопасного предсказания
            return {
                'prediction': 0.5,
                'confidence': 0.3,
                'model_used': 'fallback',
                'error': str(e)
            }
    
    async def get_model_performance(self, model_type: str) -> Dict[str, Any]:
        """Получение производительности модели"""
        if model_type in self.model_performance:
            return {
                'model_type': model_type,
                'accuracy': self.model_performance[model_type],
                'last_updated': datetime.now().isoformat(),
                'status': 'active'
            }
        else:
            return {
                'model_type': model_type,
                'accuracy': 0.0,
                'status': 'not_trained'
            }
    
    async def get_service_status(self) -> Dict[str, Any]:
        """Получение статуса сервиса ML"""
        return {
            'is_running': self.is_running,
            'models_loaded': len(self.models),
            'training_data_size': len(self.training_data),
            'data_buffer_size': len(self.data_buffer),
            'stats': self.stats,
            'analyzer_status': await self.analyzer.get_status(),
            'optimizer_status': await self.optimizer.get_status(),
            'predictor_status': await self.predictor.get_status()
        }
    
    async def _training_loop(self):
        """Цикл обучения моделей"""
        while self.is_running:
            try:
                # Ожидание интервала обучения
                await asyncio.sleep(self.training_interval)
                
                # Проверка наличия достаточных данных
                if len(self.training_data) >= self.min_training_samples:
                    await self._train_models()
                else:
                    logger.info(f"Недостаточно данных для обучения: {len(self.training_data)}/{self.min_training_samples}")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле обучения: {e}")
                await asyncio.sleep(60)
    
    async def _prediction_loop(self):
        """Цикл предсказаний"""
        while self.is_running:
            try:
                # Ожидание интервала предсказаний
                await asyncio.sleep(self.prediction_interval)
                
                # Выполнение регулярных предсказаний
                await self._perform_regular_predictions()
                
            except Exception as e:
                logger.error(f"Ошибка в цикле предсказаний: {e}")
                await asyncio.sleep(30)
    
    async def _optimization_loop(self):
        """Цикл оптимизации моделей"""
        while self.is_running:
            try:
                # Оптимизация каждые 6 часов
                await asyncio.sleep(21600)
                
                # Оптимизация гиперпараметров
                await self._optimize_models()
                
                # Очистка устаревших данных
                await self._cleanup_old_data()
                
            except Exception as e:
                logger.error(f"Ошибка в цикле оптимизации: {e}")
                await asyncio.sleep(300)
    
    async def _train_models(self):
        """Обучение ML моделей"""
        start_time = asyncio.get_event_loop().time()
        
        try:
            logger.info(f"Начало обучения моделей. Данных: {len(self.training_data)}")
            
            # Подготовка данных
            training_features, training_labels = await self.analyzer.prepare_training_data(
                self.training_data
            )
            
            # Обучение различных моделей
            models_to_train = ['engagement', 'timing', 'sentiment', 'trend']
            
            for model_type in models_to_train:
                try:
                    # Обучение модели
                    new_model = await self.analyzer.train_model(
                        model_type,
                        training_features,
                        training_labels
                    )
                    
                    # Оценка производительности
                    performance = await self.analyzer.evaluate_model(
                        new_model,
                        training_features,
                        training_labels
                    )
                    
                    # Сравнение с существующей моделью
                    current_performance = self.model_performance.get(model_type, 0.0)
                    
                    if (performance - current_performance) > self.model_update_threshold:
                        # Обновление модели
                        self.models[model_type] = new_model
                        self.model_performance[model_type] = performance
                        
                        self.stats['accuracy_improvements'] += 1
                        logger.info(f"Модель {model_type} обновлена. Новая точность: {performance:.3f}")
                    else:
                        logger.info(f"Модель {model_type} не требует обновления. Текущая точность: {current_performance:.3f}")
                    
                except Exception as e:
                    logger.error(f"Ошибка при обучении модели {model_type}: {e}")
                    continue
            
            # Обновление статистики
            self.stats['models_trained'] += len(models_to_train)
            training_time = asyncio.get_event_loop().time() - start_time
            self.stats['training_time_avg'] = (
                (self.stats['training_time_avg'] * (self.stats['models_trained'] - len(models_to_train)) + training_time) /
                self.stats['models_trained']
            )
            
            logger.info(f"Обучение моделей завершено за {training_time:.2f} секунд")
            
        except Exception as e:
            logger.error(f"Ошибка при обучении моделей: {e}")
    
    async def _perform_regular_predictions(self):
        """Выполнение регулярных предсказаний"""
        try:
            # Предсказание оптимального времени публикации
            timing_prediction = await self.make_prediction({
                'type': 'timing',
                'current_hour': datetime.now().hour,
                'day_of_week': datetime.now().weekday(),
                'content_type': 'mixed'
            })
            
            # Предсказание вовлеченности
            engagement_prediction = await self.make_prediction({
                'type': 'engagement',
                'content_length': 1000,
                'has_media': True,
                'topic': 'technology'
            })
            
            # Предсказание трендов
            trend_prediction = await self.make_prediction({
                'type': 'trend',
                'keywords': ['AI', 'machine learning', 'technology'],
                'time_window': '24h'
            })
            
            # Сохранение предсказаний для анализа
            await self._save_predictions({
                'timing': timing_prediction,
                'engagement': engagement_prediction,
                'trend': trend_prediction
            })
            
        except Exception as e:
            logger.error(f"Ошибка при выполнении предсказаний: {e}")
    
    async def _optimize_models(self):
        """Оптимизация гиперпараметров моделей"""
        try:
            logger.info("Оптимизация гиперпараметров моделей...")
            
            for model_type, model in self.models.items():
                try:
                    # Оптимизация модели
                    optimized_model = await self.optimizer.optimize_model(
                        model,
                        model_type,
                        self.training_data
                    )
                    
                    # Обновление модели если оптимизация успешна
                    if optimized_model:
                        self.models[model_type] = optimized_model
                        logger.info(f"Модель {model_type} оптимизирована")
                    
                except Exception as e:
                    logger.error(f"Ошибка оптимизации модели {model_type}: {e}")
                    continue
            
            logger.info("Оптимизация моделей завершена")
            
        except Exception as e:
            logger.error(f"Ошибка при оптимизации моделей: {e}")
    
    async def _process_data_buffer(self):
        """Обработка буфера данных для обучения"""
        if not self.data_buffer:
            return
        
        try:
            # Обработка и валидация данных
            processed_data = await self.analyzer.process_data_batch(self.data_buffer)
            
            # Добавление в обучающую выборку
            self.training_data.extend(processed_data)
            
            # Ограничение размера обучающей выборки
            max_samples = 10000
            if len(self.training_data) > max_samples:
                self.training_data = self.training_data[-max_samples:]
            
            # Очистка буфера
            self.data_buffer.clear()
            
            self.stats['data_points_processed'] += len(processed_data)
            
            logger.info(f"Обработано {len(processed_data)} точек данных")
            
        except Exception as e:
            logger.error(f"Ошибка при обработке буфера данных: {e}")
    
    async def _cleanup_old_data(self):
        """Очистка устаревших данных"""
        cutoff_date = datetime.now() - timedelta(days=90)
        
        # Очистка старых данных для обучения
        self.training_data = [
            data for data in self.training_data
            if data.get('timestamp', datetime.now()) > cutoff_date
        ]
        
        # Очистка истории предсказаний
        self.predictor.cleanup_old_predictions(cutoff_date)
        
        logger.info(f"Очищены устаревшие данные. Осталось {len(self.training_data)} точек")
    
    async def _save_predictions(self, predictions: Dict[str, Any]):
        """Сохранение предсказаний для анализа"""
        # В реальном приложении - сохранение в базу данных
        logger.debug(f"Сохранены предсказания: {list(predictions.keys())}")
    
    async def _load_models(self):
        """Загрузка существующих моделей"""
        # В реальном приложении - загрузка из файлов или базы данных
        logger.info("Загрузка ML моделей...")
        
        # Инициализация базовых моделей
        self.model_performance = {
            'engagement': 0.65,
            'timing': 0.70,
            'sentiment': 0.80,
            'trend': 0.60
        }
        
        logger.info(f"Загружено {len(self.model_performance)} моделей")
    
    async def _save_models(self):
        """Сохранение обученных моделей"""
        # В реальном приложении - сохранение в файлы или базу данных
        logger.info(f"Сохранение {len(self.models)} обученных моделей...")
        
        # Сохранение метрик производительности
        for model_type, performance in self.model_performance.items():
            logger.info(f"Модель {model_type}: точность {performance:.3f}")

# Обработка сигналов
def signal_handler(signum, frame):
    """Обработчик системных сигналов"""
    logger.info(f"Получен сигнал {signum}")
    
    if signum == signal.SIGTERM:
        asyncio.create_task(ml_service.stop())
    elif signum == signal.SIGINT:
        asyncio.create_task(ml_service.stop())

# Глобальный экземпляр
ml_service = MLEngineService()

async def main():
    """Главная функция"""
    # Установка обработчиков сигналов
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        await ml_service.start()
    except KeyboardInterrupt:
        logger.info("Получено прерывание от пользователя")
        await ml_service.stop()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        await ml_service.stop()

if __name__ == "__main__":
    asyncio.run(main())