"""
Universal Parser Module
Универсальный парсер для всех типов источников контента
"""

import asyncio
import aiohttp
import requests
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from newspaper import Article
import feedparser
import json
import re
from typing import Dict, List, Any, Optional, Union
from dataclasses import dataclass
from datetime import datetime
from urllib.parse import urljoin, urlparse
import logging
import time

logger = logging.getLogger(__name__)

@dataclass
class ParsedContent:
    """Структура спарсенного контента"""
    url: str
    title: str
    content: str
    author: Optional[str] = None
    publish_date: Optional[datetime] = None
    tags: List[str] = None
    images: List[str] = None
    videos: List[str] = None
    metadata: Dict[str, Any] = None
    source_type: str = 'unknown'
    parsing_time: float = 0.0

class SourceTypeDetector:
    """Детектор типов источников"""
    
    def __init__(self):
        self.patterns = {
            'news_site': [
                r'news', r'новост', r'article', r'post', r'journal',
                r'media', r'press', r'report', r'новинки'
            ],
            'blog': [
                r'blog', r'post', r'article', r'запис', r'блог',
                r'diary', r'journal', r'笔记', r'日记'
            ],
            'forum': [
                r'forum', r'форум', r'thread', r'topic', r'discussion',
                r'board', r'community', r'сообществ'
            ],
            'social_media': [
                r'twitter', r'facebook', r'instagram', r'vk', r'telegram',
                r'linkedin', r'reddit', r'youtube', r'tiktok'
            ],
            'ecommerce': [
                r'shop', r'store', r'product', r'товар', r'магазин',
                r'cart', r'price', r'купить', r'продаж', r'commerce'
            ],
            'wiki': [
                r'wiki', r'вики', r'encyclopedia', r'справочник',
                r'reference', r'knowledge'
            ]
        }
    
    def detect_from_url(self, url: str) -> str:
        """Определение типа источника по URL"""
        url_lower = url.lower()
        
        for source_type, patterns in self.patterns.items():
            for pattern in patterns:
                if re.search(pattern, url_lower):
                    return source_type
        
        return 'unknown'
    
    def detect_from_content(self, soup: BeautifulSoup) -> str:
        """Определение типа источника по содержимому страницы"""
        # Проверка мета-тегов
        meta_tags = soup.find_all('meta')
        for tag in meta_tags:
            if tag.get('property') in ['og:type', 'article:type']:
                content = tag.get('content', '').lower()
                if 'article' in content:
                    return 'news_site'
                elif 'website' in content:
                    return 'blog'
        
        # Проверка структуры страницы
        if soup.find('article') or soup.find('div', class_=re.compile(r'article|post|news')):
            return 'news_site'
        
        if soup.find('div', class_=re.compile(r'forum|thread|topic|comment')):
            return 'forum'
        
        if soup.find('div', class_=re.compile(r'product|item|shop|store')):
            return 'ecommerce'
        
        return 'unknown'

class UniversalParser:
    """Универсальный парсер контента"""
    
    def __init__(self):
        self.detector = SourceTypeDetector()
        self.session: Optional[aiohttp.ClientSession] = None
        self.selenium_driver: Optional[webdriver.Chrome] = None
        
        # Настройки
        self.request_timeout = 30
        self.max_retries = 3
        self.retry_delay = 1
        self.user_agent_rotation = True
        
        # Кэш
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._cache_ttl = 3600  # 1 час
        
        logger.info("Universal Parser инициализирован")
    
    async def initialize(self):
        """Инициализация парсера"""
        # Создание aiohttp сессии
        connector = aiohttp.TCPConnector(
            limit=100,
            limit_per_host=10,
            ttl_dns_cache=300
        )
        
        timeout = aiohttp.ClientTimeout(total=self.request_timeout)
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout
        )
        
        logger.info("Universal Parser инициализирован")
    
    async def cleanup(self):
        """Очистка ресурсов"""
        if self.session:
            await self.session.close()
        
        if self.selenium_driver:
            self.selenium_driver.quit()
        
        logger.info("Universal Parser очищен")
    
    async def cleanup_cache(self):
        """Очистка кэша"""
        current_time = time.time()
        expired_keys = [
            key for key, data in self._cache.items()
            if current_time - data.get('timestamp', 0) > self._cache_ttl
        ]
        
        for key in expired_keys:
            del self._cache[key]
        
        logger.info(f"Кэш парсера очищен. Удалено {len(expired_keys)} записей")
    
    async def parse(
        self,
        url: str,
        source_type: str = 'auto',
        proxy: Optional[str] = None,
        headers: Optional[Dict[str, str]] = None,
        selectors: Optional[Dict[str, str]] = None,
        use_selenium: bool = False
    ) -> Dict[str, Any]:
        """
        Универсальный метод парсинга
        
        Args:
            url: URL для парсинга
            source_type: Тип источника ('auto', 'news_site', 'blog', 'forum', etc.)
            proxy: Прокси сервер
            headers: HTTP заголовки
            selectors: CSS/XPath селекторы для извлечения
            use_selenium: Использовать Selenium для JS-heavy сайтов
            
        Returns:
            Dict с результатами парсинга
        """
        start_time = time.time()
        
        # Проверка кэша
        cache_key = f"{url}_{source_type}"
        cached_result = await self._get_cached_result(cache_key)
        if cached_result:
            logger.info(f"Результат взят из кэша: {url}")
            return cached_result
        
        try:
            # Определение стратегии парсинга
            if source_type == 'auto':
                detected_type = self.detector.detect_from_url(url)
                logger.info(f"Определен тип источника: {detected_type}")
            else:
                detected_type = source_type
            
            # Выбор метода парсинга
            if use_selenium or detected_type in ['social_media', 'ecommerce']:
                result = await self._parse_with_selenium(url, detected_type, selectors)
            elif detected_type == 'news_site' and not selectors:
                result = await self._parse_with_newspaper(url)
            elif detected_type == 'forum':
                result = await self._parse_forum(url, selectors)
            elif detected_type == 'wiki':
                result = await self._parse_wiki(url, selectors)
            else:
                result = await self._parse_with_requests(url, detected_type, headers, proxy)
            
            # Обогащение метаданными
            result['source_type'] = detected_type
            result['parsing_time'] = time.time() - start_time
            result['parsed_at'] = datetime.now().isoformat()
            
            # Кэширование результата
            await self._cache_result(cache_key, result)
            
            logger.info(f"Успешно спарсен: {url} (тип: {detected_type})")
            return result
            
        except Exception as e:
            logger.error(f"Ошибка при парсинге {url}: {e}")
            raise
    
    async def detect_source_type(self, url: str) -> str:
        """Автоматическое определение типа источника"""
        # Быстрая проверка по URL
        url_type = self.detector.detect_from_url(url)
        if url_type != 'unknown':
            return url_type
        
        # Парсинг страницы для определения типа
        try:
            html = await self._fetch_content(url)
            soup = BeautifulSoup(html, 'html.parser')
            content_type = self.detector.detect_from_content(soup)
            return content_type if content_type != 'unknown' else 'website'
        except Exception:
            return 'website'
    
    async def _parse_with_requests(
        self,
        url: str,
        source_type: str,
        headers: Optional[Dict[str, str]] = None,
        proxy: Optional[str] = None
    ) -> Dict[str, Any]:
        """Парсинг с использованием requests/aiohttp"""
        if not self.session:
            await self.initialize()
        
        # Подготовка заголовков
        request_headers = headers or {}
        if 'User-Agent' not in request_headers and self.user_agent_rotation:
            request_headers['User-Agent'] = await self._get_random_user_agent()
        
        # Подготовка прокси
        proxy_url = proxy
        
        for attempt in range(self.max_retries):
            try:
                async with self.session.get(
                    url,
                    headers=request_headers,
                    proxy=proxy_url,
                    ssl=False
                ) as response:
                    if response.status == 200:
                        html = await response.text()
                        return await self._extract_from_html(html, url, source_type)
                    else:
                        logger.warning(f"HTTP {response.status} для {url}")
                        if response.status == 404:
                            break
                        
            except Exception as e:
                logger.error(f"Ошибка при запросе {url} (попытка {attempt + 1}): {e}")
                if attempt < self.max_retries - 1:
                    await asyncio.sleep(self.retry_delay * (attempt + 1))
        
        raise Exception(f"Не удалось получить контент с {url}")
    
    async def _parse_with_selenium(
        self,
        url: str,
        source_type: str,
        selectors: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Парсинг с использованием Selenium для JS-heavy сайтов"""
        if not self.selenium_driver:
            await self._init_selenium_driver()
        
        try:
            self.selenium_driver.get(url)
            
            # Ожидание загрузки
            await asyncio.sleep(3)
            
            # Ожидание конкретных элементов если указаны селекторы
            if selectors:
                for selector_type, selector_value in selectors.items():
                    if selector_type in ['wait_for', 'content_selector']:
                        try:
                            WebDriverWait(self.selenium_driver, 10).until(
                                EC.presence_of_element_located((By.CSS_SELECTOR, selector_value))
                            )
                        except:
                            pass
            
            html = self.selenium_driver.page_source
            return await self._extract_from_html(html, url, source_type)
            
        except Exception as e:
            logger.error(f"Ошибка при парсинге Selenium {url}: {e}")
            raise
    
    async def _parse_with_newspaper(self, url: str) -> Dict[str, Any]:
        """Парсинг с использованием библиотеки newspaper"""
        try:
            article = Article(url, language='ru')
            article.download()
            article.parse()
            article.nlp()
            
            return {
                'url': url,
                'title': article.title or '',
                'content': article.text or '',
                'author': article.authors[0] if article.authors else None,
                'publish_date': article.publish_date,
                'tags': article.tags or [],
                'images': list(article.images) if article.images else [],
                'videos': list(article.movies) if article.movies else [],
                'metadata': {
                    'summary': article.summary or '',
                    'keywords': article.keywords or []
                }
            }
            
        except Exception as e:
            logger.error(f"Ошибка при парсинге newspaper {url}: {e}")
            # Fallback на обычный парсинг
            return await self._parse_with_requests(url, 'news_site')
    
    async def _parse_forum(self, url: str, selectors: Dict[str, str]) -> Dict[str, Any]:
        """Специализированный парсинг форумов"""
        html = await self._fetch_content(url)
        soup = BeautifulSoup(html, 'html.parser')
        
        # Извлечение тем и сообщений
        posts = []
        post_elements = soup.find_all('div', class_=re.compile(r'post|message|comment'))
        
        for post in post_elements:
            author_elem = post.find(class_=re.compile(r'author|user|username'))
            content_elem = post.find(class_=re.compile(r'content|message|text'))
            
            if content_elem:
                posts.append({
                    'author': author_elem.text.strip() if author_elem else 'Unknown',
                    'content': content_elem.text.strip(),
                    'timestamp': self._extract_timestamp(post)
                })
        
        return {
            'url': url,
            'title': soup.title.string if soup.title else '',
            'content': f"Форум: {len(posts)} сообщений",
            'posts': posts,
            'metadata': {
                'post_count': len(posts),
                'forum_structure': self._analyze_forum_structure(soup)
            }
        }
    
    async def _parse_wiki(self, url: str, selectors: Dict[str, str]) -> Dict[str, Any]:
        """Специализированный парсинг wiki"""
        html = await self._fetch_content(url)
        soup = BeautifulSoup(html, 'html.parser')
        
        # Извлечение основного контента wiki
        content_div = soup.find('div', id='mw-content-text') or soup.find('div', class_='mw-parser-output')
        
        if content_div:
            # Удаление ссылок на правку
            for edit_link in content_div.find_all('span', class_='mw-editsection'):
                edit_link.decompose()
            
            content = content_div.text.strip()
        else:
            content = soup.text.strip()
        
        # Извлечение оглавления
        toc = []
        headings = content_div.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']) if content_div else []
        for heading in headings:
            level = int(heading.name[1])
            toc.append({
                'level': level,
                'text': heading.text.strip(),
                'id': heading.get('id', '')
            })
        
        return {
            'url': url,
            'title': soup.title.string if soup.title else '',
            'content': content,
            'metadata': {
                'table_of_content': toc,
                'section_count': len(toc),
                'is_wiki_page': True
            }
        }
    
    async def _extract_from_html(self, html: str, url: str, source_type: str) -> Dict[str, Any]:
        """Извлечение контента из HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        
        # Удаление ненужных элементов
        for element in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
            element.decompose()
        
        # Извлечение основных элементов
        title = self._extract_title(soup)
        content = self._extract_main_content(soup, source_type)
        author = self._extract_author(soup)
        publish_date = self._extract_date(soup)
        tags = self._extract_tags(soup)
        images = self._extract_images(soup, url)
        videos = self._extract_videos(soup)
        
        return {
            'url': url,
            'title': title,
            'content': content,
            'author': author,
            'publish_date': publish_date,
            'tags': tags,
            'images': images,
            'videos': videos,
            'metadata': {
                'source_type': source_type,
                'word_count': len(content.split()),
                'char_count': len(content),
                'has_readability_content': bool(content)
            }
        }
    
    async def _fetch_content(self, url: str) -> str:
        """Получение контента по URL"""
        if not self.session:
            await self.initialize()
        
        async with self.session.get(url, ssl=False) as response:
            if response.status == 200:
                return await response.text()
            else:
                raise Exception(f"HTTP {response.status}")
    
    def _extract_title(self, soup: BeautifulSoup) -> str:
        """Извлечение заголовка"""
        # Проверка OpenGraph тегов
        og_title = soup.find('meta', property='og:title')
        if og_title and og_title.get('content'):
            return og_title['content']
        
        # Проверка Twitter тегов
        twitter_title = soup.find('meta', attrs={'name': 'twitter:title'})
        if twitter_title and twitter_title.get('content'):
            return twitter_title['content']
        
        # Проверка тега title
        if soup.title and soup.title.string:
            return soup.title.string.strip()
        
        # Поиск h1 тега
        h1 = soup.find('h1')
        if h1:
            return h1.text.strip()
        
        return ''
    
    def _extract_main_content(self, soup: BeautifulSoup, source_type: str) -> str:
        """Извлечение основного контента"""
        # Использование readability-логики
        content_selectors = [
            'article', 'main', '.content', '.post-content', '.entry-content',
            '.article-content', '.post-body', '.message-content', '.text-content'
        ]
        
        for selector in content_selectors:
            content_elem = soup.select_one(selector)
            if content_elem:
                return content_elem.text.strip()
        
        # Fallback на весь текст
        return soup.text.strip()
    
    def _extract_author(self, soup: BeautifulSoup) -> Optional[str]:
        """Извлечение автора"""
        # Проверка мета-тегов
        author_meta = soup.find('meta', attrs={'name': 'author'})
        if author_meta and author_meta.get('content'):
            return author_meta['content']
        
        # Поиск по классам
        author_selectors = ['.author', '.byline', '.writer', '.post-author']
        for selector in author_selectors:
            author_elem = soup.select_one(selector)
            if author_elem:
                return author_elem.text.strip()
        
        return None
    
    def _extract_date(self, soup: BeautifulSoup) -> Optional[datetime]:
        """Извлечение даты публикации"""
        # Проверка мета-тегов
        date_meta = soup.find('meta', property='article:published_time')
        if date_meta and date_meta.get('content'):
            try:
                return datetime.fromisoformat(date_meta['content'])
            except:
                pass
        
        # Поиск по классам
        date_selectors = ['.date', '.published', '.post-date', '.entry-date']
        for selector in date_selectors:
            date_elem = soup.select_one(selector)
            if date_elem:
                date_text = date_elem.text.strip()
                # Парсинг даты из текста (упрощенная реализация)
                try:
                    return datetime.now()  # Заглушка
                except:
                    pass
        
        return None
    
    def _extract_tags(self, soup: BeautifulSoup) -> List[str]:
        """Извлечение тегов"""
        tags = []
        
        # Проверка мета-тегов
        keywords_meta = soup.find('meta', attrs={'name': 'keywords'})
        if keywords_meta and keywords_meta.get('content'):
            tags.extend([tag.strip() for tag in keywords_meta['content'].split(',')])
        
        # Поиск тегов по классам
        tag_elements = soup.select('.tag, .tags a, .post-tag, .keyword')
        for tag_elem in tag_elements:
            tag_text = tag_elem.text.strip()
            if tag_text and tag_text not in tags:
                tags.append(tag_text)
        
        return tags
    
    def _extract_images(self, soup: BeautifulSoup, base_url: str) -> List[str]:
        """Извлечение изображений"""
        images = []
        
        # Поиск всех изображений
        img_tags = soup.find_all('img')
        for img in img_tags:
            src = img.get('src') or img.get('data-src') or img.get('data-lazy-src')
            if src:
                # Преобразование относительных URL в абсолютные
                absolute_url = urljoin(base_url, src)
                if absolute_url not in images:
                    images.append(absolute_url)
        
        return images[:20]  # Ограничение количества
    
    def _extract_videos(self, soup: BeautifulSoup) -> List[str]:
        """Извлечение видео"""
        videos = []
        
        # Поиск video тегов
        video_tags = soup.find_all('video')
        for video in video_tags:
            src = video.get('src') or video.find('source', src=True)
            if src:
                videos.append(src.get('src') if hasattr(src, 'get') else src)
        
        # Поиск iframe (YouTube, Vimeo и т.д.)
        iframes = soup.find_all('iframe')
        for iframe in iframes:
            src = iframe.get('src')
            if src and any(platform in src.lower() for platform in ['youtube', 'vimeo', 'video']):
                videos.append(src)
        
        return videos[:10]  # Ограничение количества
    
    def _extract_timestamp(self, element) -> Optional[datetime]:
        """Извлечение временной метки из элемента"""
        # Упрощенная реализация
        return datetime.now()
    
    def _analyze_forum_structure(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """Анализ структуры форума"""
        return {
            'has_categories': bool(soup.find(class_=re.compile(r'category|forum-group'))),
            'has_threads': bool(soup.find(class_=re.compile(r'thread|topic'))),
            'has_pagination': bool(soup.find(class_=re.compile(r'pagination|pager'))),
            'post_structure': 'standard'
        }
    
    async def _get_random_user_agent(self) -> str:
        """Получение случайного User-Agent"""
        user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0'
        ]
        return user_agents[int(time.time()) % len(user_agents)]
    
    async def _init_selenium_driver(self):
        """Инициализация Selenium драйвера"""
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--window-size=1920,1080')
        
        self.selenium_driver = webdriver.Chrome(options=chrome_options)
    
    async def _get_cached_result(self, cache_key: str) -> Optional[Dict[str, Any]]:
        """Получение результата из кэша"""
        if cache_key in self._cache:
            cached_data = self._cache[cache_key]
            if time.time() - cached_data.get('timestamp', 0) < self._cache_ttl:
                return cached_data.get('result')
            else:
                del self._cache[cache_key]
        
        return None
    
    async def _cache_result(self, cache_key: str, result: Dict[str, Any]):
        """Кэширование результата"""
        self._cache[cache_key] = {
            'result': result,
            'timestamp': time.time()
        }

# Глобальный экземпляр
universal_parser = UniversalParser()