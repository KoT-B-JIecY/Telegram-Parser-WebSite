"""
Content Extractor Module
Интеллектуальное извлечение и обработка контента
"""

import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import logging
from bs4 import BeautifulSoup
import json

logger = logging.getLogger(__name__)

@dataclass
class ExtractionRule:
    """Правило извлечения контента"""
    name: str
    selector: str
    selector_type: str = 'css'  # 'css' или 'xpath'
    attribute: str = 'text'  # 'text', 'html', 'src', 'href'
    required: bool = False
    multiple: bool = False
    transform: Optional[str] = None  # 'strip', 'lower', 'upper', 'json'
    fallback: Optional[str] = None

@dataclass
class ExtractedContent:
    """Извлеченный контент"""
    title: str = ""
    content: str = ""
    summary: str = ""
    author: Optional[str] = None
    publish_date: Optional[datetime] = None
    tags: List[str] = None
    images: List[str] = None
    videos: List[str] = None
    links: List[str] = None
    metadata: Dict[str, Any] = None
    quality_score: float = 0.0
    word_count: int = 0
    reading_time: int = 0  # минуты

class ContentExtractor:
    """Интеллектуальный извлекатель контента"""
    
    def __init__(self):
        # Предустановленные правила для разных типов источников
        self.default_rules = {
            'news_site': [
                ExtractionRule('title', 'h1, .title, .headline, [data-testid="headline"]', required=True),
                ExtractionRule('content', '.article-content, .post-content, .entry-content, .story-body', required=True),
                ExtractionRule('author', '.author, .byline, .writer, [rel="author"]', multiple=True),
                ExtractionRule('date', '.date, .published, .post-date, time[datetime]', attribute='datetime'),
                ExtractionRule('tags', '.tags a, .tag, .keywords a', multiple=True),
                ExtractionRule('images', 'img[src]', attribute='src', multiple=True),
                ExtractionRule('summary', '.summary, .excerpt, .lead'),
            ],
            'blog': [
                ExtractionRule('title', 'h1, .post-title, .entry-title', required=True),
                ExtractionRule('content', '.post-content, .entry-content, .blog-content', required=True),
                ExtractionRule('author', '.author, .post-author, .by-author'),
                ExtractionRule('date', '.post-date, .entry-date, .published'),
                ExtractionRule('tags', '.tags a, .post-tags a', multiple=True),
                ExtractionRule('images', 'img[src]', attribute='src', multiple=True),
            ],
            'forum': [
                ExtractionRule('title', 'h1, .thread-title, .topic-title', required=True),
                ExtractionRule('content', '.post-content, .message-content, .post-body', multiple=True),
                ExtractionRule('author', '.username, .author-name', multiple=True),
                ExtractionRule('date', '.post-date, .message-date', multiple=True),
                ExtractionRule('images', 'img[src]', attribute='src', multiple=True),
            ],
            'wiki': [
                ExtractionRule('title', 'h1#firstHeading, .firstHeading', required=True),
                ExtractionRule('content', '#mw-content-text, .mw-parser-output', required=True),
                ExtractionRule('images', 'img[src]', attribute='src', multiple=True),
            ]
        }
        
        # Настройки качества контента
        self.quality_thresholds = {
            'min_word_count': 100,
            'min_char_count': 500,
            'max_link_ratio': 0.3,  # максимальная доля ссылок в тексте
            'min_readability_score': 0.5
        }
        
        logger.info("Content Extractor инициализирован")
    
    async def extract(
        self,
        parsed_data: Dict[str, Any],
        custom_rules: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Извлечение контента из спарсенных данных
        
        Args:
            parsed_data: Данные от парсера
            custom_rules: Пользовательские правила извлечения
            
        Returns:
            Извлеченный и обработанный контент
        """
        try:
            source_type = parsed_data.get('source_type', 'unknown')
            html_content = parsed_data.get('html', '')
            
            logger.info(f"Извлечение контента для типа: {source_type}")
            
            # Получение правил извлечения
            rules = await self._get_extraction_rules(source_type, custom_rules)
            
            # Извлечение по правилам
            if html_content:
                extracted = await self._extract_with_rules(html_content, rules)
            else:
                # Работа с уже извлеченными данными
                extracted = await self._extract_from_data(parsed_data)
            
            # Обогащение и очистка контента
            cleaned_content = await self._clean_content(extracted)
            enriched_content = await self._enrich_content(cleaned_content)
            
            # Оценка качества
            quality_score = await self._calculate_quality_score(enriched_content)
            enriched_content['quality_score'] = quality_score
            
            # Фильтрация по качеству
            if quality_score < self.quality_thresholds['min_readability_score']:
                logger.warning(f"Качество контента ниже порога: {quality_score}")
            
            logger.info(f"Контент извлечен успешно. Качество: {quality_score}")
            return enriched_content
            
        except Exception as e:
            logger.error(f"Ошибка при извлечении контента: {e}")
            # Возврат минимального контента
            return {
                'title': parsed_data.get('title', ''),
                'content': parsed_data.get('content', ''),
                'quality_score': 0.0,
                'error': str(e)
            }
    
    async def extract_from_url(self, url: str, rules: List[ExtractionRule]) -> Dict[str, Any]:
        """Извлечение контента напрямую из URL с пользовательскими правилами"""
        try:
            # Получение HTML
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    html = await response.text()
            
            return await self._extract_with_rules(html, rules)
            
        except Exception as e:
            logger.error(f"Ошибка при извлечении из URL {url}: {e}")
            return {'error': str(e)}
    
    async def _get_extraction_rules(
        self,
        source_type: str,
        custom_rules: Optional[Dict[str, Any]] = None
    ) -> List[ExtractionRule]:
        """Получение правил извлечения для типа источника"""
        rules = []
        
        # Базовые правила для типа источника
        if source_type in self.default_rules:
            rules.extend(self.default_rules[source_type])
        
        # Пользовательские правила
        if custom_rules and 'rules' in custom_rules:
            for rule_data in custom_rules['rules']:
                rule = ExtractionRule(**rule_data)
                rules.append(rule)
        
        # Если правил нет, используем универсальные
        if not rules:
            rules = self._get_universal_rules()
        
        return rules
    
    def _get_universal_rules(self) -> List[ExtractionRule]:
        """Универсальные правила для неизвестных типов"""
        return [
            ExtractionRule('title', 'title, h1, .title', required=True),
            ExtractionRule('content', 'main, .content, .main, article, .article', required=True),
            ExtractionRule('author', '.author, .byline, [rel="author"]'),
            ExtractionRule('date', 'time, .date, .published'),
            ExtractionRule('images', 'img[src]', attribute='src', multiple=True),
        ]
    
    async def _extract_with_rules(self, html: str, rules: List[ExtractionRule]) -> Dict[str, Any]:
        """Извлечение контента по правилам"""
        soup = BeautifulSoup(html, 'html.parser')
        extracted = {}
        
        for rule in rules:
            try:
                if rule.selector_type == 'css':
                    elements = soup.select(rule.selector)
                else:  # xpath - требует дополнительной библиотеки
                    elements = []
                
                if not elements and rule.required and rule.fallback:
                    # Использование fallback правила
                    elements = soup.select(rule.fallback)
                
                if elements:
                    if rule.multiple:
                        values = []
                        for elem in elements:
                            value = self._extract_value_from_element(elem, rule)
                            if value:
                                values.append(value)
                        extracted[rule.name] = values
                    else:
                        value = self._extract_value_from_element(elements[0], rule)
                        extracted[rule.name] = value
                
            except Exception as e:
                logger.warning(f"Ошибка при применении правила {rule.name}: {e}")
                if rule.required:
                    extracted[rule.name] = ''
        
        return extracted
    
    def _extract_value_from_element(self, element, rule: ExtractionRule) -> Optional[str]:
        """Извлечение значения из элемента по правилу"""
        try:
            if rule.attribute == 'text':
                value = element.text.strip()
            elif rule.attribute == 'html':
                value = str(element)
            else:
                value = element.get(rule.attribute, '')
                if isinstance(value, list):
                    value = ' '.join(value)
                value = str(value).strip()
            
            # Применение трансформаций
            if rule.transform:
                if rule.transform == 'strip':
                    value = value.strip()
                elif rule.transform == 'lower':
                    value = value.lower()
                elif rule.transform == 'upper':
                    value = value.upper()
                elif rule.transform == 'json':
                    try:
                        value = json.loads(value)
                    except:
                        pass
            
            return value if value else None
            
        except Exception as e:
            logger.warning(f"Ошибка при извлечении значения: {e}")
            return None
    
    async def _extract_from_data(self, parsed_data: Dict[str, Any]) -> Dict[str, Any]:
        """Извлечение из уже спарсенных данных"""
        return {
            'title': parsed_data.get('title', ''),
            'content': parsed_data.get('content', ''),
            'author': parsed_data.get('author'),
            'publish_date': parsed_data.get('publish_date'),
            'tags': parsed_data.get('tags', []),
            'images': parsed_data.get('images', []),
            'videos': parsed_data.get('videos', []),
            'metadata': parsed_data.get('metadata', {})
        }
    
    async def _clean_content(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Очистка и нормализация контента"""
        cleaned = content.copy()
        
        # Очистка заголовка
        if cleaned.get('title'):
            cleaned['title'] = self._clean_text(cleaned['title'])
        
        # Очистка основного контента
        if cleaned.get('content'):
            cleaned['content'] = self._clean_main_content(cleaned['content'])
        
        # Очистка автора
        if cleaned.get('author'):
            cleaned['author'] = self._clean_author_name(cleaned['author'])
        
        # Очистка тегов
        if cleaned.get('tags'):
            cleaned['tags'] = self._clean_tags(cleaned['tags'])
        
        # Валидация URL изображений
        if cleaned.get('images'):
            cleaned['images'] = self._validate_image_urls(cleaned['images'])
        
        return cleaned
    
    def _clean_text(self, text: str) -> str:
        """Очистка текста"""
        if not text:
            return ""
        
        # Удаление лишних пробелов
        text = re.sub(r'\s+', ' ', text)
        
        # Удаление специальных символов
        text = re.sub(r'[^\w\s\-.,!?;:()"""'"''\[\]{}@#$%^&*+=|<>~`]', '', text)
        
        # Удаление лишних пустых строк
        text = re.sub(r'\n\s*\n', '\n\n', text)
        
        return text.strip()
    
    def _clean_main_content(self, content: str) -> str:
        """Очистка основного контента"""
        if not content:
            return ""
        
        # Удаление ссылок на социальные сети
        content = re.sub(r'Follow us on [\w\s]+|Подписывайтесь на [\w\s]+', '', content, flags=re.IGNORECASE)
        
        # Удаление рекламы и промо
        content = re.sub(r'Реклама|Advertisement|РЕКЛАМА', '', content)
        
        # Удаление ссылок на другие статьи (если их слишком много)
        link_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        links = re.findall(link_pattern, content)
        if len(links) > len(content.split()) * self.quality_thresholds['max_link_ratio']:
            content = re.sub(link_pattern, '', content)
        
        return self._clean_text(content)
    
    def _clean_author_name(self, author: str) -> str:
        """Очистка имени автора"""
        if not author:
            return None
        
        # Удаление лишних слов
        author = re.sub(r'^(by|автор|author):?\s*', '', author, flags=re.IGNORECASE)
        
        # Очистка от лишних символов
        author = re.sub(r'[^\w\s\-.,]', '', author)
        
        return author.strip() if len(author.strip()) > 2 else None
    
    def _clean_tags(self, tags: List[str]) -> List[str]:
        """Очистка тегов"""
        if not tags:
            return []
        
        cleaned_tags = []
        for tag in tags:
            if isinstance(tag, str):
                tag = self._clean_text(tag)
                if tag and len(tag) > 1:
                    cleaned_tags.append(tag.lower())
        
        # Удаление дубликатов с сохранением порядка
        seen = set()
        unique_tags = []
        for tag in cleaned_tags:
            if tag not in seen:
                seen.add(tag)
                unique_tags.append(tag)
        
        return unique_tags[:20]  # Ограничение количества тегов
    
    def _validate_image_urls(self, images: List[str]) -> List[str]:
        """Валидация URL изображений"""
        if not images:
            return []
        
        valid_images = []
        for img_url in images:
            if isinstance(img_url, str) and img_url.startswith(('http://', 'https://')):
                # Проверка расширения
                if re.search(r'\.(jpg|jpeg|png|gif|webp|svg)$', img_url, re.IGNORECASE):
                    valid_images.append(img_url)
        
        return valid_images[:50]  # Ограничение количества изображений
    
    async def _enrich_content(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """Обогащение контента дополнительной информацией"""
        enriched = content.copy()
        
        # Подсчет слов и символов
        if enriched.get('content'):
            enriched['word_count'] = len(enriched['content'].split())
            enriched['char_count'] = len(enriched['content'])
        
        # Расчет времени чтения
        if enriched.get('word_count'):
            # Средняя скорость чтения: 200 слов в минуту
            enriched['reading_time'] = max(1, enriched['word_count'] // 200)
        
        # Генерация краткого описания
        if enriched.get('content') and not enriched.get('summary'):
            enriched['summary'] = await self._generate_summary(enriched['content'])
        
        # Извлечение дополнительных метаданных
        if enriched.get('content'):
            enriched['metadata'] = enriched.get('metadata', {})
            enriched['metadata'].update(await self._extract_metadata(enriched['content']))
        
        return enriched
    
    async def _generate_summary(self, content: str, max_length: int = 200) -> str:
        """Генерация краткого описания контента"""
        if not content:
            return ""
        
        sentences = re.split(r'[.!?]+', content)
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if not sentences:
            return content[:max_length] + "..." if len(content) > max_length else content
        
        # Использование первых 2-3 предложений для описания
        summary_sentences = []
        current_length = 0
        
        for sentence in sentences[:3]:
            if current_length + len(sentence) <= max_length:
                summary_sentences.append(sentence)
                current_length += len(sentence)
            else:
                break
        
        summary = '. '.join(summary_sentences)
        if len(summary) > max_length:
            summary = summary[:max_length] + "..."
        
        return summary
    
    async def _extract_metadata(self, content: str) -> Dict[str, Any]:
        """Извлечение дополнительных метаданных из контента"""
        metadata = {}
        
        # Подсчет предложений
        sentences = re.split(r'[.!?]+', content)
        metadata['sentence_count'] = len([s for s in sentences if s.strip()])
        
        # Подсчет абзацев
        paragraphs = [p for p in content.split('\n\n') if p.strip()]
        metadata['paragraph_count'] = len(paragraphs)
        
        # Подсчет ссылок
        link_pattern = r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+'
        metadata['link_count'] = len(re.findall(link_pattern, content))
        
        # Анализ читаемости (упрощенный)
        avg_sentence_length = metadata['word_count'] / max(metadata['sentence_count'], 1)
        metadata['readability_score'] = max(0, 1 - (avg_sentence_length - 15) / 30)
        
        # Определение языка (упрощенный)
        cyrillic_ratio = len(re.findall(r'[а-яё]', content, re.IGNORECASE)) / max(metadata['char_count'], 1)
        metadata['language'] = 'ru' if cyrillic_ratio > 0.3 else 'en'
        
        return metadata
    
    async def _calculate_quality_score(self, content: Dict[str, Any]) -> float:
        """Расчет оценки качества контента"""
        score = 0.0
        max_score = 100.0
        
        # Наличие заголовка
        if content.get('title') and len(content['title']) > 10:
            score += 15
        
        # Длина контента
        word_count = content.get('word_count', 0)
        if word_count >= 500:
            score += 25
        elif word_count >= 200:
            score += 15
        elif word_count >= 100:
            score += 10
        
        # Наличие автора
        if content.get('author'):
            score += 10
        
        # Наличие даты
        if content.get('publish_date'):
            score += 10
        
        # Наличие тегов
        if content.get('tags') and len(content['tags']) > 0:
            score += 10
        
        # Наличие изображений
        if content.get('images') and len(content['images']) > 0:
            score += 10
        
        # Читаемость
        readability_score = content.get('metadata', {}).get('readability_score', 0)
        score += readability_score * 20
        
        return min(score / max_score, 1.0)

# Глобальный экземпляр
content_extractor = ContentExtractor()