"""
NLP Processor Module
Обработка естественного языка для оптимизации контента
"""

import asyncio
import re
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import logging
import time

logger = logging.getLogger(__name__)

@dataclass
class NLPAnalysis:
    """Результат NLP анализа"""
    sentiment_score: float  # -1 to 1
    readability_score: float  # 0 to 1
    keyword_density: Dict[str, float]
    named_entities: List[Dict[str, Any]]
    sentence_complexity: float
    grammar_issues: List[Dict[str, Any]]
    topic_classification: str
    language: str
    word_count: int
    sentence_count: int
    paragraph_count: int
    reading_time_minutes: int

@dataclass
class SentimentResult:
    """Результат анализа тональности"""
    score: float
    label: str  # 'positive', 'negative', 'neutral'
    confidence: float

class NLPProcessor:
    """Процессор естественного языка"""
    
    def __init__(self):
        # Модели и инструменты NLP
        self.sentiment_analyzer = None
        self.readability_analyzer = None
        self.keyword_extractor = None
        self.entity_recognizer = None
        self.grammar_checker = None
        self.topic_classifier = None
        
        # Настройки
        self.min_keyword_length = 3
        self.max_keywords = 20
        self.min_keyword_density = 0.01
        self.max_keyword_density = 0.1
        
        # Кэш
        self._analysis_cache: Dict[str, NLPAnalysis] = {}
        self._cache_ttl = 3600  # 1 час
        
        # Статистика
        self.stats = {
            'texts_analyzed': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'avg_processing_time': 0.0
        }
        
        logger.info("NLP Processor инициализирован")
    
    async def initialize(self):
        """Инициализация NLP моделей"""
        try:
            # Инициализация моделей (в реальном приложении - загрузка из transformers)
            logger.info("Загрузка NLP моделей...")
            
            # Заглушки для демонстрации
            self.sentiment_analyzer = self._dummy_sentiment_analysis
            self.readability_analyzer = self._dummy_readability_analysis
            self.keyword_extractor = self._dummy_keyword_extraction
            self.entity_recognizer = self._dummy_entity_recognition
            self.grammar_checker = self._dummy_grammar_check
            self.topic_classifier = self._dummy_topic_classification
            
            logger.info("NLP модели загружены")
            
        except Exception as e:
            logger.error(f"Ошибка при загрузке NLP моделей: {e}")
            # Использование заглушек
            self._initialize_dummy_models()
    
    async def cleanup(self):
        """Очистка ресурсов"""
        # Очистка кэша
        self._analysis_cache.clear()
        logger.info("NLP Processor очищен")
    
    async def cleanup_cache(self):
        """Очистка кэша анализа"""
        current_time = time.time()
        expired_keys = [
            key for key, analysis in self._analysis_cache.items()
            if current_time - getattr(analysis, 'timestamp', current_time) > self._cache_ttl
        ]
        
        for key in expired_keys:
            del self._analysis_cache[key]
        
        logger.info(f"Кэш NLP очищен. Удалено {len(expired_keys)} записей")
    
    async def process(self, content: Dict[str, Any]) -> NLPAnalysis:
        """
        Обработка контента с помощью NLP
        
        Args:
            content: Словарь с контентом (title, content, etc.)
            
        Returns:
            Результат NLP анализа
        """
        start_time = time.time()
        
        # Формирование ключа для кэша
        cache_key = self._generate_cache_key(content)
        
        # Проверка кэша
        if cache_key in self._analysis_cache:
            self.stats['cache_hits'] += 1
            logger.debug("NLP анализ взят из кэша")
            return self._analysis_cache[cache_key]
        
        self.stats['cache_misses'] += 1
        
        try:
            # Объединение заголовка и контента для анализа
            text_to_analyze = f"{content.get('title', '')} {content.get('content', '')}".strip()
            
            if not text_to_analyze:
                return self._empty_analysis()
            
            # Параллельный анализ
            analysis_tasks = [
                self._analyze_sentiment(text_to_analyze),
                self._analyze_readability(text_to_analyze),
                self._extract_keywords(text_to_analyze),
                self._recognize_entities(text_to_analyze),
                self._check_grammar(text_to_analyze),
                self._classify_topic(text_to_analyze),
                self._analyze_language(text_to_analyze)
            ]
            
            results = await asyncio.gather(*analysis_tasks)
            
            # Формирование результата анализа
            analysis = NLPAnalysis(
                sentiment_score=results[0].score,
                readability_score=results[1],
                keyword_density=results[2],
                named_entities=results[3],
                sentence_complexity=await self._calculate_sentence_complexity(text_to_analyze),
                grammar_issues=results[4],
                topic_classification=results[5],
                language=results[6],
                word_count=len(text_to_analyze.split()),
                sentence_count=len(re.split(r'[.!?]+', text_to_analyze)),
                paragraph_count=len([p for p in text_to_analyze.split('\n\n') if p.strip()]),
                reading_time_minutes=max(1, len(text_to_analyze.split()) // 200)
            )
            
            # Кэширование результата
            self._analysis_cache[cache_key] = analysis
            
            # Обновление статистики
            self.stats['texts_analyzed'] += 1
            processing_time = time.time() - start_time
            self.stats['avg_processing_time'] = (
                (self.stats['avg_processing_time'] * (self.stats['texts_analyzed'] - 1) + processing_time) /
                self.stats['texts_analyzed']
            )
            
            logger.debug(f"NLP анализ завершен за {processing_time:.2f} секунд")
            return analysis
            
        except Exception as e:
            logger.error(f"Ошибка при NLP анализе: {e}")
            return self._empty_analysis()
    
    async def _analyze_sentiment(self, text: str) -> SentimentResult:
        """Анализ тональности текста"""
        if self.sentiment_analyzer:
            try:
                # Использование загруженной модели
                if asyncio.iscoroutinefunction(self.sentiment_analyzer):
                    result = await self.sentiment_analyzer(text)
                else:
                    result = self.sentiment_analyzer(text)
                
                return SentimentResult(**result) if isinstance(result, dict) else result
                
            except Exception as e:
                logger.warning(f"Ошибка анализа тональности: {e}")
        
        # Fallback на простой анализ
        return self._simple_sentiment_analysis(text)
    
    async def _analyze_readability(self, text: str) -> float:
        """Анализ читаемости текста"""
        if self.readability_analyzer:
            try:
                if asyncio.iscoroutinefunction(self.readability_analyzer):
                    return await self.readability_analyzer(text)
                else:
                    return self.readability_analyzer(text)
            except Exception as e:
                logger.warning(f"Ошибка анализа читаемости: {e}")
        
        # Fallback на простой анализ
        return self._simple_readability_analysis(text)
    
    async def _extract_keywords(self, text: str) -> Dict[str, float]:
        """Извлечение ключевых слов и их плотности"""
        if self.keyword_extractor:
            try:
                if asyncio.iscoroutinefunction(self.keyword_extractor):
                    keywords = await self.keyword_extractor(text)
                else:
                    keywords = self.keyword_extractor(text)
                
                # Расчет плотности ключевых слов
                total_words = len(text.split())
                keyword_density = {}
                
                for keyword, count in keywords.items():
                    density = count / total_words
                    if self.min_keyword_density <= density <= self.max_keyword_density:
                        keyword_density[keyword] = density
                
                return keyword_density
                
            except Exception as e:
                logger.warning(f"Ошибка извлечения ключевых слов: {e}")
        
        # Fallback на простой анализ
        return self._simple_keyword_extraction(text)
    
    async def _recognize_entities(self, text: str) -> List[Dict[str, Any]]:
        """Распознавание именованных сущностей"""
        if self.entity_recognizer:
            try:
                if asyncio.iscoroutinefunction(self.entity_recognizer):
                    entities = await self.entity_recognizer(text)
                else:
                    entities = self.entity_recognizer(text)
                
                return entities[:50]  # Ограничение количества
                
            except Exception as e:
                logger.warning(f"Ошибка распознавания сущностей: {e}")
        
        # Fallback на простой анализ
        return self._simple_entity_recognition(text)
    
    async def _check_grammar(self, text: str) -> List[Dict[str, Any]]:
        """Проверка грамматики"""
        if self.grammar_checker:
            try:
                if asyncio.iscoroutinefunction(self.grammar_checker):
                    issues = await self.grammar_checker(text)
                else:
                    issues = self.grammar_checker(text)
                
                return issues[:20]  # Ограничение количества
                
            except Exception as e:
                logger.warning(f"Ошибка проверки грамматики: {e}")
        
        # Fallback на простую проверку
        return self._simple_grammar_check(text)
    
    async def _classify_topic(self, text: str) -> str:
        """Классификация темы текста"""
        if self.topic_classifier:
            try:
                if asyncio.iscoroutinefunction(self.topic_classifier):
                    topic = await self.topic_classifier(text)
                else:
                    topic = self.topic_classifier(text)
                
                return topic
                
            except Exception as e:
                logger.warning(f"Ошибка классификации темы: {e}")
        
        # Fallback на простую классификацию
        return self._simple_topic_classification(text)
    
    async def _analyze_language(self, text: str) -> str:
        """Определение языка текста"""
        # Простая проверка на основе символов
        cyrillic_count = sum(1 for char in text.lower() if char in 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
        latin_count = sum(1 for char in text.lower() if char in 'abcdefghijklmnopqrstuvwxyz')
        
        if cyrillic_count > latin_count:
            return 'ru'
        else:
            return 'en'
    
    async def _calculate_sentence_complexity(self, text: str) -> float:
        """Расчет сложности предложений"""
        sentences = re.split(r'[.!?]+', text)
        if not sentences:
            return 0.0
        
        total_complexity = 0.0
        valid_sentences = 0
        
        for sentence in sentences:
            sentence = sentence.strip()
            if len(sentence) < 10:  # Пропуск коротких предложений
                continue
            
            words = sentence.split()
            word_count = len(words)
            
            # Сложность на основе длины предложения
            complexity = min(1.0, word_count / 30)  # 30 слов = максимальная сложность
            
            # Учет сложных слов (длинные слова)
            complex_words = sum(1 for word in words if len(word) > 6)
            complexity += (complex_words / word_count) * 0.3
            
            total_complexity += min(complexity, 1.0)
            valid_sentences += 1
        
        return total_complexity / valid_sentences if valid_sentences > 0 else 0.0
    
    def _generate_cache_key(self, content: Dict[str, Any]) -> str:
        """Генерация ключа для кэширования"""
        # Использование хеша контента для ключа
        import hashlib
        content_str = f"{content.get('title', '')}{content.get('content', '')}"
        return hashlib.md5(content_str.encode()).hexdigest()
    
    def _empty_analysis(self) -> NLPAnalysis:
        """Пустой результат анализа"""
        return NLPAnalysis(
            sentiment_score=0.0,
            readability_score=0.5,
            keyword_density={},
            named_entities=[],
            sentence_complexity=0.0,
            grammar_issues=[],
            topic_classification='unknown',
            language='unknown',
            word_count=0,
            sentence_count=0,
            paragraph_count=0,
            reading_time_minutes=0
        )
    
    # Методы-заглушки для демонстрации
    def _initialize_dummy_models(self):
        """Инициализация заглушек для моделей"""
        self.sentiment_analyzer = self._dummy_sentiment_analysis
        self.readability_analyzer = self._dummy_readability_analysis
        self.keyword_extractor = self._dummy_keyword_extraction
        self.entity_recognizer = self._dummy_entity_recognition
        self.grammar_checker = self._dummy_grammar_check
        self.topic_classifier = self._dummy_topic_classification
    
    async def _dummy_sentiment_analysis(self, text: str) -> SentimentResult:
        """Заглушка для анализа тональности"""
        # Простой анализ на основе ключевых слов
        positive_words = ['хорошо', 'отлично', 'прекрасно', 'замечательно', 'good', 'great', 'excellent']
        negative_words = ['плохо', 'ужасно', 'отвратительно', 'bad', 'terrible', 'awful']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return SentimentResult(score=0.7, label='positive', confidence=0.8)
        elif negative_count > positive_count:
            return SentimentResult(score=-0.7, label='negative', confidence=0.8)
        else:
            return SentimentResult(score=0.0, label='neutral', confidence=0.9)
    
    def _dummy_readability_analysis(self, text: str) -> float:
        """Заглушка для анализа читаемости"""
        # Простой анализ на основе длины предложений
        sentences = re.split(r'[.!?]+', text)
        if not sentences:
            return 0.5
        
        avg_sentence_length = sum(len(s.split()) for s in sentences if s.strip()) / len(sentences)
        
        # Оптимальная длина предложения - 15-20 слов
        if 15 <= avg_sentence_length <= 20:
            return 0.9
        elif 10 <= avg_sentence_length <= 25:
            return 0.7
        elif 5 <= avg_sentence_length <= 30:
            return 0.5
        else:
            return 0.3
    
    def _dummy_keyword_extraction(self, text: str) -> Dict[str, int]:
        """Заглушка для извлечения ключевых слов"""
        # Простое извлечение на основе частотности
        words = re.findall(r'\b\w{4,}\b', text.lower())
        word_freq = {}
        
        for word in words:
            if word not in {'this', 'that', 'with', 'have', 'will', 'from', 'they', 'know', 'want', 'been', 'good', 'much', 'some', 'time', 'very', 'when', 'come', 'here', 'just', 'like', 'make', 'many', 'over', 'such', 'take', 'than', 'them', 'well', 'were'}":  # Стоп-слова
                word_freq[word] = word_freq.get(word, 0) + 1
        
        # Возврат топ-10 ключевых слов
        return dict(sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:10])
    
    def _dummy_entity_recognition(self, text: str) -> List[Dict[str, Any]]:
        """Заглушка для распознавания сущностей"""
        entities = []
        
        # Простое распознавание на основе паттернов
        # Email
        emails = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        for email in emails:
            entities.append({'text': email, 'type': 'EMAIL', 'confidence': 0.9})
        
        # URL
        urls = re.findall(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)
        for url in urls:
            entities.append({'text': url, 'type': 'URL', 'confidence': 0.9})
        
        # Даты (простой паттерн)
        dates = re.findall(r'\b\d{1,2}[\/\.]\d{1,2}[\/\.]\d{2,4}\b', text)
        for date in dates:
            entities.append({'text': date, 'type': 'DATE', 'confidence': 0.7})
        
        return entities
    
    def _dummy_grammar_check(self, text: str) -> List[Dict[str, Any]]:
        """Заглушка для проверки грамматики"""
        issues = []
        
        # Простые проверки
        # Проверка повторяющихся слов
        words = text.lower().split()
        for i in range(len(words) - 1):
            if words[i] == words[i + 1] and len(words[i]) > 2:
                issues.append({
                    'type': 'repetition',
                    'message': 'Повторяющееся слово',
                    'position': i,
                    'suggestion': f'Удалите повторяющееся слово "{words[i]}"'
                })
        
        return issues
    
    def _dummy_topic_classification(self, text: str) -> str:
        """Заглушка для классификации темы"""
        # Простая классификация на основе ключевых слов
        text_lower = text.lower()
        
        tech_keywords = ['технолог', 'technology', 'tech', 'software', 'hardware', 'программ', 'компьютер']
        politics_keywords = ['политик', 'politic', 'government', 'парламент', 'выбор', 'election']
        sports_keywords = ['спорт', 'sport', 'футбол', 'football', 'теннис', 'tennis', 'матч', 'match']
        business_keywords = ['бизнес', 'business', 'компани', 'company', 'деньг', 'money', 'экономик', 'economy']
        
        categories = {
            'technology': sum(1 for word in tech_keywords if word in text_lower),
            'politics': sum(1 for word in politics_keywords if word in text_lower),
            'sports': sum(1 for word in sports_keywords if word in text_lower),
            'business': sum(1 for word in business_keywords if word in text_lower)
        }
        
        # Возврат категории с наибольшим количеством совпадений
        if any(count > 0 for count in categories.values()):
            return max(categories.items(), key=lambda x: x[1])[0]
        else:
            return 'general'
    
    def _simple_sentiment_analysis(self, text: str) -> SentimentResult:
        """Простой анализ тональности"""
        return asyncio.run(self._dummy_sentiment_analysis(text))
    
    def _simple_readability_analysis(self, text: str) -> float:
        """Простой анализ читаемости"""
        return self._dummy_readability_analysis(text)
    
    def _simple_keyword_extraction(self, text: str) -> Dict[str, float]:
        """Простое извлечение ключевых слов"""
        keywords = self._dummy_keyword_extraction(text)
        total_words = len(text.split())
        return {word: count / total_words for word, count in keywords.items()}
    
    def _simple_entity_recognition(self, text: str) -> List[Dict[str, Any]]:
        """Простое распознавание сущностей"""
        return self._dummy_entity_recognition(text)
    
    def _simple_grammar_check(self, text: str) -> List[Dict[str, Any]]:
        """Простая проверка грамматики"""
        return self._dummy_grammar_check(text)
    
    def _simple_topic_classification(self, text: str) -> str:
        """Простая классификация темы"""
        return self._dummy_topic_classification(text)
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса NLP процессора"""
        return {
            'is_initialized': self.sentiment_analyzer is not None,
            'stats': self.stats,
            'cache_size': len(self._analysis_cache),
            'models_loaded': {
                'sentiment': self.sentiment_analyzer is not None,
                'readability': self.readability_analyzer is not None,
                'keywords': self.keyword_extractor is not None,
                'entities': self.entity_recognizer is not None,
                'grammar': self.grammar_checker is not None,
                'topic': self.topic_classifier is not None
            }
        }

# Глобальный экземпляр
nlp_processor = NLPProcessor()