import hashlib
import secrets
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import logging
import re
import json
import bcrypt
from cryptography.fernet import Fernet
import jwt
from dataclasses import dataclass

@dataclass
class SecurityEvent:
    timestamp: datetime
    event_type: str
    severity: str
    source_ip: str
    user_id: Optional[str]
    details: Dict[str, Any]

class SecurityManager:
    def __init__(self, db_path: str = "ultrabot.db", jwt_secret: str = None):
        self.db_path = db_path
        self.jwt_secret = jwt_secret or secrets.token_urlsafe(32)
        self.logger = logging.getLogger(__name__)
        
        # Rate limiting settings
        self.rate_limits = {
            'login_attempts': {'limit': 5, 'window': 300},  # 5 attempts per 5 minutes
            'api_requests': {'limit': 1000, 'window': 3600},  # 1000 per hour
            'content_creation': {'limit': 50, 'window': 3600},  # 50 per hour
            'failed_logins': {'limit': 3, 'window': 900}  # 3 per 15 minutes
        }
        
        # Security settings
        self.settings = {
            'password_min_length': 8,
            'password_require_complexity': True,
            'session_timeout_hours': 24,
            'max_sessions_per_user': 5,
            'enable_2fa': False,
            'require_email_verification': True
        }
        
        # Initialize encryption
        self.encryption_key = Fernet.generate_key()
        self.cipher = Fernet(self.encryption_key)
        
        # Track security events
        self.security_events = []
        
        self.setup_security_tables()
    
    def setup_security_tables(self):
        """Initialize security-related database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Rate limiting table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS rate_limits (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                identifier TEXT NOT NULL,
                action_type TEXT NOT NULL,
                count INTEGER DEFAULT 1,
                window_start DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_attempt DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Failed login attempts table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS failed_logins (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT,
                source_ip TEXT NOT NULL,
                attempt_time DATETIME DEFAULT CURRENT_TIMESTAMP,
                reason TEXT
            )
        ''')
        
        # Security events table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS security_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                event_type TEXT NOT NULL,
                severity TEXT NOT NULL,
                source_ip TEXT,
                user_id TEXT,
                details TEXT,
                resolved BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # Blocked IPs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS blocked_ips (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ip_address TEXT UNIQUE NOT NULL,
                reason TEXT,
                blocked_until DATETIME,
                blocked_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                blocked_by TEXT
            )
        ''')
        
        # API keys table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS api_keys (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key_id TEXT UNIQUE NOT NULL,
                user_id INTEGER NOT NULL,
                key_hash TEXT NOT NULL,
                name TEXT,
                permissions TEXT DEFAULT '[]',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_used DATETIME,
                is_active BOOLEAN DEFAULT TRUE,
                expires_at DATETIME,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Content moderation table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content_moderation (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_id TEXT NOT NULL,
                moderation_status TEXT DEFAULT 'pending',
                flagged_keywords TEXT,
                spam_score REAL,
                moderation_reason TEXT,
                moderated_at DATETIME,
                moderated_by INTEGER,
                FOREIGN KEY (content_id) REFERENCES content (content_id),
                FOREIGN KEY (moderated_by) REFERENCES users (id)
            )
        ''')
        
        # Create indexes
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_rate_limits_identifier ON rate_limits (identifier, action_type)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_failed_logins_ip ON failed_logins (source_ip)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_security_events_timestamp ON security_events (timestamp)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_blocked_ips_address ON blocked_ips (ip_address)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys (key_hash)')
        
        conn.commit()
        conn.close()
    
    def hash_password(self, password: str) -> str:
        """Hash password using bcrypt"""
        return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    
    def verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password against hash"""
        return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))
    
    def validate_password(self, password: str) -> Dict[str, Any]:
        """Validate password strength"""
        errors = []
        
        if len(password) < self.settings['password_min_length']:
            errors.append(f"Password must be at least {self.settings['password_min_length']} characters long")
        
        if self.settings['password_require_complexity']:
            if not re.search(r'[A-Z]', password):
                errors.append("Password must contain at least one uppercase letter")
            
            if not re.search(r'[a-z]', password):
                errors.append("Password must contain at least one lowercase letter")
            
            if not re.search(r'\d', password):
                errors.append("Password must contain at least one number")
            
            if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
                errors.append("Password must contain at least one special character")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors
        }
    
    def check_rate_limit(self, identifier: str, action_type: str) -> Dict[str, Any]:
        """Check if action is within rate limits"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get rate limit config
            limit_config = self.rate_limits.get(action_type, {'limit': 100, 'window': 3600})
            window_start = datetime.now() - timedelta(seconds=limit_config['window'])
            
            # Check current count
            cursor.execute('''
                SELECT count, window_start FROM rate_limits 
                WHERE identifier = ? AND action_type = ?
            ''', (identifier, action_type))
            
            result = cursor.fetchone()
            
            if result:
                count, window_start_str = result
                window_start_dt = datetime.fromisoformat(window_start_str)
                
                # Reset if window has expired
                if window_start_dt < window_start:
                    count = 0
                    window_start_dt = datetime.now()
                
                # Check if limit exceeded
                if count >= limit_config['limit']:
                    conn.close()
                    return {
                        'allowed': False,
                        'remaining': 0,
                        'reset_time': window_start_dt + timedelta(seconds=limit_config['window'])
                    }
                
                # Update count
                new_count = count + 1
                cursor.execute('''
                    UPDATE rate_limits 
                    SET count = ?, last_attempt = CURRENT_TIMESTAMP
                    WHERE identifier = ? AND action_type = ?
                ''', (new_count, identifier, action_type))
                
            else:
                # Create new record
                new_count = 1
                cursor.execute('''
                    INSERT INTO rate_limits (identifier, action_type, count)
                    VALUES (?, ?, ?)
                ''', (identifier, action_type, new_count))
            
            conn.commit()
            conn.close()
            
            return {
                'allowed': True,
                'remaining': limit_config['limit'] - new_count,
                'reset_time': datetime.now() + timedelta(seconds=limit_config['window'])
            }
            
        except Exception as e:
            self.logger.error(f"Error checking rate limit: {e}")
            return {'allowed': True, 'remaining': 100}  # Allow on error
    
    def log_security_event(self, event_type: str, severity: str, source_ip: str,
                         user_id: str = None, details: Dict = None):
        """Log a security event"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO security_events 
                (event_type, severity, source_ip, user_id, details)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                event_type,
                severity,
                source_ip,
                user_id,
                json.dumps(details or {})
            ))
            
            conn.commit()
            conn.close()
            
            # Add to in-memory events
            event = SecurityEvent(
                timestamp=datetime.now(),
                event_type=event_type,
                severity=severity,
                source_ip=source_ip,
                user_id=user_id,
                details=details or {}
            )
            self.security_events.append(event)
            
            # Keep only last 1000 events in memory
            if len(self.security_events) > 1000:
                self.security_events = self.security_events[-1000:]
            
            self.logger.warning(f"Security event: {event_type} from {source_ip}")
            
        except Exception as e:
            self.logger.error(f"Error logging security event: {e}")
    
    def is_ip_blocked(self, ip_address: str) -> bool:
        """Check if IP address is blocked"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT blocked_until FROM blocked_ips 
                WHERE ip_address = ? AND blocked_until > CURRENT_TIMESTAMP
            ''', (ip_address,))
            
            result = cursor.fetchone()
            conn.close()
            
            return result is not None
            
        except Exception as e:
            self.logger.error(f"Error checking IP block: {e}")
            return False
    
    def block_ip(self, ip_address: str, reason: str, duration_hours: int = 24,
                blocked_by: str = 'system'):
        """Block an IP address"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            blocked_until = datetime.now() + timedelta(hours=duration_hours)
            
            cursor.execute('''
                INSERT OR REPLACE INTO blocked_ips 
                (ip_address, reason, blocked_until, blocked_by)
                VALUES (?, ?, ?, ?)
            ''', (ip_address, reason, blocked_until, blocked_by))
            
            conn.commit()
            conn.close()
            
            self.log_security_event(
                event_type='ip_blocked',
                severity='high',
                source_ip=ip_address,
                details={'reason': reason, 'duration_hours': duration_hours}
            )
            
            self.logger.warning(f"IP {ip_address} blocked for {reason}")
            
        except Exception as e:
            self.logger.error(f"Error blocking IP: {e}")
    
    def generate_api_key(self, user_id: int, name: str, 
                        permissions: List[str] = None, 
                        expires_days: int = None) -> str:
        """Generate a new API key"""
        try:
            # Generate random API key
            api_key = secrets.token_urlsafe(32)
            key_hash = hashlib.sha256(api_key.encode()).hexdigest()
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            key_id = secrets.token_hex(8)
            expires_at = None
            if expires_days:
                expires_at = datetime.now() + timedelta(days=expires_days)
            
            cursor.execute('''
                INSERT INTO api_keys 
                (key_id, user_id, key_hash, name, permissions, expires_at)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                key_id,
                user_id,
                key_hash,
                name,
                json.dumps(permissions or ['read']),
                expires_at.isoformat() if expires_at else None
            ))
            
            conn.commit()
            conn.close()
            
            self.log_security_event(
                event_type='api_key_created',
                severity='info',
                source_ip='system',
                user_id=str(user_id),
                details={'key_id': key_id, 'name': name}
            )
            
            return api_key
            
        except Exception as e:
            self.logger.error(f"Error generating API key: {e}")
            return None
    
    def validate_api_key(self, api_key: str) -> Dict[str, Any]:
        """Validate API key and return user info"""
        try:
            key_hash = hashlib.sha256(api_key.encode()).hexdigest()
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT ak.user_id, ak.permissions, ak.is_active, ak.expires_at, u.username, u.role
                FROM api_keys ak
                JOIN users u ON ak.user_id = u.id
                WHERE ak.key_hash = ?
            ''', (key_hash,))
            
            result = cursor.fetchone()
            conn.close()
            
            if not result:
                return {'valid': False, 'error': 'Invalid API key'}
            
            user_id, permissions, is_active, expires_at, username, role = result
            
            if not is_active:
                return {'valid': False, 'error': 'API key is deactivated'}
            
            if expires_at:
                expires_dt = datetime.fromisoformat(expires_at)
                if datetime.now() > expires_dt:
                    return {'valid': False, 'error': 'API key has expired'}
            
            # Update last used
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                UPDATE api_keys SET last_used = CURRENT_TIMESTAMP
                WHERE key_hash = ?
            ''', (key_hash,))
            conn.commit()
            conn.close()
            
            return {
                'valid': True,
                'user_id': user_id,
                'username': username,
                'role': role,
                'permissions': json.loads(permissions)
            }
            
        except Exception as e:
            self.logger.error(f"Error validating API key: {e}")
            return {'valid': False, 'error': 'System error'}
    
    def moderate_content(self, content: str, content_id: str) -> Dict[str, Any]:
        """Moderate content for spam and inappropriate content"""
        try:
            # Spam detection (simplified)
            spam_score = self._calculate_spam_score(content)
            
            # Check for flagged keywords
            flagged_keywords = self._check_flagged_keywords(content)
            
            # Determine moderation status
            if spam_score > 0.8 or len(flagged_keywords) > 3:
                status = 'rejected'
                reason = 'High spam score or inappropriate content'
            elif spam_score > 0.5 or len(flagged_keywords) > 1:
                status = 'flagged'
                reason = 'Medium risk content'
            else:
                status = 'approved'
                reason = 'Clean content'
            
            # Store moderation result
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO content_moderation 
                (content_id, moderation_status, flagged_keywords, spam_score, moderation_reason)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                content_id,
                status,
                json.dumps(flagged_keywords),
                spam_score,
                reason
            ))
            
            conn.commit()
            conn.close()
            
            if status in ['rejected', 'flagged']:
                self.log_security_event(
                    event_type='content_flagged',
                    severity='medium' if status == 'flagged' else 'high',
                    source_ip='system',
                    details={
                        'content_id': content_id,
                        'status': status,
                        'spam_score': spam_score,
                        'flagged_keywords': flagged_keywords
                    }
                )
            
            return {
                'status': status,
                'spam_score': spam_score,
                'flagged_keywords': flagged_keywords,
                'reason': reason
            }
            
        except Exception as e:
            self.logger.error(f"Error moderating content: {e}")
            return {'status': 'error', 'reason': str(e)}
    
    def _calculate_spam_score(self, content: str) -> float:
        """Calculate spam score for content (simplified)"""
        content_lower = content.lower()
        
        # Spam indicators
        spam_indicators = [
            'buy now', 'click here', 'free', 'urgent', 'limited time',
            'act now', 'don\'t miss', 'exclusive offer', 'promotion',
            'money back', 'guarantee', 'no risk'
        ]
        
        # Count spam indicators
        spam_count = sum(1 for indicator in spam_indicators if indicator in content_lower)
        
        # Check for excessive capitalization
        capital_ratio = sum(1 for c in content if c.isupper()) / len(content) if content else 0
        
        # Check for excessive punctuation
        punctuation_ratio = sum(1 for c in content if c in '!?') / len(content) if content else 0
        
        # Calculate score
        spam_score = (
            spam_count * 0.1 +
            capital_ratio * 0.3 +
            punctuation_ratio * 0.4
        )
        
        return min(1.0, spam_score)
    
    def _check_flagged_keywords(self, content: str) -> List[str]:
        """Check for flagged keywords in content"""
        content_lower = content.lower()
        
        # Flagged keywords (example list)
        flagged_keywords = [
            'spam', 'scam', 'fake', 'bot', 'automated',
            'inappropriate', 'offensive', 'harassment'
        ]
        
        found_keywords = []
        for keyword in flagged_keywords:
            if keyword in content_lower:
                found_keywords.append(keyword)
        
        return found_keywords
    
    def generate_jwt_token(self, user_id: int, username: str, role: str, 
                         expires_hours: int = 24) -> str:
        """Generate JWT token for user"""
        payload = {
            'user_id': user_id,
            'username': username,
            'role': role,
            'exp': datetime.utcnow() + timedelta(hours=expires_hours),
            'iat': datetime.utcnow()
        }
        
        token = jwt.encode(payload, self.jwt_secret, algorithm='HS256')
        return token
    
    def verify_jwt_token(self, token: str) -> Dict[str, Any]:
        """Verify JWT token and return payload"""
        try:
            payload = jwt.decode(token, self.jwt_secret, algorithms=['HS256'])
            return {'valid': True, 'payload': payload}
        except jwt.ExpiredSignatureError:
            return {'valid': False, 'error': 'Token has expired'}
        except jwt.InvalidTokenError:
            return {'valid': False, 'error': 'Invalid token'}
    
    def get_security_stats(self) -> Dict[str, Any]:
        """Get security statistics"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Count recent security events
            cursor.execute('''
                SELECT 
                    COUNT(CASE WHEN severity = 'high' THEN 1 END) as high_risk,
                    COUNT(CASE WHEN severity = 'medium' THEN 1 END) as medium_risk,
                    COUNT(CASE WHEN severity = 'low' THEN 1 END) as low_risk,
                    COUNT(CASE WHEN event_type = 'failed_login' THEN 1 END) as failed_logins,
                    COUNT(CASE WHEN event_type = 'ip_blocked' THEN 1 END) as blocked_ips
                FROM security_events 
                WHERE timestamp >= datetime('now', '-24 hours')
            ''')
            
            result = cursor.fetchone()
            conn.close()
            
            return {
                'high_risk_events': result[0] or 0,
                'medium_risk_events': result[1] or 0,
                'low_risk_events': result[2] or 0,
                'failed_logins_24h': result[3] or 0,
                'blocked_ips_24h': result[4] or 0,
                'total_events_24h': sum(result[:3]) if result else 0
            }
            
        except Exception as e:
            self.logger.error(f"Error getting security stats: {e}")
            return {}

# Global security manager instance
security_manager = SecurityManager()

def main():
    """Test the security manager"""
    # Test password validation
    password = "TestPassword123!"
    validation = security_manager.validate_password(password)
    print(f"Password validation: {validation}")
    
    # Test password hashing
    password_hash = security_manager.hash_password(password)
    print(f"Password hash: {password_hash[:50]}...")
    
    # Test password verification
    is_valid = security_manager.verify_password(password, password_hash)
    print(f"Password verification: {is_valid}")
    
    # Test rate limiting
    rate_limit = security_manager.check_rate_limit("test_user", "login_attempts")
    print(f"Rate limit check: {rate_limit}")
    
    # Test content moderation
    content = "Check out this amazing offer! Click here now for free stuff!!!"
    moderation = security_manager.moderate_content(content, "test_content_1")
    print(f"Content moderation: {moderation}")
    
    # Test JWT token
    token = security_manager.generate_jwt_token(1, "testuser", "user")
    print(f"JWT token: {token[:50]}...")
    
    # Test token verification
    verification = security_manager.verify_jwt_token(token)
    print(f"Token verification: {verification}")
    
    # Test security stats
    stats = security_manager.get_security_stats()
    print(f"Security stats: {stats}")

if __name__ == "__main__":
    main()