"""
UltraBot Core Service
Главный процесс управления всей системой
"""

import asyncio
import signal
import sys
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from pathlib import Path

from config import config
from scheduler import TaskScheduler
from resource_manager import ResourceManager
from self_healing import SelfHealingSystem
from database.models import DatabaseManager

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOGS_DIR / 'core.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class SystemStatus:
    """Статус системы"""
    is_running: bool = False
    start_time: Optional[datetime] = None
    uptime: Optional[timedelta] = None
    memory_usage: float = 0.0
    cpu_usage: float = 0.0
    active_services: List[str] = None
    last_health_check: Optional[datetime] = None

class UltraBotCore:
    """Главный класс управления UltraBot"""
    
    def __init__(self):
        self.status = SystemStatus()
        self.scheduler = TaskScheduler()
        self.resource_manager = ResourceManager()
        self.healing_system = SelfHealingSystem()
        self.db_manager = DatabaseManager()
        
        # Флаги управления
        self._shutdown_event = asyncio.Event()
        self._restart_event = asyncio.Event()
        self._emergency_stop = False
        
        # Сервисы
        self.services = {
            'parser': None,
            'editor': None,
            'publisher': None,
            'ml': None,
            'monitoring': None,
            'web_panel': None
        }
        
        logger.info("UltraBot Core инициализирован")
    
    async def start(self):
        """Запуск системы"""
        try:
            logger.info("Запуск UltraBot Core...")
            
            # Инициализация базы данных
            await self._init_database()
            
            # Проверка конфигурации
            await self._validate_configuration()
            
            # Запуск системы самовосстановления
            await self.healing_system.start()
            
            # Запуск планировщика задач
            await self.scheduler.start()
            
            # Запуск менеджера ресурсов
            await self.resource_manager.start()
            
            # Инициализация сервисов
            await self._init_services()
            
            # Обновление статуса
            self.status.is_running = True
            self.status.start_time = datetime.now()
            
            logger.info("UltraBot Core успешно запущен")
            
            # Запуск основного цикла
            await self._main_loop()
            
        except Exception as e:
            logger.error(f"Ошибка при запуске Core: {e}")
            await self._emergency_shutdown()
            raise
    
    async def stop(self):
        """Остановка системы"""
        logger.info("Остановка UltraBot Core...")
        
        self.status.is_running = False
        self._shutdown_event.set()
        
        # Остановка сервисов
        await self._stop_services()
        
        # Остановка компонентов
        await self.scheduler.stop()
        await self.resource_manager.stop()
        await self.healing_system.stop()
        
        # Закрытие соединений
        await self.db_manager.close()
        
        logger.info("UltraBot Core остановлен")
    
    async def restart(self):
        """Перезапуск системы"""
        logger.info("Перезапуск UltraBot Core...")
        await self.stop()
        await asyncio.sleep(5)
        await self.start()
    
    async def emergency_stop(self):
        """Экстренная остановка"""
        logger.critical("Экстренная остановка системы!")
        self._emergency_stop = True
        self._shutdown_event.set()
        
        # Немедленная остановка всех процессов
        for service_name, service in self.services.items():
            if service and hasattr(service, 'emergency_stop'):
                try:
                    await service.emergency_stop()
                except Exception as e:
                    logger.error(f"Ошибка при экстренной остановке {service_name}: {e}")
        
        # Принудительный выход
        sys.exit(1)
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса системы"""
        # Обновление uptime
        if self.status.start_time:
            self.status.uptime = datetime.now() - self.status.start_time
        
        # Получение метрик ресурсов
        resource_metrics = await self.resource_manager.get_metrics()
        self.status.memory_usage = resource_metrics.get('memory_usage', 0)
        self.status.cpu_usage = resource_metrics.get('cpu_usage', 0)
        
        # Получение активных сервисов
        self.status.active_services = [
            name for name, service in self.services.items() 
            if service and hasattr(service, 'is_running') and service.is_running
        ]
        
        self.status.last_health_check = datetime.now()
        
        return {
            'system': {
                'is_running': self.status.is_running,
                'uptime': str(self.status.uptime) if self.status.uptime else None,
                'start_time': self.status.start_time.isoformat() if self.status.start_time else None,
                'memory_usage': self.status.memory_usage,
                'cpu_usage': self.status.cpu_usage,
                'active_services': self.status.active_services
            },
            'services': await self._get_services_status(),
            'database': await self._get_database_status(),
            'scheduler': await self.scheduler.get_status(),
            'resources': resource_metrics,
            'health': await self.healing_system.get_health_status()
        }
    
    async def _init_database(self):
        """Инициализация базы данных"""
        try:
            await self.db_manager.initialize()
            logger.info("База данных инициализирована")
        except Exception as e:
            logger.error(f"Ошибка инициализации БД: {e}")
            raise
    
    async def _validate_configuration(self):
        """Проверка конфигурации"""
        validation_result = config.validate_config()
        
        if not validation_result['is_valid']:
            logger.error(f"Ошибки конфигурации: {validation_result['errors']}")
            raise ValueError("Недопустимая конфигурация")
        
        if validation_result['warnings']:
            logger.warning(f"Предупреждения конфигурации: {validation_result['warnings']}")
        
        logger.info("Конфигурация проверена")
    
    async def _init_services(self):
        """Инициализация сервисов"""
        # Запуск сервисов по мере необходимости
        # Каждый сервис запускается отдельно через Docker
        logger.info("Сервисы инициализированы для работы в Docker")
    
    async def _stop_services(self):
        """Остановка сервисов"""
        for service_name, service in self.services.items():
            if service and hasattr(service, 'stop'):
                try:
                    await service.stop()
                    logger.info(f"Сервис {service_name} остановлен")
                except Exception as e:
                    logger.error(f"Ошибка при остановке {service_name}: {e}")
    
    async def _main_loop(self):
        """Главный цикл работы системы"""
        logger.info("Запуск главного цикла...")
        
        while not self._shutdown_event.is_set() and not self._emergency_stop:
            try:
                # Периодическая проверка состояния
                await self._periodic_check()
                
                # Обработка задач
                await self._process_tasks()
                
                # Ожидание следующего цикла
                await asyncio.sleep(10)
                
            except asyncio.CancelledError:
                logger.info("Главный цикл отменен")
                break
            except Exception as e:
                logger.error(f"Ошибка в главном цикле: {e}")
                await asyncio.sleep(5)
    
    async def _periodic_check(self):
        """Периодическая проверка системы"""
        # Проверка ресурсов
        if self.resource_manager.is_overloaded():
            logger.warning("Система перегружена, принятие мер...")
            await self._handle_overload()
        
        # Проверка здоровья
        health_status = await self.healing_system.get_health_status()
        if not health_status.get('is_healthy', True):
            logger.warning("Обнаружены проблемы со здоровьем системы")
            await self._handle_health_issues(health_status)
        
        # Обновление статистики
        await self._update_statistics()
    
    async def _process_tasks(self):
        """Обработка фоновых задач"""
        # Обработка задач из очереди
        pending_tasks = await self.scheduler.get_pending_tasks()
        
        for task in pending_tasks:
            try:
                await self._execute_task(task)
            except Exception as e:
                logger.error(f"Ошибка при выполнении задачи {task.get('id')}: {e}")
    
    async def _execute_task(self, task: Dict[str, Any]):
        """Выполнение задачи"""
        task_type = task.get('type')
        
        if task_type == 'health_check':
            await self.healing_system.perform_health_check()
        elif task_type == 'resource_cleanup':
            await self.resource_manager.cleanup()
        elif task_type == 'backup':
            await self._create_backup()
        elif task_type == 'analytics_update':
            await self._update_analytics()
        else:
            logger.warning(f"Неизвестный тип задачи: {task_type}")
    
    async def _handle_overload(self):
        """Обработка перегрузки системы"""
        logger.warning("Обработка перегрузки системы...")
        
        # Уменьшение количества активных задач
        await self.scheduler.reduce_load()
        
        # Очистка кэша
        await self.resource_manager.clear_cache()
        
        # Оповещение администратора
        await self._send_admin_alert("System overload detected")
    
    async def _handle_health_issues(self, health_status: Dict[str, Any]):
        """Обработка проблем со здоровьем системы"""
        logger.warning("Обработка проблем со здоровьем...")
        
        issues = health_status.get('issues', [])
        
        for issue in issues:
            if issue.get('severity') == 'critical':
                await self._send_admin_alert(f"Critical health issue: {issue.get('message')}")
                
                if issue.get('requires_restart', False):
                    logger.info("Требуется перезапуск системы...")
                    await self.restart()
                    break
    
    async def _update_statistics(self):
        """Обновление статистики"""
        # Сбор статистики от всех компонентов
        stats = {
            'timestamp': datetime.now().isoformat(),
            'uptime': str(self.status.uptime) if self.status.uptime else None,
            'memory_usage': self.status.memory_usage,
            'cpu_usage': self.status.cpu_usage
        }
        
        # Сохранение в базу данных
        await self.db_manager.save_statistics(stats)
    
    async def _update_analytics(self):
        """Обновление аналитики"""
        # Обновление ML аналитики
        logger.info("Обновление аналитики...")
        
    async def _create_backup(self):
        """Создание резервной копии"""
        logger.info("Создание резервной копии...")
        try:
            await self.db_manager.create_backup()
            logger.info("Резервная копия создана успешно")
        except Exception as e:
            logger.error(f"Ошибка при создании резервной копии: {e}")
    
    async def _send_admin_alert(self, message: str):
        """Отправка оповещения администратору"""
        logger.critical(f"ADMIN ALERT: {message}")
        # Здесь можно добавить отправку через Telegram, Email и т.д.
    
    async def _get_services_status(self) -> Dict[str, Any]:
        """Получение статуса сервисов"""
        status = {}
        for service_name, service in self.services.items():
            if service and hasattr(service, 'get_status'):
                try:
                    status[service_name] = await service.get_status()
                except Exception as e:
                    status[service_name] = {'error': str(e), 'status': 'error'}
            else:
                status[service_name] = {'status': 'not_initialized'}
        return status
    
    async def _get_database_status(self) -> Dict[str, Any]:
        """Получение статуса базы данных"""
        try:
            return await self.db_manager.get_status()
        except Exception as e:
            return {'error': str(e), 'status': 'error'}

# Обработка сигналов
def signal_handler(signum, frame):
    """Обработчик системных сигналов"""
    logger.info(f"Получен сигнал {signum}")
    
    if signum == signal.SIGTERM:
        # Graceful shutdown
        asyncio.create_task(core.stop())
    elif signum == signal.SIGINT:
        # Interrupt (Ctrl+C)
        asyncio.create_task(core.stop())
    elif signum == signal.SIGHUP:
        # Reload configuration
        asyncio.create_task(core.restart())

# Глобальный экземпляр
core = UltraBotCore()

async def main():
    """Главная функция"""
    # Установка обработчиков сигналов
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGHUP, signal_handler)
    
    try:
        await core.start()
    except KeyboardInterrupt:
        logger.info("Получено прерывание от пользователя")
        await core.stop()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        await core.emergency_stop()

if __name__ == "__main__":
    asyncio.run(main())