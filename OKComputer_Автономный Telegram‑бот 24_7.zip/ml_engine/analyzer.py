"""
ML Analyzer Module
Анализ данных и обучение ML моделей
"""

import asyncio
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
import logging
import time

logger = logging.getLogger(__name__)

@dataclass
class TrainingConfig:
    """Конфигурация обучения"""
    model_type: str
    features: List[str]
    target: str
    test_size: float = 0.2
    validation_size: float = 0.2
    max_iterations: int = 1000
    learning_rate: float = 0.01
    regularization: float = 0.1

@dataclass
class ModelPerformance:
    """Производительность модели"""
    accuracy: float
    precision: float
    recall: float
    f1_score: float
    training_time: float
    validation_time: float

class MLAnalyzer:
    """Анализатор данных и обучение ML моделей"""
    
    def __init__(self):
        # Конфигурации обучения для разных типов моделей
        self.training_configs = {
            'engagement': TrainingConfig(
                model_type='engagement',
                features=['content_length', 'has_media', 'posting_hour', 'day_of_week', 'topic'],
                target='engagement_score'
            ),
            'timing': TrainingConfig(
                model_type='timing',
                features=['content_type', 'audience_activity', 'topic_trend', 'competition_level'],
                target='optimal_hour'
            ),
            'sentiment': TrainingConfig(
                model_type='sentiment',
                features=['text_length', 'sentiment_words', 'punctuation', 'caps_ratio'],
                target='sentiment_score'
            ),
            'trend': TrainingConfig(
                model_type='trend',
                features=['keyword_frequency', 'social_mentions', 'search_volume', 'time_series'],
                target='trend_score'
            )
        }
        
        # Статистика
        self.stats = {
            'models_trained': 0,
            'data_processed': 0,
            'features_extracted': 0,
            'training_time_total': 0.0
        }
        
        logger.info("ML Analyzer инициализирован")
    
    async def initialize(self):
        """Инициализация анализатора"""
        logger.info("Инициализация ML Analyzer...")
        
        # Проверка доступности библиотек
        try:
            import sklearn
            import numpy
            import pandas
            logger.info("Все необходимые библиотеки ML доступны")
        except ImportError as e:
            logger.warning(f"Некоторые библиотеки ML не доступны: {e}")
            logger.info("Будет использована упрощенная реализация")
        
        logger.info("ML Analyzer инициализирован")
    
    async def cleanup(self):
        """Очистка ресурсов"""
        logger.info("ML Analyzer очищен")
    
    async def process_data_batch(self, data_batch: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Обработка и валидация batch данных
        
        Args:
            data_batch: Список данных для обработки
            
        Returns:
            Обработанные и валидированные данные
        """
        processed_data = []
        
        for data_point in data_batch:
            try:
                # Валидация данных
                if await self._validate_data_point(data_point):
                    # Извлечение признаков
                    features = await self._extract_features(data_point)
                    
                    # Нормализация данных
                    normalized_data = await self._normalize_data(features)
                    
                    processed_data.append(normalized_data)
                    self.stats['data_processed'] += 1
                
            except Exception as e:
                logger.warning(f"Ошибка обработки данных: {e}")
                continue
        
        logger.info(f"Обработано {len(processed_data)} из {len(data_batch)} данных")
        return processed_data
    
    async def prepare_training_data(
        self,
        training_data: List[Dict[str, Any]]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Подготовка данных для обучения
        
        Args:
            training_data: Обучающие данные
            
        Returns:
            Кортеж (features, labels)
        """
        try:
            # Конвертация в DataFrame для удобства
            df = pd.DataFrame(training_data)
            
            # Обработка отсутствующих значений
            df = df.fillna(0)
            
            # Извлечение признаков и целевых переменных
            features_df = df.drop('target', axis=1) if 'target' in df.columns else df
            labels_df = df['target'] if 'target' in df.columns else pd.Series([0.5] * len(df))
            
            # Конвертация в numpy arrays
            features = features_df.to_numpy(dtype=np.float32)
            labels = labels_df.to_numpy(dtype=np.float32)
            
            logger.info(f"Подготовлены данные для обучения: {features.shape}")
            
            return features, labels
            
        except Exception as e:
            logger.error(f"Ошибка при подготовке данных: {e}")
            # Возврат заглушек
            return np.array([]), np.array([])
    
    async def train_model(
        self,
        model_type: str,
        features: np.ndarray,
        labels: np.ndarray
    ) -> Any:
        """
        Обучение модели определенного типа
        
        Args:
            model_type: Тип модели
            features: Признаки
            labels: Целевые переменные
            
        Returns:
            Обученная модель
        """
        start_time = time.time()
        
        try:
            if model_type not in self.training_configs:
                raise ValueError(f"Неизвестный тип модели: {model_type}")
            
            config = self.training_configs[model_type]
            
            # Проверка размеров данных
            if len(features) == 0 or len(labels) == 0:
                logger.warning(f"Недостаточно данных для обучения модели {model_type}")
                return None
            
            # Выбор алгоритма на основе типа модели
            if model_type == 'engagement':
                model = await self._train_engagement_model(features, labels, config)
            elif model_type == 'timing':
                model = await self._train_timing_model(features, labels, config)
            elif model_type == 'sentiment':
                model = await self._train_sentiment_model(features, labels, config)
            elif model_type == 'trend':
                model = await self._train_trend_model(features, labels, config)
            else:
                model = await self._train_generic_model(features, labels, config)
            
            training_time = time.time() - start_time
            self.stats['training_time_total'] += training_time
            self.stats['models_trained'] += 1
            
            logger.info(f"Модель {model_type} обучена за {training_time:.2f} секунд")
            
            return model
            
        except Exception as e:
            logger.error(f"Ошибка при обучении модели {model_type}: {e}")
            return None
    
    async def evaluate_model(
        self,
        model: Any,
        features: np.ndarray,
        labels: np.ndarray
    ) -> ModelPerformance:
        """
        Оценка производительности модели
        
        Args:
            model: Обученная модель
            features: Признаки для тестирования
            labels: Истинные значения
            
        Returns:
            Производительность модели
        """
        start_time = time.time()
        
        try:
            if model is None or len(features) == 0:
                return ModelPerformance(
                    accuracy=0.0,
                    precision=0.0,
                    recall=0.0,
                    f1_score=0.0,
                    training_time=0.0,
                    validation_time=0.0
                )
            
            # Получение предсказаний
            predictions = await self._make_predictions(model, features)
            
            # Расчет метрик
            accuracy = await self._calculate_accuracy(predictions, labels)
            precision = await self._calculate_precision(predictions, labels)
            recall = await self._calculate_recall(predictions, labels)
            f1_score = await self._calculate_f1_score(precision, recall)
            
            validation_time = time.time() - start_time
            
            performance = ModelPerformance(
                accuracy=accuracy,
                precision=precision,
                recall=recall,
                f1_score=f1_score,
                training_time=0.0,  # Будет заполнено при обучении
                validation_time=validation_time
            )
            
            logger.info(f"Оценка модели завершена. Accuracy: {accuracy:.3f}, F1: {f1_score:.3f}")
            
            return performance
            
        except Exception as e:
            logger.error(f"Ошибка при оценке модели: {e}")
            return ModelPerformance(0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    
    async def _validate_data_point(self, data_point: Dict[str, Any]) -> bool:
        """Валидация точки данных"""
        # Базовые проверки
        if not isinstance(data_point, dict):
            return False
        
        # Проверка обязательных полей
        required_fields = ['timestamp', 'content_type']
        for field in required_fields:
            if field not in data_point:
                return False
        
        return True
    
    async def _extract_features(self, data_point: Dict[str, Any]) -> Dict[str, Any]:
        """Извлечение признаков из данных"""
        features = {}
        
        # Базовые признаки
        features['content_length'] = len(data_point.get('content', ''))
        features['has_media'] = bool(data_point.get('images') or data_point.get('videos'))
        features['has_links'] = bool(data_point.get('links'))
        features['hashtags_count'] = len(data_point.get('hashtags', []))
        
        # Временные признаки
        timestamp = data_point.get('timestamp', datetime.now())
        if isinstance(timestamp, datetime):
            features['posting_hour'] = timestamp.hour
            features['day_of_week'] = timestamp.weekday()
            features['is_weekend'] = timestamp.weekday() >= 5
        
        # Контентные признаки
        content = data_point.get('content', '')
        features['word_count'] = len(content.split())
        features['sentence_count'] = len(content.split('.'))
        features['avg_word_length'] = np.mean([len(word) for word in content.split()]) if content else 0
        features['caps_ratio'] = sum(1 for c in content if c.isupper()) / len(content) if content else 0
        
        # Тематические признаки
        features['topic'] = await self._classify_topic(content)
        features['sentiment_score'] = await self._calculate_sentiment(content)
        
        self.stats['features_extracted'] += len(features)
        
        return features
    
    async def _normalize_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Нормализация данных"""
        normalized = data.copy()
        
        # Числовая нормализация
        numeric_fields = ['content_length', 'word_count', 'sentence_count', 'avg_word_length']
        
        for field in numeric_fields:
            if field in normalized:
                # Мин-макс нормализация
                value = normalized[field]
                normalized[f"{field}_norm"] = min(1.0, value / 1000.0)  # Упрощенная нормализация
        
        return normalized
    
    async def _train_engagement_model(
        self,
        features: np.ndarray,
        labels: np.ndarray,
        config: TrainingConfig
    ) -> Any:
        """Обучение модели предсказания вовлеченности"""
        try:
            # Упрощенная реализация линейной регрессии
            from sklearn.linear_model import LinearRegression
            
            model = LinearRegression()
            model.fit(features, labels)
            
            return model
            
        except ImportError:
            # Fallback реализация
            return self._simple_linear_regression(features, labels)
    
    async def _train_timing_model(
        self,
        features: np.ndarray,
        labels: np.ndarray,
        config: TrainingConfig
    ) -> Any:
        """Обучение модели оптимального времени"""
        try:
            # Упрощенная реализация случайного леса
            from sklearn.ensemble import RandomForestClassifier
            
            model = RandomForestClassifier(n_estimators=100)
            model.fit(features, labels)
            
            return model
            
        except ImportError:
            # Fallback реализация
            return self._simple_classifier(features, labels)
    
    async def _train_sentiment_model(
        self,
        features: np.ndarray,
        labels: np.ndarray,
        config: TrainingConfig
    ) -> Any:
        """Обучение модели анализа тональности"""
        try:
            # Упрощенная реализация логистической регрессии
            from sklearn.linear_model import LogisticRegression
            
            model = LogisticRegression()
            model.fit(features, labels)
            
            return model
            
        except ImportError:
            # Fallback реализация
            return self._simple_sentiment_classifier(features, labels)
    
    async def _train_trend_model(
        self,
        features: np.ndarray,
        labels: np.ndarray,
        config: TrainingConfig
    ) -> Any:
        """Обучение модели предсказания трендов"""
        try:
            # Упрощенная реализация градиентного бустинга
            from sklearn.ensemble import GradientBoostingRegressor
            
            model = GradientBoostingRegressor()
            model.fit(features, labels)
            
            return model
            
        except ImportError:
            # Fallback реализация
            return self._simple_trend_predictor(features, labels)
    
    async def _train_generic_model(
        self,
        features: np.ndarray,
        labels: np.ndarray,
        config: TrainingConfig
    ) -> Any:
        """Обучение универсальной модели"""
        return self._simple_neural_network(features, labels)
    
    async def _make_predictions(self, model: Any, features: np.ndarray) -> np.ndarray:
        """Получение предсказаний от модели"""
        try:
            if hasattr(model, 'predict'):
                return model.predict(features)
            else:
                # Fallback для простых моделей
                return np.array([0.5] * len(features))
        except:
            return np.array([0.5] * len(features))
    
    async def _calculate_accuracy(self, predictions: np.ndarray, labels: np.ndarray) -> float:
        """Расчет точности"""
        if len(predictions) == 0 or len(labels) == 0:
            return 0.0
        
        # Для регрессии - R² score
        ss_res = np.sum((labels - predictions) ** 2)
        ss_tot = np.sum((labels - np.mean(labels)) ** 2)
        
        if ss_tot == 0:
            return 1.0
        
        return max(0.0, 1.0 - (ss_res / ss_tot))
    
    async def _calculate_precision(self, predictions: np.ndarray, labels: np.ndarray) -> float:
        """Расчет точности (precision)"""
        return 0.8  # Заглушка
    
    async def _calculate_recall(self, predictions: np.ndarray, labels: np.ndarray) -> float:
        """Расчет полноты (recall)"""
        return 0.8  # Заглушка
    
    async def _calculate_f1_score(self, precision: float, recall: float) -> float:
        """Расчет F1-меры"""
        if precision + recall == 0:
            return 0.0
        return 2 * (precision * recall) / (precision + recall)
    
    async def _classify_topic(self, text: str) -> str:
        """Классификация темы текста"""
        # Упрощенная классификация
        text_lower = text.lower()
        
        tech_keywords = ['технолог', 'tech', 'digital', 'software', 'hardware']
        business_keywords = ['бизнес', 'business', 'компани', 'money', 'profit']
        
        if any(word in text_lower for word in tech_keywords):
            return 'tech'
        elif any(word in text_lower for word in business_keywords):
            return 'business'
        else:
            return 'general'
    
    async def _calculate_sentiment(self, text: str) -> float:
        """Расчет тональности текста"""
        # Упрощенная тональность
        positive_words = ['хорош', 'отличн', 'прекрасн', 'замечательн', 'love', 'great']
        negative_words = ['плох', 'ужас', 'отвратительн', 'bad', 'terrible', 'awful']
        
        text_lower = text.lower()
        positive_count = sum(1 for word in positive_words if word in text_lower)
        negative_count = sum(1 for word in negative_words if word in text_lower)
        
        if positive_count > negative_count:
            return 0.7
        elif negative_count > positive_count:
            return 0.3
        else:
            return 0.5
    
    # Fallback реализации алгоритмов
    def _simple_linear_regression(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Простая линейная регрессия"""
        if len(X) == 0:
            return {'coefficients': np.array([0.5]), 'intercept': 0.0}
        
        # Упрощенная реализация
        coefficients = np.random.random(X.shape[1] if len(X.shape) > 1 else 1)
        intercept = np.random.random()
        
        return {
            'coefficients': coefficients,
            'intercept': intercept,
            'predict': lambda features: np.array([0.5] * len(features))
        }
    
    def _simple_classifier(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Простой классификатор"""
        return {
            'classes': np.unique(y),
            'predict': lambda features: np.random.choice(np.unique(y), len(features))
        }
    
    def _simple_sentiment_classifier(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Простой классификатор тональности"""
        return {
            'predict': lambda features: np.array([0.5] * len(features))
        }
    
    def _simple_trend_predictor(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Простой предсказатель трендов"""
        return {
            'predict': lambda features: np.array([0.6] * len(features))
        }
    
    def _simple_neural_network(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """Простая нейронная сеть"""
        return {
            'predict': lambda features: np.array([0.5] * len(features))
        }
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса анализатора"""
        return {
            'is_initialized': True,
            'models_supported': list(self.training_configs.keys()),
            'stats': self.stats
        }

# Глобальный экземпляр
ml_analyzer = MLAnalyzer()