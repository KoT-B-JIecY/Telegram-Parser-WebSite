"""
Translator Module
Перевод контента на разные языки с помощью ML моделей
"""

import asyncio
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging
import time

logger = logging.getLogger(__name__)

@dataclass
class TranslationResult:
    """Результат перевода"""
    original_text: str
    translated_text: str
    source_language: str
    target_language: str
    confidence: float
    translation_time: float
    alternatives: List[str] = None

@dataclass
class LanguagePair:
    """Пара языков для перевода"""
    source: str
    target: str
    confidence: float

class Translator:
    """Переводчик контента"""
    
    def __init__(self):
        # Поддерживаемые языки
        self.supported_languages = {
            'ru': 'Russian',
            'en': 'English',
            'es': 'Spanish',
            'de': 'German',
            'fr': 'French',
            'it': 'Italian',
            'pt': 'Portuguese',
            'zh': 'Chinese',
            'ja': 'Japanese',
            'ko': 'Korean',
            'ar': 'Arabic',
            'hi': 'Hindi',
            'tr': 'Turkish',
            'pl': 'Polish',
            'uk': 'Ukrainian'
        }
        
        # Настройки перевода
        self.translation_settings = {
            'preserve_formatting': True,
            'maintain_tone': True,
            'use_context': True,
            'max_text_length': 5000,
            'batch_size': 10
        }
        
        # Кэш переводов
        self._translation_cache: Dict[str, TranslationResult] = {}
        self._cache_ttl = 86400  # 24 часа
        
        # Статистика
        self.stats = {
            'translations_made': 0,
            'characters_translated': 0,
            'cache_hits': 0,
            'cache_misses': 0,
            'avg_translation_time': 0.0,
            'most_used_pairs': {}
        }
        
        # Модели перевода (в реальном приложении - загрузка из transformers)
        self.translation_models = {}
        
        logger.info("Translator инициализирован")
    
    async def initialize(self):
        """Инициализация переводчика"""
        try:
            logger.info("Инициализация моделей перевода...")
            
            # В реальном приложении здесь загрузка моделей
            # Например: MarianMTModel, Helsinki-NLP models
            
            logger.info("Модели перевода инициализированы")
            
        except Exception as e:
            logger.error(f"Ошибка при инициализации переводчика: {e}")
            # Использование заглушек
            self._initialize_dummy_models()
    
    async def cleanup(self):
        """Очистка ресурсов"""
        # Очистка кэша
        self._translation_cache.clear()
        logger.info("Translator очищен")
    
    async def translate_content(
        self,
        content: Dict[str, Any],
        target_language: str,
        source_language: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Перевод контента на указанный язык
        
        Args:
            content: Контент для перевода
            target_language: Целевой язык
            source_language: Исходный язык (определяется автоматически)
            
        Returns:
            Переведенный контент
        """
        start_time = time.time()
        
        try:
            # Проверка поддержки языка
            if target_language not in self.supported_languages:
                logger.warning(f"Язык {target_language} не поддерживается")
                return content
            
            # Определение исходного языка
            if not source_language:
                source_language = await self._detect_language(
                    f"{content.get('title', '')} {content.get('content', '')}"
                )
            
            # Проверка необходимости перевода
            if source_language == target_language:
                return content
            
            # Формирование ключа для кэша
            cache_key = self._generate_cache_key(content, source_language, target_language)
            
            # Проверка кэша
            if cache_key in self._translation_cache:
                self.stats['cache_hits'] += 1
                cached_result = self._translation_cache[cache_key]
                logger.debug("Перевод взят из кэша")
                return self._apply_translation_result(content, cached_result)
            
            self.stats['cache_misses'] += 1
            
            # Перевод основных элементов
            translated_content = content.copy()
            
            # Перевод заголовка
            if content.get('title'):
                title_result = await self._translate_text(
                    content['title'],
                    source_language,
                    target_language
                )
                translated_content['title'] = title_result.translated_text
            
            # Перевод основного контента
            if content.get('content'):
                content_result = await self._translate_text(
                    content['content'],
                    source_language,
                    target_language
                )
                translated_content['content'] = content_result.translated_text
            
            # Перевод тегов
            if content.get('tags'):
                translated_tags = []
                for tag in content['tags']:
                    tag_result = await self._translate_text(
                        tag,
                        source_language,
                        target_language
                    )
                    translated_tags.append(tag_result.translated_text)
                translated_content['tags'] = translated_tags
            
            # Перевод summary
            if content.get('summary'):
                summary_result = await self._translate_text(
                    content['summary'],
                    source_language,
                    target_language
                )
                translated_content['summary'] = summary_result.translated_text
            
            # Обновление метаинформации
            translated_content['original_language'] = source_language
            translated_content['translated_to'] = target_language
            translated_content['translation_confidence'] = min(
                title_result.confidence if 'title' in locals() else 0.8,
                content_result.confidence if 'content' in locals() else 0.8
            )
            
            # Кэширование результата
            translation_result = TranslationResult(
                original_text=f"{content.get('title', '')} {content.get('content', '')}",
                translated_text=f"{translated_content.get('title', '')} {translated_content.get('content', '')}",
                source_language=source_language,
                target_language=target_language,
                confidence=translated_content['translation_confidence'],
                translation_time=time.time() - start_time
            )
            
            self._translation_cache[cache_key] = translation_result
            
            # Обновление статистики
            self.stats['translations_made'] += 1
            total_chars = sum(len(str(value)) for value in content.values() if isinstance(value, str))
            self.stats['characters_translated'] += total_chars
            
            translation_time = time.time() - start_time
            self.stats['avg_translation_time'] = (
                (self.stats['avg_translation_time'] * (self.stats['translations_made'] - 1) + translation_time) /
                self.stats['translations_made']
            )
            
            # Обновление статистики языковых пар
            lang_pair = f"{source_language}->{target_language}"
            self.stats['most_used_pairs'][lang_pair] = self.stats['most_used_pairs'].get(lang_pair, 0) + 1
            
            logger.info(f"Перевод завершен за {translation_time:.2f} секунд")
            return translated_content
            
        except Exception as e:
            logger.error(f"Ошибка при переводе: {e}")
            return content
    
    async def _translate_text(
        self,
        text: str,
        source_lang: str,
        target_lang: str
    ) -> TranslationResult:
        """Перевод отдельного текста"""
        start_time = time.time()
        
        if not text.strip():
            return TranslationResult(
                original_text=text,
                translated_text=text,
                source_language=source_lang,
                target_language=target_lang,
                confidence=1.0,
                translation_time=0.0
            )
        
        try:
            # Проверка длины текста
            if len(text) > self.translation_settings['max_text_length']:
                # Разделение на части для длинных текстов
                return await self._translate_long_text(text, source_lang, target_lang)
            
            # Получение модели перевода
            model_key = f"{source_lang}_{target_lang}"
            
            if model_key in self.translation_models:
                # Использование загруженной модели
                model = self.translation_models[model_key]
                
                if asyncio.iscoroutinefunction(model.translate):
                    translated = await model.translate(text)
                else:
                    translated = model.translate(text)
                
                confidence = getattr(model, 'confidence', 0.8)
                
            else:
                # Использование API или заглушки
                translated = await self._dummy_translate(text, source_lang, target_lang)
                confidence = 0.7
            
            return TranslationResult(
                original_text=text,
                translated_text=translated,
                source_language=source_lang,
                target_language=target_lang,
                confidence=confidence,
                translation_time=time.time() - start_time
            )
            
        except Exception as e:
            logger.error(f"Ошибка при переводе текста: {e}")
            # Fallback - возврат оригинального текста
            return TranslationResult(
                original_text=text,
                translated_text=text,
                source_language=source_lang,
                target_language=target_lang,
                confidence=0.0,
                translation_time=time.time() - start_time
            )
    
    async def _translate_long_text(self, text: str, source_lang: str, target_lang: str) -> TranslationResult:
        """Перевод длинного текста частями"""
        # Разделение на предложения
        sentences = self._split_into_sentences(text)
        
        # Перевод батчами
        translated_parts = []
        total_confidence = 0.0
        start_time = time.time()
        
        for i in range(0, len(sentences), self.translation_settings['batch_size']):
            batch = sentences[i:i + self.translation_settings['batch_size']]
            batch_text = '. '.join(batch)
            
            batch_result = await self._translate_text(batch_text, source_lang, target_lang)
            translated_parts.append(batch_result.translated_text)
            total_confidence += batch_result.confidence
        
        return TranslationResult(
            original_text=text,
            translated_text='. '.join(translated_parts),
            source_language=source_lang,
            target_language=target_lang,
            confidence=total_confidence / len(translated_parts) if translated_parts else 0.0,
            translation_time=time.time() - start_time
        )
    
    async def _detect_language(self, text: str) -> str:
        """Определение языка текста"""
        if not text.strip():
            return 'en'
        
        # Простая проверка на основе символов
        cyrillic_count = sum(1 for char in text.lower() if char in 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя')
        latin_count = sum(1 for char in text.lower() if char in 'abcdefghijklmnopqrstuvwxyz')
        
        if cyrillic_count > latin_count:
            return 'ru'
        else:
            return 'en'
    
    def _split_into_sentences(self, text: str) -> List[str]:
        """Разделение текста на предложения"""
        # Простое разделение по знакам препинания
        sentences = re.split(r'[.!?]+', text)
        return [s.strip() for s in sentences if s.strip()]
    
    def _generate_cache_key(self, content: Dict[str, Any], source_lang: str, target_lang: str) -> str:
        """Генерация ключа для кэширования"""
        import hashlib
        content_str = f"{content.get('title', '')}{content.get('content', '')}{source_lang}{target_lang}"
        return hashlib.md5(content_str.encode()).hexdigest()
    
    def _apply_translation_result(self, content: Dict[str, Any], result: TranslationResult) -> Dict[str, Any]:
        """Применение результата перевода к контенту"""
        # Этот метод используется для применения кэшированных результатов
        # В реальной реализации - более сложная логика
        return content
    
    async def _dummy_translate(self, text: str, source_lang: str, target_lang: str) -> str:
        """Заглушка для перевода (в реальном приложении - интеграция с API)"""
        # Простая транслитерация для демонстрации
        if source_lang == 'ru' and target_lang == 'en':
            # Базовая транслитерация
            translit_map = {
                'а': 'a', 'б': 'b', 'в': 'v', 'г': 'g', 'д': 'd', 'е': 'e', 'ё': 'yo',
                'ж': 'zh', 'з': 'z', 'и': 'i', 'й': 'y', 'к': 'k', 'л': 'l', 'м': 'm',
                'н': 'n', 'о': 'o', 'п': 'p', 'р': 'r', 'с': 's', 'т': 't', 'у': 'u',
                'ф': 'f', 'х': 'kh', 'ц': 'ts', 'ч': 'ch', 'ш': 'sh', 'щ': 'shch',
                'ы': 'y', 'э': 'e', 'ю': 'yu', 'я': 'ya'
            }
            
            result = ''
            for char in text.lower():
                result += translit_map.get(char, char)
            return result
        
        elif source_lang == 'en' and target_lang == 'ru':
            # Базовая обратная транслитерация
            reverse_map = {
                'a': 'а', 'b': 'б', 'v': 'в', 'g': 'г', 'd': 'д', 'e': 'е', 'yo': 'ё',
                'zh': 'ж', 'z': 'з', 'i': 'и', 'y': 'й', 'k': 'к', 'l': 'л', 'm': 'м',
                'n': 'н', 'o': 'о', 'p': 'п', 'r': 'р', 's': 'с', 't': 'т', 'u': 'у',
                'f': 'ф', 'kh': 'х', 'ts': 'ц', 'ch': 'ч', 'sh': 'ш', 'shch': 'щ'
            }
            
            result = ''
            i = 0
            while i < len(text.lower()):
                found = False
                for eng, rus in reverse_map.items():
                    if text.lower()[i:].startswith(eng):
                        result += rus
                        i += len(eng)
                        found = True
                        break
                if not found:
                    result += text[i]
                    i += 1
            return result
        
        else:
            return text  # Возврат оригинала для других языков
    
    def _initialize_dummy_models(self):
        """Инициализация заглушек для моделей"""
        # В реальном приложении здесь инициализация моделей
        pass
    
    async def get_supported_languages(self) -> Dict[str, str]:
        """Получение списка поддерживаемых языков"""
        return self.supported_languages.copy()
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса переводчика"""
        return {
            'is_initialized': len(self.translation_models) > 0 or hasattr(self, '_dummy_translate'),
            'supported_languages': len(self.supported_languages),
            'stats': self.stats,
            'cache_size': len(self._translation_cache),
            'translation_settings': self.translation_settings
        }

# Глобальный экземпляр
translator = Translator()