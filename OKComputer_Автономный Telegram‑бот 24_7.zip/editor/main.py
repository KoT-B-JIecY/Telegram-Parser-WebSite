"""
Editor Service Main Module
Главный модуль сервиса авторедактирования
"""

import asyncio
import signal
import sys
from typing import Dict, List, Any, Optional
import logging
from pathlib import Path

from config import config
from nlp_processor import NLPProcessor
from content_optimizer import ContentOptimizer
from translator import Translator
from moderation import ContentModerator

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOGS_DIR / 'editor.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class EditorService:
    """Сервис авторедактирования контента"""
    
    def __init__(self):
        self.is_running = False
        self.nlp_processor = NLPProcessor()
        self.optimizer = ContentOptimizer()
        self.translator = Translator()
        self.moderator = ContentModerator()
        
        # Очереди
        self.processing_queue: List[Dict[str, Any]] = []
        self.completed_queue: List[Dict[str, Any]] = []
        
        # Статистика
        self.stats = {
            'content_processed': 0,
            'content_optimized': 0,
            'content_translated': 0,
            'content_rejected': 0,
            'processing_time_avg': 0.0,
            'quality_improvements': 0
        }
        
        # Настройки
        self.max_queue_size = 1000
        self.batch_size = 10
        self.processing_timeout = 300  # 5 минут
        
        # Флаги управления
        self._shutdown_event = asyncio.Event()
        
        logger.info("Editor Service инициализирован")
    
    async def start(self):
        """Запуск сервиса редактирования"""
        try:
            logger.info("Запуск Editor Service...")
            
            # Инициализация компонентов
            await self.nlp_processor.initialize()
            await self.translator.initialize()
            await self.moderator.initialize()
            
            # Обновление статуса
            self.is_running = True
            
            # Запуск рабочих циклов
            asyncio.create_task(self._processing_loop())
            asyncio.create_task(self._quality_monitoring_loop())
            asyncio.create_task(self._cleanup_loop())
            
            logger.info("Editor Service успешно запущен")
            
            # Ожидание завершения
            await self._shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"Ошибка при запуске Editor Service: {e}")
            raise
    
    async def stop(self):
        """Остановка сервиса редактирования"""
        logger.info("Остановка Editor Service...")
        self.is_running = False
        self._shutdown_event.set()
        
        # Очистка ресурсов
        await self.nlp_processor.cleanup()
        await self.translator.cleanup()
        
        logger.info("Editor Service остановлен")
    
    async def process_content(self, content_data: Dict[str, Any]) -> str:
        """Добавление контента на обработку"""
        if len(self.processing_queue) >= self.max_queue_size:
            raise Exception("Очередь обработки переполнена")
        
        task_id = content_data.get('id', f"edit_task_{len(self.processing_queue)}")
        task = {
            'id': task_id,
            'content': content_data,
            'status': 'pending',
            'created_at': asyncio.get_event_loop().time(),
            'processing_options': content_data.get('processing_options', {})
        }
        
        self.processing_queue.append(task)
        logger.info(f"Добавлена задача редактирования: {task_id}")
        
        return task_id
    
    async def get_processing_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Получение статуса обработки контента"""
        # Поиск в очереди на обработку
        for task in self.processing_queue:
            if task['id'] == task_id:
                return {
                    'id': task_id,
                    'status': task['status'],
                    'created_at': task.get('created_at'),
                    'queue_position': self.processing_queue.index(task)
                }
        
        # Поиск в завершенной очереди
        for task in self.completed_queue:
            if task['id'] == task_id:
                return {
                    'id': task_id,
                    'status': 'completed',
                    'completed_at': task.get('completed_at'),
                    'quality_score': task.get('result', {}).get('quality_score'),
                    'processing_time': task.get('processing_time')
                }
        
        return None
    
    async def get_service_status(self) -> Dict[str, Any]:
        """Получение статуса сервиса"""
        return {
            'is_running': self.is_running,
            'queue_size': len(self.processing_queue),
            'completed_count': len(self.completed_queue),
            'stats': self.stats,
            'nlp_status': await self.nlp_processor.get_status(),
            'translator_status': await self.translator.get_status()
        }
    
    async def _processing_loop(self):
        """Основной цикл обработки контента"""
        while self.is_running:
            try:
                if self.processing_queue:
                    # Обработка пакетами для эффективности
                    batch = self.processing_queue[:self.batch_size]
                    
                    # Обработка батча
                    results = await self._process_batch(batch)
                    
                    # Перемещение результатов
                    for task, result in zip(batch, results):
                        task['status'] = 'completed'
                        task['result'] = result
                        task['completed_at'] = asyncio.get_event_loop().time()
                        task['processing_time'] = task['completed_at'] - task['created_at']
                        
                        self.completed_queue.append(task)
                        self.processing_queue.remove(task)
                        
                        # Обновление статистики
                        self._update_stats(result)
                    
                    logger.info(f"Обработан батч из {len(batch)} задач")
                
                await asyncio.sleep(1)  # Пауза для предотвращения CPU overload
                
            except Exception as e:
                logger.error(f"Ошибка в цикле обработки: {e}")
                await asyncio.sleep(5)
    
    async def _process_batch(self, batch: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Обработка батча контента"""
        results = []
        
        for task in batch:
            try:
                # Изменение статуса
                task['status'] = 'processing'
                
                # Обработка контента
                result = await self._process_single_content(task)
                results.append(result)
                
            except Exception as e:
                logger.error(f"Ошибка при обработке задачи {task['id']}: {e}")
                results.append({
                    'error': str(e),
                    'original_content': task['content'],
                    'quality_score': 0.0
                })
        
        return results
    
    async def _process_single_content(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Обработка одного элемента контента"""
        content = task['content']
        options = task['processing_options']
        
        logger.info(f"Обработка контента: {task['id']}")
        
        # Модерация контента
        moderation_result = await self.moderator.check_content(content)
        if moderation_result['is_inappropriate']:
            logger.warning(f"Контент отклонен модерацией: {task['id']}")
            return {
                'error': 'Content rejected by moderation',
                'moderation_reason': moderation_result['reason'],
                'original_content': content,
                'quality_score': 0.0
            }
        
        # NLP обработка
        nlp_result = await self.nlp_processor.process(content)
        
        # Оптимизация контента
        optimized_content = content.copy()
        
        if options.get('optimize_text', True):
            optimized_content = await self.optimizer.optimize_text(
                optimized_content,
                nlp_result
            )
        
        if options.get('add_emojis', True):
            optimized_content = await self.optimizer.add_emojis(optimized_content)
        
        if options.get('generate_hashtags', True):
            optimized_content = await self.optimizer.generate_hashtags(
                optimized_content,
                nlp_result
            )
        
        # Перевод если необходимо
        if options.get('translate_to'):
            optimized_content = await self.translator.translate_content(
                optimized_content,
                options['translate_to']
            )
        
        # Формирование результата
        result = {
            'original_content': content,
            'processed_content': optimized_content,
            'nlp_analysis': nlp_result,
            'moderation_result': moderation_result,
            'processing_options': options,
            'quality_score': await self._calculate_quality_score(optimized_content)
        }
        
        return result
    
    async def _calculate_quality_score(self, content: Dict[str, Any]) -> float:
        """Расчет оценки качества обработанного контента"""
        score = 0.0
        
        # Оценка на основе различных метрик
        if content.get('title') and len(content['title']) > 10:
            score += 0.2
        
        if content.get('content'):
            content_length = len(content['content'])
            if 500 <= content_length <= 4000:  # Оптимальная длина для Telegram
                score += 0.3
            elif content_length > 4000:
                score += 0.1  # Штраф за слишком длинный контент
        
        if content.get('hashtags') and 1 <= len(content['hashtags']) <= 10:
            score += 0.2
        
        if content.get('readability_score', 0) > 0.7:
            score += 0.3
        
        return min(score, 1.0)
    
    async def _quality_monitoring_loop(self):
        """Цикл мониторинга качества"""
        while self.is_running:
            try:
                # Проверка качества каждые 5 минут
                await asyncio.sleep(300)
                
                # Анализ качества последних обработанных контентов
                if self.completed_queue:
                    recent_tasks = self.completed_queue[-50:]  # Последние 50
                    avg_quality = sum(
                        task.get('result', {}).get('quality_score', 0)
                        for task in recent_tasks
                    ) / len(recent_tasks)
                    
                    logger.info(f"Среднее качество контента: {avg_quality:.2f}")
                    
                    # Регулировка параметров если качество низкое
                    if avg_quality < 0.6:
                        logger.warning("Качество контента ниже порога, регулировка параметров")
                        await self._adjust_processing_parameters()
                
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга качества: {e}")
    
    async def _cleanup_loop(self):
        """Цикл очистки ресурсов"""
        while self.is_running:
            try:
                # Очистка каждый час
                await asyncio.sleep(3600)
                
                # Очистка старых задач (старше 24 часов)
                current_time = asyncio.get_event_loop().time()
                self.completed_queue = [
                    task for task in self.completed_queue
                    if current_time - task.get('completed_at', 0) < 86400
                ]
                
                # Очистка кэшей NLP процессора
                await self.nlp_processor.cleanup_cache()
                
                logger.info("Ресурсы сервиса редактирования очищены")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле очистки: {e}")
    
    def _update_stats(self, result: Dict[str, Any]):
        """Обновление статистики"""
        self.stats['content_processed'] += 1
        
        if 'error' not in result:
            self.stats['content_optimized'] += 1
            
            if result.get('processing_options', {}).get('translate_to'):
                self.stats['content_translated'] += 1
            
            quality_score = result.get('quality_score', 0)
            if quality_score > 0.7:
                self.stats['quality_improvements'] += 1
        else:
            self.stats['content_rejected'] += 1
        
        # Обновление среднего времени обработки
        if 'processing_time' in result:
            total_processed = self.stats['content_processed']
            self.stats['processing_time_avg'] = (
                (self.stats['processing_time_avg'] * (total_processed - 1) + result['processing_time']) /
                total_processed
            )
    
    async def _adjust_processing_parameters(self):
        """Регулировка параметров обработки для улучшения качества"""
        # Увеличение порогов качества
        self.optimizer.quality_thresholds['min_readability_score'] = min(
            0.8, self.optimizer.quality_thresholds['min_readability_score'] + 0.1
        )
        
        # Включение дополнительных опций оптимизации
        self.optimizer.enable_advanced_optimization = True
        
        logger.info("Параметры обработки скорректированы для улучшения качества")

# Обработка сигналов
def signal_handler(signum, frame):
    """Обработчик системных сигналов"""
    logger.info(f"Получен сигнал {signum}")
    
    if signum == signal.SIGTERM:
        asyncio.create_task(editor_service.stop())
    elif signum == signal.SIGINT:
        asyncio.create_task(editor_service.stop())

# Глобальный экземпляр
editor_service = EditorService()

async def main():
    """Главная функция"""
    # Установка обработчиков сигналов
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        await editor_service.start()
    except KeyboardInterrupt:
        logger.info("Получено прерывание от пользователя")
        await editor_service.stop()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        await editor_service.stop()

if __name__ == "__main__":
    asyncio.run(main())