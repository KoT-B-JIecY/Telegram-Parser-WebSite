"""
Publishing Scheduler Module
Умное расписание публикаций на основе анализа аудитории
"""

import asyncio
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

@dataclass
class PublishingSlot:
    """Слот для публикации"""
    time: datetime
    channel_id: str
    priority: int = 5  # 1-10, 1 = highest
    content_type: str = 'text'
    estimated_engagement: float = 0.5
    is_optimal: bool = False

@dataclass
class AudienceAnalytics:
    """Аналитика аудитории"""
    peak_hours: List[int]  # часы с наибольшей активностью
    active_days: List[int]  # дни недели с активностью (0=понедельник)
    engagement_by_hour: Dict[int, float]
    avg_post_lifetime: int  # минуты
    optimal_post_frequency: int  # постов в день

class PublishingScheduler:
    """Планировщик публикаций с ML оптимизацией"""
    
    def __init__(self):
        # Оптимальные часы публикации (UTC)
        self.optimal_hours = [9, 12, 15, 18, 21]  # По умолчанию
        
        # Аналитика аудитории
        self.audience_analytics = AudienceAnalytics(
            peak_hours=self.optimal_hours,
            active_days=[0, 1, 2, 3, 4, 5],  # Пн-Сб
            engagement_by_hour={h: 0.7 for h in self.optimal_hours},
            avg_post_lifetime=1440,  # 24 часа
            optimal_post_frequency=5
        )
        
        # Настройки расписания
        self.schedule_settings = {
            'auto_scheduling': True,
            'respect_peak_hours': True,
            'min_interval_minutes': 30,
            'max_posts_per_hour': 3,
            'timezone_offset': 0  # UTC
        }
        
        # Слоты публикации
        self.publishing_slots: List[PublishingSlot] = []
        
        # Статистика
        self.stats = {
            'posts_scheduled': 0,
            'posts_published': 0,
            'optimal_time_hits': 0,
            'schedule_optimization_score': 0.0
        }
        
        # История публикаций для обучения
        self.publishing_history: List[Dict[str, Any]] = []
        
        logger.info("Publishing Scheduler инициализирован")
    
    async def initialize(self):
        """Инициализация планировщика"""
        logger.info("Инициализация Publishing Scheduler...")
        
        # Загрузка исторических данных
        await self._load_publishing_history()
        
        # Инициализация слотов публикации
        await self._initialize_publishing_slots()
        
        logger.info("Publishing Scheduler инициализирован")
    
    async def cleanup(self):
        """Очистка ресурсов"""
        logger.info("Publishing Scheduler очищен")
    
    async def schedule_post(
        self,
        content: Dict[str, Any],
        channel_ids: List[str],
        preferred_time: Optional[datetime] = None,
        priority: int = 5
    ) -> List[datetime]:
        """
        Планирование публикации поста
        
        Args:
            content: Контент для публикации
            channel_ids: Список каналов для публикации
            preferred_time: Предпочтительное время
            priority: Приоритет поста (1-10)
            
        Returns:
            Список запланированных времен публикации
        """
        scheduled_times = []
        
        for channel_id in channel_ids:
            # Определение оптимального времени
            optimal_time = await self._calculate_optimal_time(
                channel_id,
                preferred_time,
                priority
            )
            
            # Создание слота публикации
            slot = PublishingSlot(
                time=optimal_time,
                channel_id=channel_id,
                priority=priority,
                content_type=content.get('type', 'text'),
                estimated_engagement=await self._estimate_engagement(
                    content,
                    channel_id,
                    optimal_time
                ),
                is_optimal=optimal_time.hour in self.optimal_hours
            )
            
            # Добавление слота
            self.publishing_slots.append(slot)
            scheduled_times.append(optimal_time)
            
            self.stats['posts_scheduled'] += 1
            
            logger.info(f"Пост запланирован на {optimal_time} для канала {channel_id}")
        
        # Сортировка слотов по времени
        self.publishing_slots.sort(key=lambda x: x.time)
        
        return scheduled_times
    
    async def get_next_publishing_slot(self) -> Optional[PublishingSlot]:
        """Получение следующего слота для публикации"""
        current_time = datetime.now()
        
        # Фильтрация прошедших и ближайших слотов
        upcoming_slots = [
            slot for slot in self.publishing_slots
            if slot.time <= current_time + timedelta(minutes=5)
        ]
        
        if upcoming_slots:
            # Возврат слота с наивысшим приоритетом
            next_slot = max(upcoming_slots, key=lambda x: x.priority)
            
            # Удаление слота из очереди
            self.publishing_slots.remove(next_slot)
            
            return next_slot
        
        return None
    
    async def update_publishing_recommendations(self):
        """Обновление рекомендаций по времени публикации"""
        # Анализ истории публикаций
        if len(self.publishing_history) < 50:
            return  # Недостаточно данных
        
        # Анализ эффективности по часам
        engagement_by_hour = {}
        post_count_by_hour = {}
        
        for record in self.publishing_history[-500:]:  # Последние 500 записей
            hour = record['published_at'].hour
            engagement = record.get('engagement_score', 0.5)
            
            engagement_by_hour[hour] = engagement_by_hour.get(hour, 0) + engagement
            post_count_by_hour[hour] = post_count_by_hour.get(hour, 0) + 1
        
        # Расчет средней эффективности по часам
        avg_engagement_by_hour = {}
        for hour in range(24):
            if hour in post_count_by_hour:
                avg_engagement_by_hour[hour] = (
                    engagement_by_hour.get(hour, 0) / post_count_by_hour[hour]
                )
        
        # Выбор топ-5 часов с наилучшей эффективностью
        sorted_hours = sorted(
            avg_engagement_by_hour.items(),
            key=lambda x: x[1],
            reverse=True
        )
        
        self.optimal_hours = [hour for hour, _ in sorted_hours[:5]]
        
        # Обновление аналитики аудитории
        self.audience_analytics.peak_hours = self.optimal_hours
        self.audience_analytics.engagement_by_hour = dict(sorted_hours[:10])
        
        self.stats['schedule_optimization_score'] = sum(
            score for _, score in sorted_hours[:5]
        ) / 5
        
        logger.info(f"Обновлены оптимальные часы публикации: {self.optimal_hours}")
    
    async def update_optimal_hours(self, optimal_hours: List[int]):
        """Обновление оптимальных часов из внешнего источника"""
        self.optimal_hours = optimal_hours
        self.audience_analytics.peak_hours = optimal_hours
        
        logger.info(f"Оптимальные часы обновлены: {optimal_hours}")
    
    async def _calculate_optimal_time(
        self,
        channel_id: str,
        preferred_time: Optional[datetime],
        priority: int
    ) -> datetime:
        """Расчет оптимального времени публикации"""
        current_time = datetime.now()
        
        if preferred_time:
            # Использование предпочтительного времени с небольшими корректировками
            base_time = preferred_time
        else:
            # Выбор из оптимальных часов
            if self.schedule_settings['respect_peak_hours'] and self.optimal_hours:
                # Случайный выбор из оптимальных часов
                optimal_hour = random.choice(self.optimal_hours)
                base_time = current_time.replace(
                    hour=optimal_hour,
                    minute=random.randint(0, 59),
                    second=0,
                    microsecond=0
                )
                
                # Если время уже прошло, перенос на следующий день
                if base_time <= current_time:
                    base_time += timedelta(days=1)
            else:
                # Случайное время в рабочие часы
                base_time = current_time + timedelta(
                    hours=random.randint(1, 6),
                    minutes=random.randint(0, 59)
                )
        
        # Корректировка на основе приоритета
        if priority >= 8:  # Высокий приоритет
            # Публикация как можно скорее
            if base_time > current_time + timedelta(minutes=30):
                base_time = current_time + timedelta(minutes=random.randint(5, 15))
        elif priority <= 3:  # Низкий приоритет
            # Публикация в менее загруженное время
            base_time += timedelta(hours=random.randint(2, 8))
        
        # Проверка конфликтов с другими публикациями
        base_time = await self._resolve_conflicts(base_time, channel_id)
        
        return base_time
    
    async def _resolve_conflicts(
        self,
        proposed_time: datetime,
        channel_id: str
    ) -> datetime:
        """Разрешение конфликтов с другими публикациями"""
        min_interval = timedelta(minutes=self.schedule_settings['min_interval_minutes'])
        
        # Проверка существующих слотов
        for slot in self.publishing_slots:
            if slot.channel_id == channel_id:
                time_diff = abs((proposed_time - slot.time).total_seconds() / 60)
                
                if time_diff < self.schedule_settings['min_interval_minutes']:
                    # Конфликт найден, сдвигаем время
                    if proposed_time < slot.time:
                        proposed_time = slot.time - min_interval
                    else:
                        proposed_time = slot.time + min_interval
        
        return proposed_time
    
    async def _estimate_engagement(
        self,
        content: Dict[str, Any],
        channel_id: str,
        publish_time: datetime
    ) -> float:
        """Оценка ожидаемой вовлеченности"""
        base_score = 0.5
        
        # Влияние времени публикации
        hour = publish_time.hour
        if hour in self.audience_analytics.engagement_by_hour:
            time_factor = self.audience_analytics.engagement_by_hour[hour]
        else:
            time_factor = 0.6
        
        # Влияние типа контента
        content_type = content.get('type', 'text')
        type_multipliers = {
            'text': 1.0,
            'image': 1.2,
            'video': 1.5,
            'mixed': 1.3
        }
        type_factor = type_multipliers.get(content_type, 1.0)
        
        # Влияние длины контента
        text_length = len(content.get('content', ''))
        if 500 <= text_length <= 2000:
            length_factor = 1.1
        elif text_length > 2000:
            length_factor = 0.9
        else:
            length_factor = 1.0
        
        # Влияние наличия медиа
        media_factor = 1.2 if (content.get('images') or content.get('videos')) else 1.0
        
        # Итоговая оценка
        estimated_engagement = (
            base_score * time_factor * type_factor * 
            length_factor * media_factor
        )
        
        return min(1.0, max(0.1, estimated_engagement))
    
    async def _initialize_publishing_slots(self):
        """Инициализация слотов публикации"""
        # Создание базовых слотов на ближайшие 7 дней
        current_time = datetime.now()
        
        for day_offset in range(7):
            for hour in self.optimal_hours:
                base_time = current_time + timedelta(days=day_offset)
                slot_time = base_time.replace(
                    hour=hour,
                    minute=random.randint(0, 59),
                    second=0,
                    microsecond=0
                )
                
                # Создание слотов для основных каналов
                for channel_id in ['main_channel']:  # Заглушка
                    slot = PublishingSlot(
                        time=slot_time,
                        channel_id=channel_id,
                        is_optimal=True
                    )
                    self.publishing_slots.append(slot)
        
        logger.info(f"Инициализировано {len(self.publishing_slots)} слотов публикации")
    
    async def _load_publishing_history(self):
        """Загрузка истории публикаций"""
        # В реальном приложении - загрузка из базы данных
        # Заглушка с примерными данными
        self.publishing_history = [
            {
                'published_at': datetime.now() - timedelta(hours=i),
                'engagement_score': 0.5 + random.random() * 0.5,
                'channel_id': 'main_channel',
                'content_type': 'text'
            }
            for i in range(1, 101)
        ]
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса планировщика"""
        return {
            'is_initialized': True,
            'optimal_hours': self.optimal_hours,
            'pending_slots': len(self.publishing_slots),
            'stats': self.stats,
            'settings': self.schedule_settings,
            'audience_analytics': {
                'peak_hours': self.audience_analytics.peak_hours,
                'optimal_post_frequency': self.audience_analytics.optimal_post_frequency
            }
        }

# Глобальный экземпляр
publishing_scheduler = PublishingScheduler()