"""
Media Optimizer Module
Оптимизация медиа файлов для Telegram
"""

import asyncio
import aiohttp
import io
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from PIL import Image
import logging
import time

logger = logging.getLogger(__name__)

@dataclass
class MediaOptimizationResult:
    """Результат оптимизации медиа"""
    original_size: int
    optimized_size: int
    compression_ratio: float
    quality_score: float
    optimized_urls: List[str]
    processing_time: float

class MediaOptimizer:
    """Оптимизатор медиа файлов для Telegram"""
    
    def __init__(self):
        # Ограничения Telegram
        self.telegram_limits = {
            'photo_max_size': 10 * 1024 * 1024,  # 10MB
            'photo_max_dimensions': (1280, 1280),
            'video_max_size': 50 * 1024 * 1024,  # 50MB
            'video_max_duration': 60,  # секунд для автоматического постинга
            'media_group_max_size': 10  # максимум медиа в группе
        }
        
        # Настройки оптимизации
        self.optimization_settings = {
            'image_quality': 85,  # проценты
            'max_width': 1280,
            'max_height': 1280,
            'preserve_aspect_ratio': True,
            'auto_orient': True,
            'remove_metadata': True
        }
        
        # Кэш оптимизированных файлов
        self._optimization_cache: Dict[str, MediaOptimizationResult] = {}
        self._cache_ttl = 86400  # 24 часа
        
        # Статистика
        self.stats = {
            'images_processed': 0,
            'images_optimized': 0,
            'total_size_saved': 0,
            'processing_time_avg': 0.0
        }
        
        logger.info("Media Optimizer инициализирован")
    
    async def initialize(self):
        """Инициализация оптимизатора медиа"""
        logger.info("Инициализация Media Optimizer...")
        
        # Проверка доступности библиотек
        try:
            import PIL.Image
            logger.info("PIL/Pillow доступен для обработки изображений")
        except ImportError:
            logger.warning("PIL/Pillow не доступен, оптимизация изображений ограничена")
        
        logger.info("Media Optimizer инициализирован")
    
    async def optimize_for_telegram(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """
        Оптимизация медиа контента для Telegram
        
        Args:
            content: Контент с медиа файлами
            
        Returns:
            Оптимизированный контент
        """
        optimized_content = content.copy()
        
        try:
            # Оптимизация изображений
            if content.get('images'):
                optimized_images = await self._optimize_images(content['images'])
                optimized_content['images'] = optimized_images
            
            # Оптимизация видео
            if content.get('videos'):
                optimized_videos = await self._optimize_videos(content['videos'])
                optimized_content['videos'] = optimized_videos
            
            # Создание коллажей если много изображений
            if len(optimized_content.get('images', [])) > 4:
                collages = await self._create_collages(optimized_content['images'])
                optimized_content['images'] = collages[:4]  # Ограничение количества
            
            return optimized_content
            
        except Exception as e:
            logger.error(f"Ошибка при оптимизации медиа: {e}")
            return content
    
    async def _optimize_images(self, image_urls: List[str]) -> List[str]:
        """Оптимизация списка изображений"""
        optimized_urls = []
        
        for url in image_urls[:10]:  # Ограничение количества
            try:
                # Проверка кэша
                cache_key = f"image_{url}"
                if cache_key in self._optimization_cache:
                    cached_result = self._optimization_cache[cache_key]
                    if time.time() - cached_result.processing_time < self._cache_ttl:
                        optimized_urls.extend(cached_result.optimized_urls)
                        continue
                
                # Загрузка и оптимизация изображения
                optimized_url = await self._optimize_single_image(url)
                if optimized_url:
                    optimized_urls.append(optimized_url)
                    
                    # Обновление статистики
                    self.stats['images_processed'] += 1
                    self.stats['images_optimized'] += 1
                    
            except Exception as e:
                logger.warning(f"Не удалось оптимизировать изображение {url}: {e}")
                # Использование оригинального URL как fallback
                optimized_urls.append(url)
        
        return optimized_urls
    
    async def _optimize_single_image(self, image_url: str) -> Optional[str]:
        """Оптимизация одного изображения"""
        start_time = time.time()
        
        try:
            # Загрузка изображения
            async with aiohttp.ClientSession() as session:
                async with session.get(image_url) as response:
                    if response.status != 200:
                        return None
                    
                    image_data = await response.read()
                    original_size = len(image_data)
            
            # Проверка необходимости оптимизации
            if original_size <= self.telegram_limits['photo_max_size']:
                # Изображение уже подходит по размеру
                return image_url
            
            # Открытие изображения
            image = Image.open(io.BytesIO(image_data))
            
            # Автоматическая ориентация
            if self.optimization_settings['auto_orient']:
                image = self._auto_orient_image(image)
            
            # Изменение размера если необходимо
            if (image.width > self.optimization_settings['max_width'] or 
                image.height > self.optimization_settings['max_height']):
                
                image = self._resize_image(
                    image,
                    self.optimization_settings['max_width'],
                    self.optimization_settings['max_height']
                )
            
            # Сжатие изображения
            optimized_image_data = self._compress_image(
                image,
                self.optimization_settings['image_quality']
            )
            
            optimized_size = len(optimized_image_data)
            
            # Проверка результата
            if optimized_size > self.telegram_limits['photo_max_size']:
                # Повторное сжатие с более низким качеством
                optimized_image_data = self._compress_image(image, 60)
                optimized_size = len(optimized_image_data)
            
            # Сохранение результата в кэш
            result = MediaOptimizationResult(
                original_size=original_size,
                optimized_size=optimized_size,
                compression_ratio=(original_size - optimized_size) / original_size,
                quality_score=0.8,  # Упрощенная оценка
                optimized_urls=[image_url],  # В реальном приложении - загрузка оптимизированного файла
                processing_time=time.time() - start_time
            )
            
            cache_key = f"image_{image_url}"
            self._optimization_cache[cache_key] = result
            
            # Обновление статистики
            self.stats['total_size_saved'] += (original_size - optimized_size)
            processing_time = time.time() - start_time
            self.stats['processing_time_avg'] = (
                (self.stats['processing_time_avg'] * (self.stats['images_processed'] - 1) + processing_time) /
                self.stats['images_processed']
            )
            
            return image_url  # Возврат оригинального URL для демонстрации
            
        except Exception as e:
            logger.error(f"Ошибка при оптимизации изображения: {e}")
            return None
    
    def _auto_orient_image(self, image: Image.Image) -> Image.Image:
        """Автоматическая ориентация изображения"""
        try:
            # Проверка EXIF ориентации
            if hasattr(image, '_getexif') and image._getexif():
                exif = image._getexif()
                orientation = exif.get(0x0112, 1)
                
                # Применение корректировки ориентации
                if orientation == 3:
                    image = image.rotate(180, expand=True)
                elif orientation == 6:
                    image = image.rotate(270, expand=True)
                elif orientation == 8:
                    image = image.rotate(90, expand=True)
        
        except Exception as e:
            logger.warning(f"Ошибка при автоматической ориентации: {e}")
        
        return image
    
    def _resize_image(
        self,
        image: Image.Image,
        max_width: int,
        max_height: int
    ) -> Image.Image:
        """Изменение размера изображения с сохранением пропорций"""
        width, height = image.size
        
        # Расчет новых размеров
        if width > max_width or height > max_height:
            if self.optimization_settings['preserve_aspect_ratio']:
                # Сохранение пропорций
                ratio = min(max_width / width, max_height / height)
                new_width = int(width * ratio)
                new_height = int(height * ratio)
            else:
                # Принудительное изменение размеров
                new_width = min(width, max_width)
                new_height = min(height, max_height)
            
            # Изменение размера
            image = image.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        return image
    
    def _compress_image(self, image: Image.Image, quality: int) -> bytes:
        """Сжатие изображения с заданным качеством"""
        output_buffer = io.BytesIO()
        
        # Определение формата
        if image.mode in ('RGBA', 'LA', 'P'):
            # Конвертация в RGB для JPEG
            rgb_image = Image.new('RGB', image.size, (255, 255, 255))
            rgb_image.paste(image, mask=image.split()[-1] if image.mode == 'RGBA' else None)
            image = rgb_image
        
        # Сохранение с сжатием
        image.save(
            output_buffer,
            format='JPEG',
            quality=quality,
            optimize=True,
            progressive=True
        )
        
        return output_buffer.getvalue()
    
    async def _optimize_videos(self, video_urls: List[str]) -> List[str]:
        """Оптимизация видео файлов"""
        optimized_urls = []
        
        for url in video_urls[:1]:  # Ограничение - один видео файл
            try:
                # В реальном приложении - использование ffmpeg для оптимизации
                # Здесь заглушка
                optimized_urls.append(url)
                
            except Exception as e:
                logger.warning(f"Не удалось оптимизировать видео {url}: {e}")
                optimized_urls.append(url)
        
        return optimized_urls
    
    async def _create_collages(self, image_urls: List[str]) -> List[str]:
        """Создание коллажей из нескольких изображений"""
        if len(image_urls) < 2:
            return image_urls
        
        collages = []
        
        try:
            # Загрузка изображений
            images = []
            for url in image_urls[:6]:  # Максимум 6 изображений для коллажа
                async with aiohttp.ClientSession() as session:
                    async with session.get(url) as response:
                        if response.status == 200:
                            image_data = await response.read()
                            image = Image.open(io.BytesIO(image_data))
                            images.append(image)
            
            if len(images) >= 2:
                # Создание коллажа 2x2
                collage_2x2 = self._create_2x2_collage(images[:4])
                collages.append(collage_2x2)
                
                # Создание коллажа 3x2 если достаточно изображений
                if len(images) >= 5:
                    collage_3x2 = self._create_3x2_collage(images[:6])
                    collages.append(collage_3x2)
            
            # Возврат оригинальных изображений + коллажей
            return image_urls[:2] + collages
            
        except Exception as e:
            logger.error(f"Ошибка при создании коллажа: {e}")
            return image_urls[:4]  # Возврат первых 4 изображений
    
    def _create_2x2_collage(self, images: List[Image.Image]) -> str:
        """Создание коллажа 2x2"""
        if len(images) < 4:
            images.extend([Image.new('RGB', (200, 200), (255, 255, 255))] * (4 - len(images)))
        
        # Изменение размера изображений
        size = 300
        resized_images = []
        for img in images[:4]:
            img_resized = img.resize((size, size), Image.Resampling.LANCZOS)
            resized_images.append(img_resized)
        
        # Создание коллажа
        collage = Image.new('RGB', (size * 2, size * 2), (255, 255, 255))
        
        # Размещение изображений
        positions = [(0, 0), (size, 0), (0, size), (size, size)]
        for i, (img, pos) in enumerate(zip(resized_images, positions)):
            collage.paste(img, pos)
        
        # Сохранение коллажа
        output_buffer = io.BytesIO()
        collage.save(output_buffer, format='JPEG', quality=90)
        collage_data = output_buffer.getvalue()
        
        # В реальном приложении - загрузка в облачное хранилище
        # Здесь возврат base64 или сохранение во временный файл
        return "collage_2x2_jpeg_data"
    
    def _create_3x2_collage(self, images: List[Image.Image]) -> str:
        """Создание коллажа 3x2"""
        if len(images) < 6:
            images.extend([Image.new('RGB', (200, 200), (255, 255, 255))] * (6 - len(images)))
        
        # Изменение размера изображений
        size = 200
        resized_images = []
        for img in images[:6]:
            img_resized = img.resize((size, size), Image.Resampling.LANCZOS)
            resized_images.append(img_resized)
        
        # Создание коллажа
        collage = Image.new('RGB', (size * 3, size * 2), (255, 255, 255))
        
        # Размещение изображений
        for i, img in enumerate(resized_images):
            x = (i % 3) * size
            y = (i // 3) * size
            collage.paste(img, (x, y))
        
        # Сохранение коллажа
        output_buffer = io.BytesIO()
        collage.save(output_buffer, format='JPEG', quality=90)
        collage_data = output_buffer.getvalue()
        
        return "collage_3x2_jpeg_data"
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса оптимизатора медиа"""
        return {
            'is_initialized': True,
            'stats': self.stats,
            'optimization_settings': self.optimization_settings,
            'telegram_limits': self.telegram_limits,
            'cache_size': len(self._optimization_cache)
        }

# Глобальный экземпляр
media_optimizer = MediaOptimizer()