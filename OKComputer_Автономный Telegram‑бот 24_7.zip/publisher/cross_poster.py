"""
Cross Poster Module
Кросс-постинг в несколько Telegram каналов
"""

import asyncio
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

@dataclass
class ChannelSettings:
    """Настройки канала для кросс-постинга"""
    channel_id: str
    name: str
    audience_type: str  # 'general', 'tech', 'business', etc.
    language: str
    posting_frequency: int  # постов в день
    content_preferences: List[str]  # предпочитаемые типы контента
    custom_formatting: bool
    delay_minutes: int  # задержка перед публикацией

@dataclass
class CrossPostResult:
    """Результат кросс-постинга"""
    success: bool
    message_ids: Dict[str, int]  # channel_id -> message_id
    errors: Dict[str, str] = None  # channel_id -> error message
    total_time: float = 0.0

class CrossPoster:
    """Модуль кросс-постинга в несколько каналов"""
    
    def __init__(self):
        # Настройки каналов
        self.channel_settings: Dict[str, ChannelSettings] = {}
        
        # Правила кросс-постинга
        self.cross_post_rules = {
            'max_channels_per_post': 5,
            'min_delay_between_posts': 300,  # 5 минут
            'respect_audience_type': True,
            'language_filtering': True,
            'content_adaptation': True
        }
        
        # Очередь кросс-постинга
        self.cross_post_queue: List[Dict[str, Any]] = []
        
        # Статистика
        self.stats = {
            'cross_posts_sent': 0,
            'successful_cross_posts': 0,
            'failed_cross_posts': 0,
            'avg_cross_post_time': 0.0
        }
        
        # История кросс-постинга
        self.cross_post_history: List[Dict[str, Any]] = []
        
        logger.info("Cross Poster инициализирован")
    
    async def initialize(self):
        """Инициализация модуля кросс-постинга"""
        logger.info("Инициализация Cross Poster...")
        
        # Загрузка настроек каналов
        await self._load_channel_settings()
        
        # Запуск фоновой задачи обработки очереди
        asyncio.create_task(self._process_cross_post_queue())
        
        logger.info("Cross Poster инициализирован")
    
    async def cleanup(self):
        """Очистка ресурсов"""
        logger.info("Cross Poster очищен")
    
    async def cross_post(
        self,
        content: Dict[str, Any],
        target_channels: List[str],
        original_message_ids: Optional[Dict[str, int]] = None
    ) -> CrossPostResult:
        """
        Кросс-постинг контента в несколько каналов
        
        Args:
            content: Контент для публикации
            target_channels: Список ID каналов
            original_message_ids: ID оригинальных сообщений
            
        Returns:
            Результат кросс-постинга
        """
        start_time = asyncio.get_event_loop().time()
        
        # Ограничение количества каналов
        target_channels = target_channels[:self.cross_post_rules['max_channels_per_post']]
        
        # Фильтрация каналов
        filtered_channels = await self._filter_channels_for_cross_post(
            content,
            target_channels
        )
        
        if not filtered_channels:
            return CrossPostResult(
                success=False,
                message_ids={},
                errors={'all': 'No suitable channels found'}
            )
        
        # Адаптация контента под каждый канал
        adapted_contents = await self._adapt_content_for_channels(
            content,
            filtered_channels
        )
        
        # Публикация с задержками
        message_ids = {}
        errors = {}
        
        for i, (channel_id, adapted_content) in enumerate(adapted_contents.items()):
            try:
                # Задержка между публикациями
                if i > 0:
                    delay = self.cross_post_rules['min_delay_between_posts']
                    await asyncio.sleep(delay)
                
                # Публикация в канал
                channel_message_ids = await self._publish_to_channel(
                    adapted_content,
                    channel_id
                )
                
                message_ids.update(channel_message_ids)
                
                # Логирование успешной публикации
                self._log_cross_post_success(
                    content,
                    channel_id,
                    channel_message_ids
                )
                
            except Exception as e:
                error_msg = str(e)
                errors[channel_id] = error_msg
                logger.error(f"Ошибка кросс-постинга в канал {channel_id}: {error_msg}")
                
                # Логирование ошибки
                self._log_cross_post_error(content, channel_id, error_msg)
        
        # Формирование результата
        success = len(message_ids) > 0
        total_time = asyncio.get_event_loop().time() - start_time
        
        result = CrossPostResult(
            success=success,
            message_ids=message_ids,
            errors=errors if errors else None,
            total_time=total_time
        )
        
        # Обновление статистики
        self.stats['cross_posts_sent'] += len(filtered_channels)
        self.stats['successful_cross_posts'] += len(message_ids)
        self.stats['failed_cross_posts'] += len(errors)
        
        if self.stats['cross_posts_sent'] > 0:
            self.stats['avg_cross_post_time'] = (
                (self.stats['avg_cross_post_time'] * (self.stats['cross_posts_sent'] - len(filtered_channels)) + total_time) /
                self.stats['cross_posts_sent']
            )
        
        logger.info(f"Кросс-постинг завершен: {len(message_ids)}/{len(filtered_channels)} успешно")
        return result
    
    async def add_channel(self, channel_settings: ChannelSettings):
        """Добавление канала для кросс-постинга"""
        self.channel_settings[channel_settings.channel_id] = channel_settings
        logger.info(f"Канал добавлен для кросс-постинга: {channel_settings.name}")
    
    async def remove_channel(self, channel_id: str):
        """Удаление канала из кросс-постинга"""
        if channel_id in self.channel_settings:
            channel_name = self.channel_settings[channel_id].name
            del self.channel_settings[channel_id]
            logger.info(f"Канал удален из кросс-постинга: {channel_name}")
    
    async def update_channel_settings(self, channel_id: str, settings: Dict[str, Any]):
        """Обновление настроек канала"""
        if channel_id in self.channel_settings:
            for key, value in settings.items():
                if hasattr(self.channel_settings[channel_id], key):
                    setattr(self.channel_settings[channel_id], key, value)
            
            logger.info(f"Обновлены настройки канала: {channel_id}")
    
    async def _filter_channels_for_cross_post(
        self,
        content: Dict[str, Any],
        target_channels: List[str]
    ) -> List[str]:
        """Фильтрация каналов для кросс-постинга"""
        filtered_channels = []
        
        for channel_id in target_channels:
            if channel_id not in self.channel_settings:
                continue
            
            channel_settings = self.channel_settings[channel_id]
            
            # Проверка языка
            if (self.cross_post_rules['language_filtering'] and 
                content.get('language') != channel_settings.language):
                continue
            
            # Проверка типа аудитории
            if (self.cross_post_rules['respect_audience_type'] and 
                not self._is_content_suitable_for_audience(content, channel_settings)):
                continue
            
            # Проверка предпочтений контента
            if not self._is_content_type_preferred(content, channel_settings):
                continue
            
            filtered_channels.append(channel_id)
        
        return filtered_channels
    
    def _is_content_suitable_for_audience(
        self,
        content: Dict[str, Any],
        channel_settings: ChannelSettings
    ) -> bool:
        """Проверка подходности контента для аудитории канала"""
        content_type = content.get('type', 'general')
        audience_type = channel_settings.audience_type
        
        # Матрица совместимости
        compatibility_matrix = {
            'general': ['general', 'news', 'entertainment'],
            'tech': ['tech', 'science', 'business'],
            'business': ['business', 'finance', 'tech'],
            'entertainment': ['entertainment', 'general', 'lifestyle'],
            'news': ['news', 'general', 'politics']
        }
        
        compatible_types = compatibility_matrix.get(audience_type, [])
        return content_type in compatible_types
    
    def _is_content_type_preferred(
        self,
        content: Dict[str, Any],
        channel_settings: ChannelSettings
    ) -> bool:
        """Проверка предпочтений типа контента"""
        content_preferences = channel_settings.content_preferences
        
        # Определение характеристик контента
        has_images = bool(content.get('images'))
        has_videos = bool(content.get('videos'))
        text_length = len(content.get('content', ''))
        
        # Проверка предпочтений
        if 'text_only' in content_preferences and (has_images or has_videos):
            return False
        
        if 'media_rich' in content_preferences and not (has_images or has_videos):
            return False
        
        if 'short_posts' in content_preferences and text_length > 1000:
            return False
        
        if 'long_posts' in content_preferences and text_length < 500:
            return False
        
        return True
    
    async def _adapt_content_for_channels(
        self,
        content: Dict[str, Any],
        channel_ids: List[str]
    ) -> Dict[str, Dict[str, Any]]:
        """Адаптация контента под каждый канал"""
        adapted_contents = {}
        
        for channel_id in channel_ids:
            channel_settings = self.channel_settings[channel_id]
            
            if self.cross_post_rules['content_adaptation']:
                # Адаптация контента
                adapted_content = await self._adapt_content_for_channel(
                    content,
                    channel_settings
                )
            else:
                # Использование оригинального контента
                adapted_content = content.copy()
            
            adapted_contents[channel_id] = adapted_content
        
        return adapted_contents
    
    async def _adapt_content_for_channel(
        self,
        content: Dict[str, Any],
        channel_settings: ChannelSettings
    ) -> Dict[str, Any]:
        """Адаптация контента под конкретный канал"""
        adapted_content = content.copy()
        
        # Кастомное форматирование
        if channel_settings.custom_formatting:
            adapted_content = await self._apply_custom_formatting(
                adapted_content,
                channel_settings
            )
        
        # Адаптация текста под аудиторию
        adapted_content['content'] = await self._adapt_text_for_audience(
            adapted_content.get('content', ''),
            channel_settings.audience_type
        )
        
        # Фильтрация хештегов
        if adapted_content.get('hashtags'):
            adapted_content['hashtags'] = await self._filter_hashtags_for_channel(
                adapted_content['hashtags'],
                channel_settings
            )
        
        return adapted_content
    
    async def _apply_custom_formatting(
        self,
        content: Dict[str, Any],
        channel_settings: ChannelSettings
    ) -> Dict[str, Any]:
        """Применение кастомного форматирования"""
        formatted_content = content.copy()
        
        # Добавление префикса канала
        prefix = f"📢 {channel_settings.name}\n\n"
        if formatted_content.get('content'):
            formatted_content['content'] = prefix + formatted_content['content']
        
        return formatted_content
    
    async def _adapt_text_for_audience(
        self,
        text: str,
        audience_type: str
    ) -> str:
        """Адаптация текста под тип аудитории"""
        # Упрощенная адаптация
        adaptations = {
            'tech': {
                'add_terms': ['API', 'алгоритм', 'машинное обучение'],
                'remove_phrases': ['простыми словами', 'как всегда']
            },
            'business': {
                'add_terms': ['ROI', 'эффективность', 'прибыльность'],
                'remove_phrases': ['весело', 'прикольно']
            },
            'general': {
                'simplify': True,
                'remove_jargon': True
            }
        }
        
        # Применение адаптаций
        adapted_text = text
        
        if audience_type in adaptations:
            rules = adaptations[audience_type]
            
            if rules.get('simplify'):
                # Упрощение текста
                adapted_text = self._simplify_text(adapted_text)
            
            if rules.get('remove_jargon'):
                # Удаление жаргона
                adapted_text = self._remove_technical_jargon(adapted_text)
            
            if rules.get('add_terms'):
                # Добавление специфичных терминов
                adapted_text = self._add_audience_specific_terms(
                    adapted_text,
                    rules['add_terms']
                )
        
        return adapted_text
    
    def _simplify_text(self, text: str) -> str:
        """Упрощение текста"""
        # Удаление сложных слов и фраз
        complex_words = ['необходимо отметить', 'следует подчеркнуть', 'важно понимать']
        
        for phrase in complex_words:
            text = text.replace(phrase, 'важно')
        
        return text
    
    def _remove_technical_jargon(self, text: str) -> str:
        """Удаление технического жаргона"""
        jargon_patterns = [
            r'\bAPI\b',
            r'\bSDK\b',
            r'\bSaaS\b',
            r'\bPaaS\b',
            r'\bIaaS\b'
        ]
        
        for pattern in jargon_patterns:
            import re
            text = re.sub(pattern, 'сервис', text)
        
        return text
    
    def _add_audience_specific_terms(
        self,
        text: str,
        terms: List[str]
    ) -> str:
        """Добавление специфичных терминов для аудитории"""
        if len(terms) > 0:
            # Добавление случайного термина в начало или конец
            term = random.choice(terms)
            if random.random() > 0.5:
                return f"{term}: {text}"
            else:
                return f"{text}\n\n#{term.replace(' ', '')}"
        
        return text
    
    async def _filter_hashtags_for_channel(
        self,
        hashtags: List[str],
        channel_settings: ChannelSettings
    ) -> List[str]:
        """Фильтрация хештегов для канала"""
        filtered_hashtags = []
        
        for hashtag in hashtags[:5]:  # Максимум 5 хештегов
            # Проверка релевантности хештега
            if self._is_hashtag_relevant_for_channel(hashtag, channel_settings):
                filtered_hashtags.append(hashtag)
        
        return filtered_hashtags
    
    def _is_hashtag_relevant_for_channel(
        self,
        hashtag: str,
        channel_settings: ChannelSettings
    ) -> bool:
        """Проверка релевантности хештега для канала"""
        hashtag_lower = hashtag.lower()
        
        # Проверка по типу аудитории
        relevance_keywords = {
            'tech': ['tech', 'technology', 'digital', 'innovation', 'ai', 'ml'],
            'business': ['business', 'entrepreneur', 'startup', 'marketing', 'sales'],
            'entertainment': ['entertainment', 'movie', 'music', 'celebrity', 'fun'],
            'news': ['news', 'current', 'update', 'breaking', 'report']
        }
        
        keywords = relevance_keywords.get(channel_settings.audience_type, [])
        return any(keyword in hashtag_lower for keyword in keywords)
    
    async def _publish_to_channel(
        self,
        content: Dict[str, Any],
        channel_id: str
    ) -> Dict[str, int]:
        """Публикация в конкретный канал"""
        # Использование Telegram бота для публикации
        from publisher.telegram_bot import telegram_bot
        
        return await telegram_bot.publish_post({
            **content,
            'channel_id': channel_id
        })
    
    def _log_cross_post_success(
        self,
        content: Dict[str, Any],
        channel_id: str,
        message_ids: Dict[str, int]
    ):
        """Логирование успешного кросс-постинга"""
        self.cross_post_history.append({
            'timestamp': datetime.now(),
            'content_id': content.get('id'),
            'channel_id': channel_id,
            'status': 'success',
            'message_ids': message_ids
        })
    
    def _log_cross_post_error(
        self,
        content: Dict[str, Any],
        channel_id: str,
        error: str
    ):
        """Логирование ошибки кросс-постинга"""
        self.cross_post_history.append({
            'timestamp': datetime.now(),
            'content_id': content.get('id'),
            'channel_id': channel_id,
            'status': 'error',
            'error': error
        })
    
    async def _load_channel_settings(self):
        """Загрузка настроек каналов"""
        # В реальном приложении - загрузка из базы данных
        # Заглушка с примерными каналами
        example_channels = [
            ChannelSettings(
                channel_id="@tech_news_channel",
                name="Tech News",
                audience_type="tech",
                language="ru",
                posting_frequency=3,
                content_preferences=["media_rich", "tech_content"],
                custom_formatting=True,
                delay_minutes=0
            ),
            ChannelSettings(
                channel_id="@business_insights",
                name="Business Insights",
                audience_type="business",
                language="ru",
                posting_frequency=2,
                content_preferences=["long_posts", "business_focus"],
                custom_formatting=True,
                delay_minutes=5
            )
        ]
        
        for channel in example_channels:
            self.channel_settings[channel.channel_id] = channel
    
    async def _process_cross_post_queue(self):
        """Обработка очереди кросс-постинга"""
        while True:
            try:
                if self.cross_post_queue:
                    task = self.cross_post_queue.pop(0)
                    await self.cross_post(**task)
                
                await asyncio.sleep(1)
                
            except Exception as e:
                logger.error(f"Ошибка в обработке очереди кросс-постинга: {e}")
                await asyncio.sleep(5)
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса модуля кросс-постинга"""
        return {
            'is_initialized': True,
            'channels_configured': len(self.channel_settings),
            'stats': self.stats,
            'rules': self.cross_post_rules,
            'queue_size': len(self.cross_post_queue),
            'history_size': len(self.cross_post_history)
        }

# Глобальный экземпляр
cross_poster = CrossPoster()