"""
Web Panel Main Module
Главный модуль веб-интерфейса управления UltraBot
"""

import asyncio
import signal
import sys
from typing import Dict, List, Any, Optional
import logging
from pathlib import Path

from flask import Flask, render_template, request, jsonify, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_required, login_user, logout_user, current_user
import json

from config import config
from routes import setup_routes
from database.models import db, User

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOGS_DIR / 'web_panel.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class WebPanelService:
    """Сервис веб-интерфейса управления"""
    
    def __init__(self):
        self.app = Flask(__name__)
        self.is_running = False
        
        # Конфигурация Flask
        self.app.config['SECRET_KEY'] = config.security.SECRET_KEY
        self.app.config['SQLALCHEMY_DATABASE_URI'] = config.database.DATABASE_URL
        self.app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        self.app.config['SESSION_TIMEOUT'] = config.web_panel.SESSION_TIMEOUT
        
        # Инициализация расширений
        db.init_app(self.app)
        self.login_manager = LoginManager()
        self.login_manager.init_app(self.app)
        self.login_manager.login_view = 'login'
        
        # Настройки безопасности
        self.app.config['SESSION_COOKIE_SECURE'] = config.web_panel.SSL_ENABLED
        self.app.config['SESSION_COOKIE_HTTPONLY'] = True
        self.app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
        
        # Статистика
        self.stats = {
            'page_views': 0,
            'api_calls': 0,
            'active_sessions': 0,
            'total_users': 0
        }
        
        # Текущие пользователи
        self.active_users: Dict[str, Dict[str, Any]] = {}
        
        # Настройка маршрутов
        self._setup_app()
        
        logger.info("Web Panel Service инициализирован")
    
    def _setup_app(self):
        """Настройка Flask приложения"""
        # Настройка пользовательской загрузки
        @self.login_manager.user_loader
        def load_user(user_id):
            return User.query.get(int(user_id))
        
        # Глобальные обработчики
        @self.app.before_request
        def before_request():
            self.stats['page_views'] += 1
            
            # Проверка таймаута сессии
            if 'last_activity' in session:
                last_activity = session['last_activity']
                if time.time() - last_activity > self.app.config['SESSION_TIMEOUT']:
                    session.clear()
                    return redirect(url_for('login'))
            
            session['last_activity'] = time.time()
        
        @self.app.after_request
        def after_request(response):
            # Добавление security headers
            response.headers['X-Content-Type-Options'] = 'nosniff'
            response.headers['X-Frame-Options'] = 'DENY'
            response.headers['X-XSS-Protection'] = '1; mode=block'
            
            return response
        
        # Настройка маршрутов
        setup_routes(self.app)
    
    async def start(self):
        """Запуск веб-интерфейса"""
        try:
            logger.info("Запуск Web Panel Service...")
            
            # Создание таблиц базы данных
            with self.app.app_context():
                db.create_all()
                await self._create_default_admin()
            
            # Обновление статуса
            self.is_running = True
            
            # Запуск Flask приложения
            import threading
            
            def run_app():
                self.app.run(
                    host=config.web_panel.HOST,
                    port=config.web_panel.PORT,
                    debug=config.base.DEBUG,
                    use_reloader=False
                )
            
            self.server_thread = threading.Thread(target=run_app)
            self.server_thread.daemon = True
            self.server_thread.start()
            
            # Запуск фоновых задач
            asyncio.create_task(self._monitoring_loop())
            asyncio.create_task(self._session_cleanup_loop())
            
            logger.info(f"Web Panel Service запущен на http://{config.web_panel.HOST}:{config.web_panel.PORT}")
            
            # Ожидание завершения
            await self._shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"Ошибка при запуске Web Panel Service: {e}")
            raise
    
    async def stop(self):
        """Остановка веб-интерфейса"""
        logger.info("Остановка Web Panel Service...")
        self.is_running = False
        
        # Очистка сессий
        session.clear()
        
        logger.info("Web Panel Service остановлен")
    
    async def get_service_status(self) -> Dict[str, Any]:
        """Получение статуса сервиса"""
        return {
            'is_running': self.is_running,
            'host': config.web_panel.HOST,
            'port': config.web_panel.PORT,
            'ssl_enabled': config.web_panel.SSL_ENABLED,
            'stats': self.stats,
            'active_users': len(self.active_users),
            'database_connected': True  # Проверка будет реализована
        }
    
    async def _create_default_admin(self):
        """Создание администратора по умолчанию"""
        try:
            # Проверка существования администратора
            admin = User.query.filter_by(username='admin').first()
            
            if not admin:
                # Создание администратора
                admin = User(
                    username='admin',
                    email='admin@ultrabot.com',
                    is_admin=True
                )
                admin.set_password(config.security.ADMIN_PASSWORD)
                
                db.session.add(admin)
                db.session.commit()
                
                logger.info("Администратор по умолчанию создан")
            
        except Exception as e:
            logger.error(f"Ошибка при создании администратора: {e}")
            db.session.rollback()
    
    async def _monitoring_loop(self):
        """Цикл мониторинга веб-интерфейса"""
        while self.is_running:
            try:
                # Обновление статистики каждые 5 минут
                await asyncio.sleep(300)
                
                # Обновление количества пользователей
                with self.app.app_context():
                    self.stats['total_users'] = User.query.count()
                
                # Логирование статистики
                logger.info(f"Web Panel Stats: {self.stats}")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга: {e}")
    
    async def _session_cleanup_loop(self):
        """Цикл очистки устаревших сессий"""
        while self.is_running:
            try:
                # Очистка каждый час
                await asyncio.sleep(3600)
                
                # Очистка устаревших сессий
                current_time = time.time()
                timeout = self.app.config['SESSION_TIMEOUT']
                
                expired_sessions = [
                    session_id for session_id, session_data in self.active_users.items()
                    if current_time - session_data.get('last_activity', 0) > timeout
                ]
                
                for session_id in expired_sessions:
                    del self.active_users[session_id]
                
                if expired_sessions:
                    logger.info(f"Очищены устаревшие сессии: {len(expired_sessions)}")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле очистки сессий: {e}")

# Обработка сигналов
def signal_handler(signum, frame):
    """Обработчик системных сигналов"""
    logger.info(f"Получен сигнал {signum}")
    
    if signum == signal.SIGTERM:
        asyncio.create_task(web_panel.stop())
    elif signum == signal.SIGINT:
        asyncio.create_task(web_panel.stop())

# Глобальный экземпляр
web_panel = WebPanelService()

async def main():
    """Главная функция"""
    # Установка обработчиков сигналов
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        await web_panel.start()
    except KeyboardInterrupt:
        logger.info("Получено прерывание от пользователя")
        await web_panel.stop()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        await web_panel.stop()

if __name__ == "__main__":
    asyncio.run(main())