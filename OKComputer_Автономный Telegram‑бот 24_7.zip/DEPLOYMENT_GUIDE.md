# UltraBot Deployment Guide

## Overview
This guide provides comprehensive instructions for deploying the UltraBot Telegram management system in various environments.

## System Requirements

### Minimum Requirements
- **Python**: 3.8 or higher
- **RAM**: 2GB minimum, 4GB recommended
- **Storage**: 10GB minimum, 50GB recommended
- **Network**: Stable internet connection (minimum 1 Mbps)

### Recommended Requirements
- **Python**: 3.9 or higher
- **RAM**: 8GB or more
- **Storage**: 100GB SSD or better
- **Network**: 10 Mbps or higher

## Installation Methods

### Method 1: Docker Deployment (Recommended)

#### Prerequisites
- Docker 20.10 or higher
- Docker Compose 2.0 or higher

#### Steps
1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/ultrabot.git
   cd ultrabot
   ```

2. **Configure environment variables**
   ```bash
   cp .env.example .env
   # Edit .env file with your settings
   ```

3. **Build and start containers**
   ```bash
   docker-compose up -d --build
   ```

4. **Check container status**
   ```bash
   docker-compose ps
   docker-compose logs
   ```

### Method 2: Manual Installation

#### Prerequisites
- Python 3.8+ with pip
- PostgreSQL 12+ (optional, SQLite included)
- Redis 6+ (optional, for caching)

#### Steps
1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/ultrabot.git
   cd ultrabot
   ```

2. **Create virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env file with your settings
   ```

5. **Run the application**
   ```bash
   python main.py
   ```

## Configuration

### Environment Variables (.env)

#### Required Settings
```bash
# Telegram Bot Configuration
TELEGRAM_BOT_TOKEN=your_bot_token_here
TELEGRAM_API_ID=your_api_id
TELEGRAM_API_HASH=your_api_hash

# Database Configuration
DATABASE_URL=postgresql://user:password@localhost/ultrabot
# Or use SQLite: DATABASE_URL=sqlite:///ultrabot.db

# Redis Configuration (Optional)
REDIS_URL=redis://localhost:6379/0

# Web Panel Configuration
WEB_PANEL_HOST=0.0.0.0
WEB_PANEL_PORT=5000
WEB_PANEL_SECRET_KEY=your_secret_key_here

# Security Configuration
JWT_SECRET_KEY=your_jwt_secret_here
ENCRYPTION_KEY=your_encryption_key_here
```

#### Optional Settings
```bash
# Email Configuration (for alerts)
SMTP_SERVER=smtp.gmail.com
SMTP_PORT=587
SMTP_USERNAME=your_email@gmail.com
SMTP_PASSWORD=your_app_password
ALERT_EMAIL=alerts@yourdomain.com

# Monitoring Configuration
ENABLE_MONITORING=true
MONITORING_INTERVAL=60

# ML Configuration
ML_MODEL_PATH=./models/
ENABLE_ML_OPTIMIZATION=true

# Rate Limiting
RATE_LIMIT_LOGIN=5
RATE_LIMIT_WINDOW=300
```

### Telegram Bot Setup

1. **Create a new bot**
   - Message @BotFather on Telegram
   - Use `/newbot` command
   - Follow the instructions to get your bot token

2. **Get API credentials**
   - Visit https://my.telegram.org
   - Login with your phone number
   - Create a new application to get API ID and Hash

3. **Configure bot settings**
   - Set privacy mode to disabled
   - Add bot to your channels as admin
   - Grant necessary permissions

## Deployment Environments

### Local Development

1. **Quick start for development**
   ```bash
   # Using Docker
   docker-compose -f docker-compose.dev.yml up -d
   
   # Or manual installation
   python main.py --dev
   ```

2. **Access the web panel**
   - URL: http://localhost:5000
   - Default credentials: admin / admin (change immediately)

### Production Deployment

#### Using Docker Compose
```bash
# Production deployment
docker-compose -f docker-compose.prod.yml up -d

# With SSL (using Traefik)
docker-compose -f docker-compose.ssl.yml up -d
```

#### Using Kubernetes
```bash
# Deploy to Kubernetes
kubectl apply -f k8s/

# Check deployment status
kubectl get pods
kubectl get services
```

#### Using SystemD (Linux)
1. **Create service file**
   ```bash
   sudo nano /etc/systemd/system/ultrabot.service
   ```

2. **Add service configuration**
   ```ini
   [Unit]
   Description=UltraBot Telegram Management System
   After=network.target

   [Service]
   Type=simple
   User=ultrabot
   WorkingDirectory=/opt/ultrabot
   ExecStart=/opt/ultrabot/venv/bin/python main.py
   Restart=always
   RestartSec=10

   [Install]
   WantedBy=multi-user.target
   ```

3. **Enable and start service**
   ```bash
   sudo systemctl enable ultrabot
   sudo systemctl start ultrabot
   sudo systemctl status ultrabot
   ```

### Cloud Deployment

#### AWS Deployment
1. **Using EC2**
   ```bash
   # Launch EC2 instance (Ubuntu 20.04)
   # Install Docker and Docker Compose
   sudo apt update
   sudo apt install docker.io docker-compose
   
   # Deploy application
   git clone https://github.com/yourusername/ultrabot.git
   cd ultrabot
   docker-compose up -d
   ```

2. **Using ECS (Elastic Container Service)**
   ```bash
   # Build and push to ECR
   aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789012.dkr.ecr.us-east-1.amazonaws.com
   docker build -t ultrabot .
   docker tag ultrabot:latest 123456789012.dkr.ecr.us-east-1.amazonaws.com/ultrabot:latest
   docker push 123456789012.dkr.ecr.us-east-1.amazonaws.com/ultrabot:latest
   ```

#### Google Cloud Platform
```bash
# Using Google Cloud Run
gcloud run deploy ultrabot \
  --image gcr.io/PROJECT_ID/ultrabot \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated

# Using GKE (Google Kubernetes Engine)
gcloud container clusters create ultrabot-cluster \
  --num-nodes=3 \
  --machine-type=n1-standard-2

kubectl apply -f k8s/
```

#### DigitalOcean
```bash
# Using App Platform
doctl apps create --spec .do/app.yaml

# Using Droplet
# Create Droplet with Docker
# Follow Docker deployment steps
```

## Security Considerations

### 1. Network Security
- Use HTTPS/SSL certificates
- Configure firewall rules
- Use VPN for database connections
- Enable rate limiting

### 2. Application Security
- Change default passwords immediately
- Use strong JWT secrets
- Enable two-factor authentication
- Regular security updates

### 3. Database Security
- Use strong database passwords
- Enable database encryption
- Regular backups
- Restrict database access

### 4. Telegram Security
- Keep bot token secure
- Use session management
- Monitor for unauthorized access
- Regular token rotation

## Monitoring and Maintenance

### Health Checks
```bash
# Check application health
curl http://localhost:5000/health

# Check database connectivity
curl http://localhost:5000/health/db

# Check Redis connectivity
curl http://localhost:5000/health/redis
```

### Log Management
```bash
# View logs
docker-compose logs -f

# View specific service logs
docker-compose logs -f ultrabot

# Clear logs
docker-compose logs --tail 0 -f > /dev/null
```

### Backup Procedures
```bash
# Database backup
docker exec ultrabot_db pg_dump -U ultrabot ultrabot > backup.sql

# Configuration backup
tar -czf ultrabot-config-backup.tar.gz .env docker-compose.yml

# Full system backup
docker-compose exec ultrabot tar -czf /tmp/ultrabot-backup.tar.gz /app
```

## Troubleshooting

### Common Issues

1. **Bot not responding**
   - Check bot token configuration
   - Verify network connectivity
   - Check Telegram API status

2. **Database connection errors**
   - Verify database credentials
   - Check database server status
   - Verify network connectivity

3. **Web panel not accessible**
   - Check firewall settings
   - Verify service is running
   - Check port configuration

4. **Performance issues**
   - Monitor system resources
   - Check database performance
   - Optimize configuration

### Debug Mode
```bash
# Enable debug mode
docker-compose -f docker-compose.yml -f docker-compose.debug.yml up -d

# Or manually
python main.py --debug
```

### Log Analysis
```bash
# Search for errors
docker-compose logs | grep ERROR

# Monitor real-time logs
docker-compose logs -f --tail=100

# Export logs for analysis
docker-compose logs --no-color > ultrabot-logs.txt
```

## Scaling

### Horizontal Scaling
```bash
# Scale web panel instances
docker-compose up -d --scale ultrabot=3

# Scale worker instances
docker-compose up -d --scale worker=5

# Using Kubernetes HPA
kubectl autoscale deployment ultrabot --cpu-percent=70 --min=2 --max=10
```

### Vertical Scaling
```bash
# Update resource limits in docker-compose.yml
services:
  ultrabot:
    deploy:
      resources:
        limits:
          cpus: '2.0'
          memory: 4G
        reservations:
          cpus: '1.0'
          memory: 2G
```

## Support and Maintenance

### Regular Maintenance Tasks
1. **Daily**: Check system health, monitor logs
2. **Weekly**: Review performance metrics, update dependencies
3. **Monthly**: Security updates, backup verification
4. **Quarterly**: Full system review, capacity planning

### Getting Help
- Check the troubleshooting section
- Review application logs
- Consult documentation
- Contact support team

## Conclusion

This deployment guide provides comprehensive instructions for deploying UltraBot in various environments. Choose the deployment method that best fits your requirements and follow the security best practices to ensure a secure and reliable installation.

For additional support or questions, please refer to the project documentation or contact the development team.