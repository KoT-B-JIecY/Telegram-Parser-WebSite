"""
Content Moderation Module
Модерация контента для фильтрации неподходящего материала
"""

import asyncio
import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

@dataclass
class ModerationResult:
    """Результат модерации"""
    is_appropriate: bool
    confidence: float
    reason: Optional[str] = None
    categories: List[str] = None
    severity: str = 'low'  # low, medium, high, critical
    action: str = 'allow'  # allow, review, block

@dataclass
class ModerationRule:
    """Правило модерации"""
    id: str
    name: str
    pattern: str
    category: str
    severity: str
    action: str
    description: str
    enabled: bool = True

class ContentModerator:
    """Модератор контента"""
    
    def __init__(self):
        # Правила модерации
        self.moderation_rules = self._load_moderation_rules()
        
        # Категории контента
        self.content_categories = {
            'safe': ['education', 'news', 'technology', 'business', 'science'],
            'sensitive': ['politics', 'religion', 'health', 'finance'],
            'restricted': ['adult', 'violence', 'hate', 'spam', 'misinformation']
        }
        
        # Настройки модерации
        self.moderation_settings = {
            'profanity_filter': True,
            'spam_detection': True,
            'duplicate_detection': True,
            'quality_check': True,
            'auto_moderation': True,
            'confidence_threshold': 0.7
        }
        
        # Кэш результатов модерации
        self._moderation_cache: Dict[str, ModerationResult] = {}
        self._cache_ttl = 3600  # 1 час
        
        # Статистика
        self.stats = {
            'content_checked': 0,
            'content_approved': 0,
            'content_rejected': 0,
            'content_flagged': 0,
            'rules_triggered': 0,
            'false_positives': 0
        }
        
        # История модерации для обучения
        self.moderation_history: List[Dict[str, Any]] = []
        
        logger.info("Content Moderator инициализирован")
    
    async def initialize(self):
        """Инициализация модератора"""
        logger.info("Инициализация Content Moderator...")
        
        # Загрузка ML моделей для модерации (в реальном приложении)
        # Например: toxicity detection models, spam classifiers
        
        logger.info("Content Moderator инициализирован")
    
    async def check_content(self, content: Dict[str, Any]) -> ModerationResult:
        """
        Проверка контента на соответствие правилам
        
        Args:
            content: Контент для проверки
            
        Returns:
            Результат модерации
        """
        start_time = datetime.now()
        
        # Формирование ключа для кэша
        cache_key = self._generate_cache_key(content)
        
        # Проверка кэша
        if cache_key in self._moderation_cache:
            logger.debug("Результат модерации взят из кэша")
            return self._mooderation_cache[cache_key]
        
        try:
            text_to_check = f"{content.get('title', '')} {content.get('content', '')}"
            
            if not text_to_check.strip():
                result = ModerationResult(
                    is_appropriate=True,
                    confidence=1.0,
                    reason="Empty content",
                    categories=['empty'],
                    severity='low',
                    action='allow'
                )
            else:
                # Выполнение проверок
                checks = await asyncio.gather(
                    self._check_profanity(text_to_check),
                    self._check_spam(content),
                    self._check_duplicates(content),
                    self._check_quality(content),
                    self._check_restricted_content(text_to_check),
                    self._check_sentiment(text_to_check)
                )
                
                # Объединение результатов
                result = self._combine_check_results(checks)
            
            # Кэширование результата
            self._moderation_cache[cache_key] = result
            
            # Обновление статистики
            self.stats['content_checked'] += 1
            
            if result.action == 'allow':
                self.stats['content_approved'] += 1
            elif result.action == 'block':
                self.stats['content_rejected'] += 1
            elif result.action == 'review':
                self.stats['content_flagged'] += 1
            
            # Сохранение в историю
            self.moderation_history.append({
                'timestamp': start_time,
                'content_hash': cache_key,
                'result': result,
                'processing_time': (datetime.now() - start_time).total_seconds()
            })
            
            # Ограничение размера истории
            if len(self.moderation_history) > 10000:
                self.moderation_history = self.moderation_history[-5000:]
            
            logger.debug(f"Модерация завершена: {result.action} (confidence: {result.confidence:.2f})")
            return result
            
        except Exception as e:
            logger.error(f"Ошибка при модерации контента: {e}")
            # Возврат безопасного результата
            return ModerationResult(
                is_appropriate=True,
                confidence=0.5,
                reason="Error during moderation",
                categories=['error'],
                severity='low',
                action='allow'
            )
    
    async def _check_profanity(self, text: str) -> ModerationResult:
        """Проверка на ненормативную лексику"""
        if not self.moderation_settings['profanity_filter']:
            return ModerationResult(True, 1.0, action='allow')
        
        # Базовые паттерны для нецензурной лексики
        profanity_patterns = [
            r'\b(сука|блядь|хуй|пизда|ебать|ебаный|ебать|ебало)\b',
            r'\b(fuck|shit|bitch|asshole|damn|crap)\b',
            r'\b(су+ка+|бля+ть+|ху+й+)',
            r'\b(f+u+c+k+|s+h+i+t+|b+i+t+c+h+)'
        ]
        
        text_lower = text.lower()
        profanity_found = []
        
        for pattern in profanity_patterns:
            matches = re.findall(pattern, text_lower, re.IGNORECASE)
            if matches:
                profanity_found.extend(matches)
        
        if profanity_found:
            profanity_ratio = len(profanity_found) / len(text.split())
            confidence = min(0.95, profanity_ratio * 10)
            
            return ModerationResult(
                is_appropriate=False,
                confidence=confidence,
                reason=f"Profanity detected: {', '.join(profanity_found[:3])}",
                categories=['profanity'],
                severity='high' if profanity_ratio > 0.05 else 'medium',
                action='block' if profanity_ratio > 0.1 else 'review'
            )
        
        return ModerationResult(True, 0.9, action='allow')
    
    async def _check_spam(self, content: Dict[str, Any]) -> ModerationResult:
        """Проверка на спам"""
        if not self.moderation_settings['spam_detection']:
            return ModerationResult(True, 1.0, action='allow')
        
        text = f"{content.get('title', '')} {content.get('content', '')}"
        
        # Признаки спама
        spam_indicators = {
            'excessive_caps': len(re.findall(r'[A-ZА-Я]', text)) / len(text) > 0.3,
            'excessive_exclamation': text.count('!') > 5,
            'repeated_words': len(set(text.lower().split())) < len(text.split()) * 0.5,
            'url_count': len(re.findall(r'http[s]?://', text)),
            'phone_numbers': len(re.findall(r'\+?\d{10,}', text)),
            'email_count': len(re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text))
        }
        
        spam_score = sum([
            2 if spam_indicators['excessive_caps'] else 0,
            2 if spam_indicators['excessive_exclamation'] else 0,
            3 if spam_indicators['repeated_words'] else 0,
            spam_indicators['url_count'],
            spam_indicators['phone_numbers'],
            spam_indicators['email_count']
        ])
        
        if spam_score > 3:
            return ModerationResult(
                is_appropriate=False,
                confidence=min(0.9, spam_score / 10),
                reason=f"Spam indicators detected: {spam_score} points",
                categories=['spam'],
                severity='medium',
                action='review' if spam_score < 6 else 'block'
            )
        
        return ModerationResult(True, 0.8, action='allow')
    
    async def _check_duplicates(self, content: Dict[str, Any]) -> ModerationResult:
        """Проверка на дубликаты"""
        if not self.moderation_settings['duplicate_detection']:
            return ModerationResult(True, 1.0, action='allow')
        
        # Простая проверка на основе хеша
        content_hash = self._generate_content_hash(content)
        
        # Проверка в истории
        for history_item in self.moderation_history[-1000:]:  # Последние 1000
            if history_item['content_hash'] == content_hash:
                time_diff = (datetime.now() - history_item['timestamp']).total_seconds()
                if time_diff < 3600:  # Повтор за последний час
                    return ModerationResult(
                        is_appropriate=False,
                        confidence=0.95,
                        reason="Duplicate content detected",
                        categories=['duplicate'],
                        severity='low',
                        action='block'
                    )
        
        return ModerationResult(True, 0.9, action='allow')
    
    async def _check_quality(self, content: Dict[str, Any]) -> ModerationResult:
        """Проверка качества контента"""
        if not self.moderation_settings['quality_check']:
            return ModerationResult(True, 1.0, action='allow')
        
        text = f"{content.get('title', '')} {content.get('content', '')}"
        
        # Метрики качества
        word_count = len(text.split())
        sentence_count = len(re.split(r'[.!?]+', text))
        avg_sentence_length = word_count / max(sentence_count, 1)
        
        quality_issues = []
        
        if word_count < 50:
            quality_issues.append("Too short")
        
        if avg_sentence_length > 30:
            quality_issues.append("Sentences too long")
        
        if avg_sentence_length < 5:
            quality_issues.append("Sentences too short")
        
        # Проверка на повторяющиеся слова
        words = text.lower().split()
        unique_ratio = len(set(words)) / len(words) if words else 1
        if unique_ratio < 0.5:
            quality_issues.append("High word repetition")
        
        if quality_issues:
            return ModerationResult(
                is_appropriate=False,
                confidence=0.7,
                reason=f"Quality issues: {', '.join(quality_issues)}",
                categories=['low_quality'],
                severity='low',
                action='review'
            )
        
        return ModerationResult(True, 0.8, action='allow')
    
    async def _check_restricted_content(self, text: str) -> ModerationResult:
        """Проверка запрещенного контента"""
        # Проверка по правилам
        for rule in self.moderation_rules:
            if not rule.enabled:
                continue
            
            if re.search(rule.pattern, text, re.IGNORECASE):
                self.stats['rules_triggered'] += 1
                return ModerationResult(
                    is_appropriate=False,
                    confidence=0.9,
                    reason=f"Rule triggered: {rule.name}",
                    categories=[rule.category],
                    severity=rule.severity,
                    action=rule.action
                )
        
        return ModerationResult(True, 0.9, action='allow')
    
    async def _check_sentiment(self, text: str) -> ModerationResult:
        """Проверка тональности"""
        # Простой анализ тональности
        negative_words = ['ужас', 'плохо', 'отвратительно', 'ненавижу', 'разочарование']
        positive_words = ['отлично', 'прекрасно', 'замечательно', 'люблю', 'восторг']
        
        text_lower = text.lower()
        negative_count = sum(1 for word in negative_words if word in text_lower)
        positive_count = sum(1 for word in positive_words if word in text_lower)
        
        if negative_count > positive_count + 2:
            return ModerationResult(
                is_appropriate=True,
                confidence=0.6,
                reason="Highly negative sentiment",
                categories=['negative_sentiment'],
                severity='low',
                action='review'
            )
        
        return ModerationResult(True, 0.8, action='allow')
    
    def _combine_check_results(self, results: List[ModerationResult]) -> ModerationResult:
        """Объединение результатов всех проверок"""
        # Фильтрация результатов с действиями
        blocking_results = [r for r in results if r.action == 'block']
        review_results = [r for r in results if r.action == 'review']
        
        if blocking_results:
            # Блокировка имеет наивысший приоритет
            worst_result = max(blocking_results, key=lambda x: x.confidence)
            return worst_result
        
        elif review_results:
            # Ревью второй по приоритету
            return max(review_results, key=lambda x: x.confidence)
        
        else:
            # Все проверки пройдены
            avg_confidence = sum(r.confidence for r in results) / len(results)
            return ModerationResult(True, avg_confidence, action='allow')
    
    def _load_moderation_rules(self) -> List[ModerationRule]:
        """Загрузка правил модерации"""
        rules = [
            # Ненормативная лексика
            ModerationRule(
                id='profanity_1',
                name='Profanity Detection',
                pattern=r'\b(сука|блядь|хуй|пизда|ебать)\b',
                category='profanity',
                severity='high',
                action='block',
                description='Russian profanity words'
            ),
            
            # Спам и реклама
            ModerationRule(
                id='spam_1',
                name='Excessive Links',
                pattern=r'http[s]?://.*\s+http[s]?://.*\s+http[s]?://.*',
                category='spam',
                severity='medium',
                action='review',
                description='Multiple URLs in content'
            ),
            
            # Контактная информация
            ModerationRule(
                id='contact_1',
                name='Phone Numbers',
                pattern=r'\+?\d{3,}\s+\d{3,}\s+\d{3,}',
                category='contact_info',
                severity='low',
                action='review',
                description='Phone number patterns'
            ),
            
            # Запрещенные темы
            ModerationRule(
                id='restricted_1',
                name='Adult Content',
                pattern=r'\b(порно|sex|xxx|adult)\b',
                category='adult',
                severity='high',
                action='block',
                description='Adult content keywords'
            )
        ]
        
        return rules
    
    def _generate_cache_key(self, content: Dict[str, Any]) -> str:
        """Генерация ключа для кэширования"""
        import hashlib
        content_str = f"{content.get('title', '')}{content.get('content', '')}"
        return hashlib.md5(content_str.encode()).hexdigest()
    
    def _generate_content_hash(self, content: Dict[str, Any]) -> str:
        """Генерация хеша контента для проверки дубликатов"""
        import hashlib
        content_str = f"{content.get('title', '')}{content.get('content', '')}"
        return hashlib.sha256(content_str.encode()).hexdigest()
    
    async def update_rules(self, new_rules: List[ModerationRule]):
        """Обновление правил модерации"""
        self.moderation_rules = new_rules
        logger.info(f"Обновлено {len(new_rules)} правил модерации")
    
    async def get_moderation_stats(self) -> Dict[str, Any]:
        """Получение статистики модерации"""
        return {
            'stats': self.stats,
            'rules_count': len(self.moderation_rules),
            'rules_enabled': sum(1 for rule in self.moderation_rules if rule.enabled),
            'history_size': len(self.moderation_history),
            'cache_size': len(self._moderation_cache)
        }
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса модуля модерации"""
        return {
            'is_initialized': True,
            'rules_loaded': len(self.moderation_rules) > 0,
            'settings': self.moderation_settings,
            'stats': await self.get_moderation_stats()
        }

# Глобальный экземпляр
content_moderator = ContentModerator()