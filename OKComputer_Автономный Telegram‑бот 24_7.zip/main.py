#!/usr/bin/env python3
"""
UltraBot - Advanced Telegram Bot Management System
Main entry point for the application
"""

import asyncio
import logging
import sys
import signal
import os
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from core.main import UltraBotCore
from web_panel.main import WebPanelService
from monitoring.monitor import system_monitor
from security.security import security_manager
from database.models import db_manager

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('ultrabot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class UltraBotApplication:
    def __init__(self):
        self.core = None
        self.web_panel = None
        self.running = False
        
    async def start(self):
        """Start the UltraBot application"""
        logger.info("Starting UltraBot application...")
        
        try:
            # Initialize database
            logger.info("Initializing database...")
            db_manager.setup_database()
            
            # Start system monitoring
            logger.info("Starting system monitoring...")
            system_monitor.start_monitoring()
            
            # Start core services
            logger.info("Starting core services...")
            self.core = UltraBotCore()
            await self.core.start()
            
            # Start web panel
            logger.info("Starting web panel...")
            self.web_panel = WebPanelService()
            await self.web_panel.start()
            
            self.running = True
            logger.info("UltraBot application started successfully!")
            
            # Keep the application running
            await self._keep_alive()
            
        except Exception as e:
            logger.error(f"Error starting UltraBot: {e}")
            await self.stop()
            raise
    
    async def stop(self):
        """Stop the UltraBot application"""
        logger.info("Stopping UltraBot application...")
        
        self.running = False
        
        try:
            # Stop web panel
            if self.web_panel:
                await self.web_panel.stop()
                logger.info("Web panel stopped")
            
            # Stop core services
            if self.core:
                await self.core.stop()
                logger.info("Core services stopped")
            
            # Stop monitoring
            system_monitor.stop_monitoring()
            logger.info("System monitoring stopped")
            
            logger.info("UltraBot application stopped successfully!")
            
        except Exception as e:
            logger.error(f"Error stopping UltraBot: {e}")
    
    async def _keep_alive(self):
        """Keep the application running"""
        try:
            while self.running:
                await asyncio.sleep(1)
        except asyncio.CancelledError:
            logger.info("Application shutdown requested")
            await self.stop()
    
    def handle_signal(self, signum, frame):
        """Handle shutdown signals"""
        logger.info(f"Received signal {signum}")
        self.running = False

def main():
    """Main entry point"""
    # Create application instance
    app = UltraBotApplication()
    
    # Set up signal handlers
    signal.signal(signal.SIGINT, app.handle_signal)
    signal.signal(signal.SIGTERM, app.handle_signal)
    
    # Run the application
    try:
        asyncio.run(app.start())
    except KeyboardInterrupt:
        logger.info("Application interrupted by user")
    except Exception as e:
        logger.error(f"Application error: {e}")
        sys.exit(1)
    finally:
        logger.info("Application shutdown complete")

if __name__ == "__main__":
    main()