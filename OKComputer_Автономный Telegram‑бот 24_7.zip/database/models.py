import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import json
import logging

class DatabaseManager:
    def __init__(self, db_path: str = "ultrabot.db"):
        self.db_path = db_path
        self.logger = logging.getLogger(__name__)
        self.setup_database()
    
    def setup_database(self):
        """Initialize all database tables"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Channels table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS channels (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id TEXT UNIQUE NOT NULL,
                channel_name TEXT NOT NULL,
                channel_type TEXT DEFAULT 'telegram',
                subscriber_count INTEGER DEFAULT 0,
                is_active BOOLEAN DEFAULT true,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                settings TEXT DEFAULT '{}'
            )
        ''')
        
        # Content table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_id TEXT UNIQUE NOT NULL,
                channel_id TEXT NOT NULL,
                content_type TEXT DEFAULT 'text',
                title TEXT,
                content TEXT NOT NULL,
                status TEXT DEFAULT 'draft',
                scheduled_time DATETIME,
                published_time DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                metadata TEXT DEFAULT '{}',
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id)
            )
        ''')
        
        # Content variants table for A/B testing
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content_variants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                variant_id TEXT UNIQUE NOT NULL,
                original_content_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                content TEXT NOT NULL,
                variant_type TEXT NOT NULL,
                status TEXT DEFAULT 'active',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                test_results TEXT DEFAULT '{}',
                FOREIGN KEY (original_content_id) REFERENCES content (content_id),
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id)
            )
        ''')
        
        # Performance metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                variant_id TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                views INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                shares INTEGER DEFAULT 0,
                likes INTEGER DEFAULT 0,
                comments INTEGER DEFAULT 0,
                engagement_rate REAL DEFAULT 0,
                click_through_rate REAL DEFAULT 0,
                conversion_rate REAL DEFAULT 0,
                reach INTEGER DEFAULT 0,
                impressions INTEGER DEFAULT 0,
                audience_segment TEXT DEFAULT 'general',
                FOREIGN KEY (content_id) REFERENCES content (content_id),
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id),
                FOREIGN KEY (variant_id) REFERENCES content_variants (variant_id)
            )
        ''')
        
        # Tasks table for scheduler
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tasks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id TEXT UNIQUE NOT NULL,
                task_type TEXT NOT NULL,
                priority INTEGER DEFAULT 5,
                status TEXT DEFAULT 'pending',
                channel_id TEXT,
                content_id TEXT,
                scheduled_time DATETIME,
                executed_time DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                parameters TEXT DEFAULT '{}',
                results TEXT DEFAULT '{}',
                error_message TEXT,
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id),
                FOREIGN KEY (content_id) REFERENCES content (content_id)
            )
        ''')
        
        # Users table for web panel
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT DEFAULT 'user',
                is_active BOOLEAN DEFAULT true,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                last_login DATETIME,
                settings TEXT DEFAULT '{}'
            )
        ''')
        
        # Sessions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT UNIQUE NOT NULL,
                user_id INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                expires_at DATETIME NOT NULL,
                ip_address TEXT,
                user_agent TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # System logs table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS system_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                level TEXT NOT NULL,
                component TEXT NOT NULL,
                message TEXT NOT NULL,
                details TEXT,
                user_id INTEGER,
                channel_id TEXT,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id)
            )
        ''')
        
        # Configuration table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS configuration (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                config_key TEXT UNIQUE NOT NULL,
                config_value TEXT NOT NULL,
                description TEXT,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_by INTEGER,
                FOREIGN KEY (updated_by) REFERENCES users (id)
            )
        ''')
        
        # ML training data table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ml_training_data (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                content_length INTEGER,
                has_hashtags INTEGER,
                has_mentions INTEGER,
                has_media INTEGER,
                posting_hour INTEGER,
                day_of_week INTEGER,
                channel_size INTEGER,
                recent_activity REAL,
                content_sentiment REAL,
                has_call_to_action INTEGER,
                is_question INTEGER,
                trending_topics_count INTEGER,
                engagement_rate REAL,
                reach INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (content_id) REFERENCES content (content_id),
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id)
            )
        ''')
        
        # Content performance summary table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content_performance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_id TEXT NOT NULL,
                channel_id TEXT NOT NULL,
                content_type TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                views INTEGER DEFAULT 0,
                engagement_rate REAL DEFAULT 0,
                reach INTEGER DEFAULT 0,
                shares INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                FOREIGN KEY (content_id) REFERENCES content (content_id),
                FOREIGN KEY (channel_id) REFERENCES channels (channel_id)
            )
        ''')
        
        # Create indexes for better performance
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_content_channel ON content (channel_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_content_status ON content (status)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_performance_content ON performance_metrics (content_id)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_performance_timestamp ON performance_metrics (timestamp)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks (status, scheduled_time)')
        cursor.execute('CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions (expires_at)')
        
        conn.commit()
        conn.close()
        
        self.logger.info("Database tables initialized successfully")
    
    def add_channel(self, channel_id: str, channel_name: str, 
                   channel_type: str = 'telegram', settings: Dict = None) -> bool:
        """Add a new channel to the system"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT OR REPLACE INTO channels 
                (channel_id, channel_name, channel_type, settings)
                VALUES (?, ?, ?, ?)
            ''', (
                channel_id,
                channel_name,
                channel_type,
                json.dumps(settings or {})
            ))
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"Channel {channel_id} added successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding channel: {e}")
            return False
    
    def add_content(self, content_id: str, channel_id: str, content: str,
                   content_type: str = 'text', title: str = None,
                   scheduled_time: datetime = None, metadata: Dict = None) -> bool:
        """Add new content to the system"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO content 
                (content_id, channel_id, content_type, title, content, 
                 scheduled_time, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                content_id,
                channel_id,
                content_type,
                title,
                content,
                scheduled_time.isoformat() if scheduled_time else None,
                json.dumps(metadata or {})
            ))
            
            conn.commit()
            conn.close()
            
            self.logger.info(f"Content {content_id} added successfully")
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding content: {e}")
            return False
    
    def update_content_status(self, content_id: str, status: str, 
                            published_time: datetime = None) -> bool:
        """Update content status"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE content 
                SET status = ?, published_time = ?, updated_at = CURRENT_TIMESTAMP
                WHERE content_id = ?
            ''', (status, published_time.isoformat() if published_time else None, content_id))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error updating content status: {e}")
            return False
    
    def add_performance_metrics(self, content_id: str, channel_id: str,
                              metrics: Dict) -> bool:
        """Add performance metrics for content"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO performance_metrics 
                (content_id, channel_id, variant_id, views, clicks, shares, 
                 likes, comments, engagement_rate, click_through_rate, 
                 conversion_rate, reach, impressions, audience_segment)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                content_id,
                channel_id,
                metrics.get('variant_id'),
                metrics.get('views', 0),
                metrics.get('clicks', 0),
                metrics.get('shares', 0),
                metrics.get('likes', 0),
                metrics.get('comments', 0),
                metrics.get('engagement_rate', 0),
                metrics.get('click_through_rate', 0),
                metrics.get('conversion_rate', 0),
                metrics.get('reach', 0),
                metrics.get('impressions', 0),
                metrics.get('audience_segment', 'general')
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding performance metrics: {e}")
            return False
    
    def add_task(self, task_id: str, task_type: str, priority: int = 5,
                channel_id: str = None, content_id: str = None,
                scheduled_time: datetime = None, parameters: Dict = None) -> bool:
        """Add a new task to the queue"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO tasks 
                (task_id, task_type, priority, channel_id, content_id, 
                 scheduled_time, parameters)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                task_id,
                task_type,
                priority,
                channel_id,
                content_id,
                scheduled_time.isoformat() if scheduled_time else None,
                json.dumps(parameters or {})
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding task: {e}")
            return False
    
    def update_task_status(self, task_id: str, status: str, 
                         results: Dict = None, error_message: str = None) -> bool:
        """Update task status and results"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE tasks 
                SET status = ?, results = ?, error_message = ?, 
                    executed_time = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
                WHERE task_id = ?
            ''', (
                status,
                json.dumps(results or {}),
                error_message,
                task_id
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error updating task status: {e}")
            return False
    
    def get_pending_tasks(self, limit: int = 100) -> List[Dict]:
        """Get pending tasks ordered by priority and scheduled time"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM tasks 
                WHERE status = 'pending' 
                AND (scheduled_time IS NULL OR scheduled_time <= CURRENT_TIMESTAMP)
                ORDER BY priority ASC, created_at ASC
                LIMIT ?
            ''', (limit,))
            
            tasks = []
            for row in cursor.fetchall():
                task = {
                    'id': row[0],
                    'task_id': row[1],
                    'task_type': row[2],
                    'priority': row[3],
                    'status': row[4],
                    'channel_id': row[5],
                    'content_id': row[6],
                    'scheduled_time': row[7],
                    'parameters': json.loads(row[11] or '{}')
                }
                tasks.append(task)
            
            conn.close()
            return tasks
            
        except Exception as e:
            self.logger.error(f"Error getting pending tasks: {e}")
            return []
    
    def get_channel_performance(self, channel_id: str, days: int = 30) -> Dict:
        """Get channel performance summary"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            start_date = datetime.now() - timedelta(days=days)
            
            cursor.execute('''
                SELECT 
                    COUNT(*) as total_posts,
                    AVG(engagement_rate) as avg_engagement,
                    AVG(reach) as avg_reach,
                    SUM(views) as total_views,
                    SUM(clicks) as total_clicks,
                    SUM(shares) as total_shares
                FROM performance_metrics 
                WHERE channel_id = ? AND timestamp >= ?
            ''', (channel_id, start_date.isoformat()))
            
            result = cursor.fetchone()
            conn.close()
            
            if result and result[0] > 0:
                return {
                    'total_posts': result[0],
                    'avg_engagement': round(result[1] or 0, 4),
                    'avg_reach': int(result[2] or 0),
                    'total_views': result[3] or 0,
                    'total_clicks': result[4] or 0,
                    'total_shares': result[5] or 0
                }
            else:
                return {
                    'total_posts': 0,
                    'avg_engagement': 0,
                    'avg_reach': 0,
                    'total_views': 0,
                    'total_clicks': 0,
                    'total_shares': 0
                }
                
        except Exception as e:
            self.logger.error(f"Error getting channel performance: {e}")
            return {}
    
    def add_user(self, username: str, password_hash: str, email: str = None,
                role: str = 'user') -> bool:
        """Add a new user to the system"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO users (username, email, password_hash, role)
                VALUES (?, ?, ?, ?)
            ''', (username, email, password_hash, role))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error adding user: {e}")
            return False
    
    def create_session(self, session_id: str, user_id: int, 
                      expires_at: datetime, ip_address: str = None,
                      user_agent: str = None) -> bool:
        """Create a new user session"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO sessions 
                (session_id, user_id, expires_at, ip_address, user_agent)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                session_id,
                user_id,
                expires_at.isoformat(),
                ip_address,
                user_agent
            ))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating session: {e}")
            return False
    
    def log_system_event(self, level: str, component: str, message: str,
                        details: str = None, user_id: int = None,
                        channel_id: str = None) -> bool:
        """Log a system event"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO system_logs 
                (level, component, message, details, user_id, channel_id)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (level, component, message, details, user_id, channel_id))
            
            conn.commit()
            conn.close()
            
            return True
            
        except Exception as e:
            print(f"Error logging system event: {e}")
            return False

# Global database manager instance
db_manager = DatabaseManager()

def main():
    """Test the database manager"""
    # Test adding a channel
    success = db_manager.add_channel(
        channel_id="test_channel_1",
        channel_name="Test Channel",
        settings={"auto_publish": True, "timezone": "UTC"}
    )
    print(f"Channel added: {success}")
    
    # Test adding content
    content_id = "content_001"
    success = db_manager.add_content(
        content_id=content_id,
        channel_id="test_channel_1",
        content="This is a test post for the Telegram bot system.",
        title="Test Post",
        metadata={"has_media": False, "tags": ["test", "bot"]}
    )
    print(f"Content added: {success}")
    
    # Test adding performance metrics
    success = db_manager.add_performance_metrics(
        content_id=content_id,
        channel_id="test_channel_1",
        metrics={
            "views": 150,
            "likes": 25,
            "comments": 5,
            "shares": 3,
            "engagement_rate": 0.22,
            "reach": 200
        }
    )
    print(f"Performance metrics added: {success}")
    
    # Test getting channel performance
    performance = db_manager.get_channel_performance("test_channel_1")
    print(f"Channel performance: {performance}")

if __name__ == "__main__":
    main()