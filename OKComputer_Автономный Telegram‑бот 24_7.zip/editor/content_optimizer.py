"""
Content Optimizer Module
Оптимизация контента для Telegram и улучшение читаемости
"""

import asyncio
import re
import random
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging
import time

logger = logging.getLogger(__name__)

@dataclass
class OptimizationOptions:
    """Опции оптимизации"""
    shorten_text: bool = True
    improve_readability: bool = True
    add_emojis: bool = True
    generate_hashtags: bool = True
    optimize_structure: bool = True
    remove_redundancy: bool = True
    format_for_telegram: bool = True
    max_length: int = 4000  # Лимит Telegram

@dataclass
class OptimizationResult:
    """Результат оптимизации"""
    original_text: str
    optimized_text: str
    changes_made: List[str]
    quality_improvements: Dict[str, float]
    length_reduction: float
    readability_improvement: float

class ContentOptimizer:
    """Оптимизатор контента для Telegram"""
    
    def __init__(self):
        # Эмодзи для разных тем
        self.emoji_sets = {
            'positive': ['😊', '👍', '✨', '🎉', '🔥', '💫', '🌟', '⭐', '👏', '🙌'],
            'news': ['📰', '📺', '📻', '📡', '🌐', '📊', '📈', '📉', '📋', '📄'],
            'tech': ['💻', '🖥️', '📱', '⌨️', '🖱️', '💾', '💿', '📀', '🔗', '⚡'],
            'business': ['💼', '💰', '💵', '💴', '💶', '💷', '🏦', '🏢', '📈', '📊'],
            'sports': ['⚽', '🏀', '🏈', '⚾', '🎾', '🏐', '🏓', '🏸', '🥊', '🏆'],
            'entertainment': ['🎬', '🎭', '🎪', '🎫', '🎮', '🎯', '🎲', '🎸', '🎺', '🎤'],
            'education': ['📚', '🎓', '📝', '✏️', '📐', '📏', '📊', '📋', '📖', '📕'],
            'health': ['🏥', '💊', '💉', '🩺', '🩸', '🧬', '🦠', '😷', '🤒', '🤕'],
            'travel': ['✈️', '🚗', '🚂', '🚢', '🧳', '🗺️', '🌍', '🌎', '🌏', '📍'],
            'food': ['🍔', '🍕', '🍣', '🍜', '🍝', '🍰', '🍩', '🍪', '🥤', '🍽️']
        }
        
        # Популярные хештеги для разных тем
        self.hashtag_suggestions = {
            'technology': ['#технологии', '#инновации', '#IT', '#цифровизация', '#будущее'],
            'business': ['#бизнес', '#предпринимательство', '#успех', '#лидерство', '#развитие'],
            'news': ['#новости', '#события', '#актуально', '#мир', '#информация'],
            'sports': ['#спорт', '#фитнес', '#здоровье', '#активныйобразжизни', '#мотивация'],
            'entertainment': ['#развлечения', '#кино', '#музыка', '#культура', '#отдых'],
            'education': ['#образование', '#обучение', '#знания', '#развитие', '#учеба'],
            'health': ['#здоровье', '#медицина', '#зож', '#профилактика', '#благополучие'],
            'travel': ['#путешествия', '#туризм', '#мир', '#приключения', '#открытия'],
            'food': ['#еда', '#кулинария', '#рецепты', '#вкусно', '#гастрономия']
        }
        
        # Настройки оптимизации
        self.quality_thresholds = {
            'min_readability_score': 0.6,
            'min_keyword_density': 0.01,
            'max_keyword_density': 0.05,
            'min_sentence_length': 8,
            'max_sentence_length': 25,
            'max_paragraph_length': 150
        }
        
        # Статистика
        self.stats = {
            'content_optimized': 0,
            'total_length_reduction': 0,
            'avg_readability_improvement': 0.0
        }
        
        logger.info("Content Optimizer инициализирован")
    
    async def optimize_text(
        self,
        content: Dict[str, Any],
        nlp_analysis: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Оптимизация текста для Telegram
        
        Args:
            content: Исходный контент
            nlp_analysis: Результат NLP анализа
            
        Returns:
            Оптимизированный контент
        """
        try:
            logger.info("Начало оптимизации контента")
            
            optimized = content.copy()
            changes_made = []
            quality_improvements = {}
            
            # Оптимизация заголовка
            if optimized.get('title'):
                new_title, title_changes = await self._optimize_title(
                    optimized['title'],
                    nlp_analysis
                )
                if new_title != optimized['title']:
                    optimized['title'] = new_title
                    changes_made.extend(title_changes)
            
            # Оптимизация основного контента
            if optimized.get('content'):
                new_content, content_changes = await self._optimize_main_content(
                    optimized['content'],
                    nlp_analysis
                )
                optimized['content'] = new_content
                changes_made.extend(content_changes)
            
            # Структурирование контента
            if optimized.get('content'):
                optimized['content'] = await self._structure_content(optimized['content'])
                changes_made.append('Content structured with paragraphs')
            
            # Добавление эмодзи
            if optimized.get('content'):
                optimized['content'] = await self.add_emojis(optimized)
                changes_made.append('Added relevant emojis')
            
            # Генерация хештегов
            if optimized.get('content'):
                hashtags = await self.generate_hashtags(optimized, nlp_analysis)
                optimized['hashtags'] = hashtags
                changes_made.append('Generated relevant hashtags')
            
            # Форматирование для Telegram
            optimized['content'] = await self._format_for_telegram(optimized['content'])
            changes_made.append('Formatted for Telegram')
            
            # Расчет улучшений
            original_length = len(content.get('content', ''))
            optimized_length = len(optimized['content'])
            length_reduction = (original_length - optimized_length) / original_length if original_length > 0 else 0
            
            quality_improvements = {
                'readability': 0.2,  # Упрощенная оценка
                'engagement': 0.3,   # Учет эмодзи и хештегов
                'seo_score': 0.15    # Учет ключевых слов
            }
            
            # Обновление статистики
            self.stats['content_optimized'] += 1
            self.stats['total_length_reduction'] += length_reduction
            
            logger.info(f"Оптимизация завершена. Изменений: {len(changes_made)}")
            
            return optimized
            
        except Exception as e:
            logger.error(f"Ошибка при оптимизации контента: {e}")
            return content
    
    async def add_emojis(self, content: Dict[str, Any]) -> str:
        """Добавление релевантных эмодзи к контенту"""
        main_text = content.get('content', '')
        if not main_text:
            return main_text
        
        # Определение тематики контента
        topic = await self._detect_topic(main_text)
        
        # Выбор эмодзи для тематики
        relevant_emojis = self.emoji_sets.get(topic, self.emoji_sets['positive'])
        
        # Добавление эмодзи в стратегических местах
        sentences = re.split(r'[.!?]+', main_text)
        optimized_sentences = []
        
        for i, sentence in enumerate(sentences):
            sentence = sentence.strip()
            if sentence:
                # Добавление эмодзи к каждому 3-му предложению
                if i % 3 == 2 and i < len(sentences) - 1:
                    emoji = random.choice(relevant_emojis)
                    sentence += f" {emoji}"
                
                optimized_sentences.append(sentence)
        
        # Добавление эмодзи в конец текста
        if optimized_sentences:
            final_emoji = random.choice(relevant_emojis)
            optimized_sentences[-1] += f" {final_emoji}"
        
        return '. '.join(optimized_sentences)
    
    async def generate_hashtags(
        self,
        content: Dict[str, Any],
        nlp_analysis: Optional[Dict[str, Any]] = None
    ) -> List[str]:
        """Генерация релевантных хештегов"""
        main_text = f"{content.get('title', '')} {content.get('content', '')}"
        if not main_text.strip():
            return []
        
        # Определение тематики
        topic = await self._detect_topic(main_text)
        
        # Получение базовых хештегов для тематики
        base_hashtags = self.hashtag_suggestions.get(topic, [])
        
        # Извлечение ключевых слов из текста
        keywords = await self._extract_keywords_for_hashtags(main_text)
        
        # Комбинирование хештегов
        all_hashtags = base_hashtags + [f"#{keyword}" for keyword in keywords]
        
        # Удаление дубликатов и ограничение количества
        unique_hashtags = list(dict.fromkeys(all_hashtags))[:10]
        
        return unique_hashtags
    
    async def _optimize_title(self, title: str, nlp_analysis: Optional[Dict[str, Any]] = None) -> Tuple[str, List[str]]:
        """Оптимизация заголовка"""
        changes = []
        optimized = title
        
        # Удаление лишних слов
        original_length = len(optimized)
        optimized = re.sub(r'\b(мне|мной|мною|тебя|тебе|тобой|тобою|он|его|нему|ним|нем|ней|ею|ей|её|её|мы|нас|нам|нами|вы|вас|вам|вами|они|их|им|ими|их|их)\b', '', optimized, flags=re.IGNORECASE)
        optimized = re.sub(r'\s+', ' ', optimized).strip()
        
        if len(optimized) < original_length:
            changes.append('Removed redundant pronouns')
        
        # Капитализация первых букв
        if optimized and optimized[0].islower():
            optimized = optimized.capitalize()
            changes.append('Capitalized title')
        
        # Добавление сильных слов если короткий заголовок
        if len(optimized.split()) < 3:
            power_words = ['Потрясающий', 'Невероятный', 'Уникальный', 'Важный', 'Срочный', 'Эксклюзивный']
            optimized = f"{random.choice(power_words)}: {optimized}"
            changes.append('Added power words to title')
        
        return optimized, changes
    
    async def _optimize_main_content(self, content: str, nlp_analysis: Optional[Dict[str, Any]] = None) -> Tuple[str, List[str]]:
        """Оптимизация основного контента"""
        changes = []
        optimized = content
        
        # Удаление повторов
        original_sentences = re.split(r'[.!?]+', optimized)
        unique_sentences = []
        seen_sentences = set()
        
        for sentence in original_sentences:
            sentence_key = sentence.strip().lower()
            if sentence_key and sentence_key not in seen_sentences:
                unique_sentences.append(sentence.strip())
                seen_sentences.add(sentence_key)
        
        if len(unique_sentences) < len(original_sentences):
            optimized = '. '.join(unique_sentences) + '.'
            changes.append('Removed duplicate sentences')
        
        # Укорочение длинных предложений
        sentences = re.split(r'[.!?]+', optimized)
        shortened_sentences = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if sentence:
                words = sentence.split()
                if len(words) > self.quality_thresholds['max_sentence_length']:
                    # Разделение длинного предложения
                    mid_point = len(words) // 2
                    first_part = ' '.join(words[:mid_point]) + '.'
                    second_part = ' '.join(words[mid_point:]) + '.'
                    shortened_sentences.extend([first_part, second_part])
                    changes.append('Split long sentences')
                else:
                    shortened_sentences.append(sentence + ('.' if not sentence.endswith('.') else ''))
        
        optimized = ' '.join(shortened_sentences)
        
        # Удаление избыточных фраз
        redundant_phrases = [
            'как известно', 'как говорится', 'на самом деле', 'в действительности',
            'безусловно', 'несомненно', 'очевидно', 'бесспорно',
            'в первую очередь', 'прежде всего', 'в основном',
            'в конце концов', 'в итоге', 'в результате'
        ]
        
        for phrase in redundant_phrases:
            if phrase.lower() in optimized.lower():
                optimized = re.sub(re.escape(phrase), '', optimized, flags=re.IGNORECASE)
                changes.append(f'Removed redundant phrase: {phrase}')
        
        return optimized, changes
    
    async def _structure_content(self, content: str) -> str:
        """Структурирование контента с абзацами"""
        sentences = re.split(r'[.!?]+', content)
        structured_paragraphs = []
        current_paragraph = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if sentence:
                current_paragraph.append(sentence)
                
                # Создание нового абзаца каждые 3-4 предложения
                if len(current_paragraph) >= random.randint(3, 4):
                    paragraph = '. '.join(current_paragraph) + '.'
                    structured_paragraphs.append(paragraph)
                    current_paragraph = []
        
        # Добавление последнего абзаца
        if current_paragraph:
            paragraph = '. '.join(current_paragraph) + '.'
            structured_paragraphs.append(paragraph)
        
        return '\n\n'.join(structured_paragraphs)
    
    async def _format_for_telegram(self, content: str) -> str:
        """Форматирование для Telegram"""
        formatted = content
        
        # Добавление жирного шрифта для заголовков
        lines = formatted.split('\n')
        for i, line in enumerate(lines):
            if i == 0 and len(line) < 100:  # Первый абзац - заголовок
                lines[i] = f"**{line}**"
            elif line.strip().endswith(':'):  # Подзаголовки
                lines[i] = f"**{line}**"
        
        formatted = '\n'.join(lines)
        
        # Добавление курсивов для выделений
        formatted = re.sub(r'"([^"]+)"', r'_\1_', formatted)
        
        return formatted
    
    async def _detect_topic(self, text: str) -> str:
        """Определение тематики текста"""
        text_lower = text.lower()
        
        # Проверка по ключевым словам
        for topic, keywords in {
            'technology': ['технолог', 'technology', 'tech', 'software', 'hardware', 'программ', 'компьютер', 'интернет'],
            'business': ['бизнес', 'business', 'компани', 'company', 'деньг', 'money', 'экономик', 'economy', 'рынок', 'market'],
            'sports': ['спорт', 'sport', 'футбол', 'football', 'теннис', 'tennis', 'матч', 'match', 'игра', 'game'],
            'entertainment': ['кино', 'movie', 'фильм', 'film', 'музык', 'music', 'концерт', 'concert', 'шоу', 'show'],
            'health': ['здоровье', 'health', 'медицин', 'medicine', 'врач', 'doctor', 'болезн', 'disease', 'лечени', 'treatment'],
            'education': ['образование', 'education', 'учеб', 'study', 'школ', 'school', 'университет', 'university'],
            'travel': ['путешеств', 'travel', 'туризм', 'tourism', 'отдых', 'vacation', 'поездк', 'trip']
        }.items():
            if any(keyword in text_lower for keyword in keywords):
                return topic
        
        return 'positive'  # По умолчанию
    
    async def _extract_keywords_for_hashtags(self, text: str) -> List[str]:
        """Извлечение ключевых слов для хештегов"""
        # Простое извлечение существительных и прилагательных
        words = re.findall(r'\b[а-яёa-z]{4,}\b', text.lower())
        
        # Фильтрация стоп-слов
        stop_words = {
            'который', 'которая', 'которое', 'которые', 'этот', 'эта', 'это', 'эти',
            'такой', 'такая', 'такое', 'такие', 'весь', 'вся', 'всё', 'все',
            'мой', 'моя', 'моё', 'мои', 'твой', 'твоя', 'твоё', 'твои'
        }
        
        keywords = [word for word in words if word not in stop_words]
        
        # Подсчет частотности
        word_freq = {}
        for word in keywords:
            word_freq[word] = word_freq.get(word, 0) + 1
        
        # Возврат топ-5 ключевых слов
        return [word for word, _ in sorted(word_freq.items(), key=lambda x: x[1], reverse=True)[:5]]
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса оптимизатора"""
        return {
            'is_initialized': True,
            'stats': self.stats,
            'quality_thresholds': self.quality_thresholds,
            'emoji_sets_count': len(self.emoji_sets),
            'hashtag_suggestions_count': len(self.hashtag_suggestions)
        }

# Глобальный экземпляр
content_optimizer = ContentOptimizer()