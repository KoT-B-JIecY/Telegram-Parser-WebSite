"""
Web Panel Routes Module
Маршруты для веб-интерфейса управления UltraBot
"""

import asyncio
import json
from flask import render_template, request, jsonify, redirect, url_for, session, flash
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

def setup_routes(app):
    """Настройка маршрутов веб-интерфейса"""
    
    # Главная страница
    @app.route('/')
    def index():
        """Главная страница панели управления"""
        if not current_user.is_authenticated:
            return redirect(url_for('login'))
        
        return render_template('dashboard.html')
    
    # Страница входа
    @app.route('/login', methods=['GET', 'POST'])
    def login():
        """Страница входа"""
        if current_user.is_authenticated:
            return redirect(url_for('index'))
        
        if request.method == 'POST':
            username = request.form.get('username')
            password = request.form.get('password')
            
            # Проверка учетных данных
            from database.models import User
            user = User.query.filter_by(username=username).first()
            
            if user and user.check_password(password):
                from flask_login import login_user
                login_user(user)
                
                # Обновление статистики
                session['login_time'] = datetime.now().isoformat()
                
                logger.info(f"Пользователь {username} вошел в систему")
                return redirect(url_for('index'))
            else:
                flash('Неверное имя пользователя или пароль', 'error')
        
        return render_template('login.html')
    
    # Выход из системы
    @app.route('/logout')
    @login_required
    def logout():
        """Выход из системы"""
        from flask_login import logout_user
        logout_user()
        session.clear()
        return redirect(url_for('login'))
    
    # API: Статус системы
    @app.route('/api/status')
    @login_required
    def api_status():
        """Получение статуса системы"""
        try:
            # Получение статуса от всех сервисов
            status_data = {}
            
            # Core Service
            try:
                from core.main import core
                status_data['core'] = await core.get_status()
            except Exception as e:
                status_data['core'] = {'error': str(e)}
            
            # Parser Service
            try:
                from parser.main import parser_service
                status_data['parser'] = await parser_service.get_service_status()
            except Exception as e:
                status_data['parser'] = {'error': str(e)}
            
            # Editor Service
            try:
                from editor.main import editor_service
                status_data['editor'] = await editor_service.get_service_status()
            except Exception as e:
                status_data['editor'] = {'error': str(e)}
            
            # Publisher Service
            try:
                from publisher.main import publisher_service
                status_data['publisher'] = await publisher_service.get_service_status()
            except Exception as e:
                status_data['publisher'] = {'error': str(e)}
            
            # ML Service
            try:
                from ml_engine.main import ml_service
                status_data['ml'] = await ml_service.get_service_status()
            except Exception as e:
                status_data['ml'] = {'error': str(e)}
            
            return jsonify({
                'status': 'success',
                'timestamp': datetime.now().isoformat(),
                'services': status_data
            })
            
        except Exception as e:
            logger.error(f"Ошибка при получении статуса: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Список источников
    @app.route('/api/sources')
    @login_required
    def api_sources():
        """Получение списка источников"""
        try:
            # В реальном приложении - получение из базы данных
            sources = [
                {
                    'id': 1,
                    'url': 'https://example-news.com',
                    'name': 'Example News',
                    'type': 'news',
                    'status': 'active',
                    'last_update': datetime.now().isoformat(),
                    'posts_count': 42,
                    'success_rate': 0.95
                },
                {
                    'id': 2,
                    'url': 'https://tech-blog.com',
                    'name': 'Tech Blog',
                    'type': 'blog',
                    'status': 'active',
                    'last_update': datetime.now().isoformat(),
                    'posts_count': 18,
                    'success_rate': 0.88
                }
            ]
            
            return jsonify({
                'status': 'success',
                'sources': sources
            })
            
        except Exception as e:
            logger.error(f"Ошибка при получении источников: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Добавление источника
    @app.route('/api/sources/add', methods=['POST'])
    @login_required
    def api_add_source():
        """Добавление нового источника"""
        try:
            data = request.get_json()
            
            url = data.get('url')
            name = data.get('name')
            source_type = data.get('type', 'auto')
            frequency = data.get('frequency', 60)
            keywords = data.get('keywords', [])
            
            # Валидация данных
            if not url or not name:
                return jsonify({
                    'status': 'error',
                    'message': 'URL и название обязательны'
                }), 400
            
            # В реальном приложении - добавление в базу данных
            source_id = 123  # Заглушка
            
            logger.info(f"Добавлен источник: {name} ({url})")
            
            return jsonify({
                'status': 'success',
                'source_id': source_id,
                'message': 'Источник добавлен'
            })
            
        except Exception as e:
            logger.error(f"Ошибка при добавлении источника: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Расписание публикаций
    @app.route('/api/schedule')
    @login_required
    def api_schedule():
        """Получение расписания публикаций"""
        try:
            # В реальном приложении - получение из базы данных
            schedule = [
                {
                    'id': 1,
                    'time': '09:00',
                    'channel': '@main_channel',
                    'content_type': 'news',
                    'status': 'active',
                    'posts_today': 3,
                    'avg_engagement': 0.75
                },
                {
                    'id': 2,
                    'time': '15:00',
                    'channel': '@tech_channel',
                    'content_type': 'tech',
                    'status': 'active',
                    'posts_today': 2,
                    'avg_engagement': 0.82
                }
            ]
            
            return jsonify({
                'status': 'success',
                'schedule': schedule
            })
            
        except Exception as e:
            logger.error(f"Ошибка при получении расписания: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Обновление расписания
    @app.route('/api/schedule/update', methods=['POST'])
    @login_required
    def api_update_schedule():
        """Обновление расписания"""
        try:
            data = request.get_json()
            
            # В реальном приложении - обновление в базе данных
            logger.info(f"Обновление расписания: {data}")
            
            return jsonify({
                'status': 'success',
                'message': 'Расписание обновлено'
            })
            
        except Exception as e:
            logger.error(f"Ошибка при обновлении расписания: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Аналитика
    @app.route('/api/analytics')
    @login_required
    def api_analytics():
        """Получение аналитики"""
        try:
            # В реальном приложении - получение из базы данных
            analytics = {
                'period': '7d',
                'posts_published': 156,
                'total_reach': 45678,
                'avg_engagement': 0.73,
                'top_channels': [
                    {'name': '@main_channel', 'reach': 23456, 'engagement': 0.78},
                    {'name': '@tech_channel', 'reach': 12345, 'engagement': 0.82},
                    {'name': '@news_channel', 'reach': 9877, 'engagement': 0.65}
                ],
                'content_performance': {
                    'text_only': {'count': 89, 'avg_engagement': 0.68},
                    'with_images': {'count': 45, 'avg_engagement': 0.79},
                    'with_videos': {'count': 22, 'avg_engagement': 0.85}
                },
                'posting_time_analysis': {
                    'optimal_hours': [9, 12, 15, 18, 21],
                    'best_days': [1, 2, 3, 4, 5]  # Пн-Пт
                }
            }
            
            return jsonify({
                'status': 'success',
                'analytics': analytics
            })
            
        except Exception as e:
            logger.error(f"Ошибка при получении аналитики: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Логи системы
    @app.route('/api/logs')
    @login_required
    def api_logs():
        """Получение логов системы"""
        try:
            service = request.args.get('service', 'all')
            level = request.args.get('level', 'INFO')
            limit = int(request.args.get('limit', 100))
            
            # В реальном приложении - чтение логов
            logs = [
                {
                    'timestamp': datetime.now().isoformat(),
                    'service': 'parser',
                    'level': 'INFO',
                    'message': 'Parser service started successfully'
                },
                {
                    'timestamp': datetime.now().isoformat(),
                    'service': 'publisher',
                    'level': 'WARNING',
                    'message': 'Rate limit hit, waiting...'
                }
            ]
            
            return jsonify({
                'status': 'success',
                'logs': logs[:limit]
            })
            
        except Exception as e:
            logger.error(f"Ошибка при получении логов: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # API: Управление системой
    @app.route('/api/system/control', methods=['POST'])
    @login_required
    def api_system_control():
        """Управление системой"""
        try:
            data = request.get_json()
            action = data.get('action')
            
            if action == 'restart':
                # Перезапуск системы
                logger.info("Запрошен перезапуск системы")
                return jsonify({
                    'status': 'success',
                    'message': 'Система будет перезапущена'
                })
            
            elif action == 'emergency_stop':
                # Экстренная остановка
                logger.warning("Запрошена экстренная остановка")
                return jsonify({
                    'status': 'success',
                    'message': 'Система остановлена'
                })
            
            elif action == 'update_config':
                # Обновление конфигурации
                config_data = data.get('config', {})
                logger.info(f"Обновление конфигурации: {config_data}")
                return jsonify({
                    'status': 'success',
                    'message': 'Конфигурация обновлена'
                })
            
            else:
                return jsonify({
                    'status': 'error',
                    'message': 'Неизвестное действие'
                }), 400
            
        except Exception as e:
            logger.error(f"Ошибка при управлении системой: {e}")
            return jsonify({
                'status': 'error',
                'message': str(e)
            }), 500
    
    # Страницы интерфейса
    @app.route('/dashboard')
    @login_required
    def dashboard():
        """Главная панель управления"""
        return render_template('dashboard.html')
    
    @app.route('/sources')
    @login_required
    def sources_page():
        """Страница управления источниками"""
        return render_template('sources.html')
    
    @app.route('/schedule')
    @login_required
    def schedule_page():
        """Страница расписания"""
        return render_template('schedule.html')
    
    @app.route('/analytics')
    @login_required
    def analytics_page():
        """Страница аналитики"""
        return render_template('analytics.html')
    
    @app.route('/settings')
    @login_required
    def settings_page():
        """Страница настроек"""
        return render_template('settings.html')
    
    @app.route('/logs')
    @login_required
    def logs_page():
        """Страница логов"""
        return render_template('logs.html')
    
    # Обработка ошибок
    @app.errorhandler(404)
    def not_found(error):
        """Обработка 404 ошибки"""
        return render_template('error.html', error_code=404, error_message='Страница не найдена'), 404
    
    @app.errorhandler(500)
    def internal_error(error):
        """Обработка 500 ошибки"""
        return render_template('error.html', error_code=500, error_message='Внутренняя ошибка сервера'), 500
    
    @app.errorhandler(403)
    def forbidden(error):
        """Обработка 403 ошибки"""
        return render_template('error.html', error_code=403, error_message='Доступ запрещен'), 403