import asyncio
import logging
import time
import psutil
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import json
import smtplib
import aiohttp
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dataclasses import dataclass
import threading

@dataclass
class SystemMetrics:
    cpu_percent: float
    memory_percent: float
    disk_usage_percent: float
    network_io: Dict[str, int]
    process_count: int
    uptime: float
    timestamp: datetime

@dataclass
class ServiceHealth:
    service_name: str
    status: str  # 'healthy', 'degraded', 'unhealthy', 'down'
    response_time: float
    last_check: datetime
    error_count: int
    details: Dict[str, Any]

class SystemMonitor:
    def __init__(self, db_path: str = "ultrabot.db", check_interval: int = 60):
        self.db_path = db_path
        self.check_interval = check_interval
        self.logger = logging.getLogger(__name__)
        self.is_running = False
        self.monitoring_thread = None
        
        # Alert thresholds
        self.thresholds = {
            'cpu_percent': 80.0,
            'memory_percent': 85.0,
            'disk_usage_percent': 90.0,
            'response_time_ms': 5000,
            'error_rate_percent': 5.0,
            'service_down_time_minutes': 5
        }
        
        # Service health tracking
        self.service_health = {}
        self.alert_history = []
        
        # Email alert settings
        self.email_settings = {
            'smtp_server': 'smtp.gmail.com',
            'smtp_port': 587,
            'username': '',  # To be configured
            'password': '',  # To be configured
            'from_email': '',
            'to_emails': []
        }
        
    def start_monitoring(self):
        """Start the monitoring system"""
        if self.is_running:
            return
        
        self.is_running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop)
        self.monitoring_thread.daemon = True
        self.monitoring_thread.start()
        
        self.logger.info("System monitoring started")
    
    def stop_monitoring(self):
        """Stop the monitoring system"""
        self.is_running = False
        if self.monitoring_thread:
            self.monitoring_thread.join()
        
        self.logger.info("System monitoring stopped")
    
    def _monitoring_loop(self):
        """Main monitoring loop running in background thread"""
        while self.is_running:
            try:
                # Collect system metrics
                system_metrics = self._collect_system_metrics()
                self._store_system_metrics(system_metrics)
                
                # Check service health
                self._check_service_health()
                
                # Check for alerts
                self._check_alerts(system_metrics)
                
                # Log system status
                self._log_system_status(system_metrics)
                
                time.sleep(self.check_interval)
                
            except Exception as e:
                self.logger.error(f"Error in monitoring loop: {e}")
                time.sleep(self.check_interval)
    
    def _collect_system_metrics(self) -> SystemMetrics:
        """Collect current system metrics"""
        # CPU usage
        cpu_percent = psutil.cpu_percent(interval=1)
        
        # Memory usage
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        
        # Disk usage
        disk = psutil.disk_usage('/')
        disk_usage_percent = (disk.used / disk.total) * 100
        
        # Network I/O
        network_io = psutil.net_io_counters()._asdict()
        
        # Process count
        process_count = len(psutil.pids())
        
        # System uptime
        uptime = time.time() - psutil.boot_time()
        
        return SystemMetrics(
            cpu_percent=cpu_percent,
            memory_percent=memory_percent,
            disk_usage_percent=disk_usage_percent,
            network_io=network_io,
            process_count=process_count,
            uptime=uptime,
            timestamp=datetime.now()
        )
    
    def _store_system_metrics(self, metrics: SystemMetrics):
        """Store system metrics in database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS system_metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    cpu_percent REAL,
                    memory_percent REAL,
                    disk_usage_percent REAL,
                    network_bytes_sent INTEGER,
                    network_bytes_recv INTEGER,
                    process_count INTEGER,
                    uptime REAL
                )
            ''')
            
            cursor.execute('''
                INSERT INTO system_metrics 
                (timestamp, cpu_percent, memory_percent, disk_usage_percent,
                 network_bytes_sent, network_bytes_recv, process_count, uptime)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                metrics.timestamp,
                metrics.cpu_percent,
                metrics.memory_percent,
                metrics.disk_usage_percent,
                metrics.network_io['bytes_sent'],
                metrics.network_io['bytes_recv'],
                metrics.process_count,
                metrics.uptime
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error storing system metrics: {e}")
    
    async def _check_service_health(self):
        """Check health of various services"""
        services = [
            {'name': 'telegram_bot', 'url': 'http://localhost:8080/health', 'type': 'http'},
            {'name': 'web_panel', 'url': 'http://localhost:5000/health', 'type': 'http'},
            {'name': 'redis', 'host': 'localhost', 'port': 6379, 'type': 'redis'},
            {'name': 'postgresql', 'host': 'localhost', 'port': 5432, 'type': 'database'}
        ]
        
        for service in services:
            health = await self._check_service(service)
            self.service_health[service['name']] = health
    
    async def _check_service(self, service: Dict) -> ServiceHealth:
        """Check individual service health"""
        start_time = time.time()
        status = 'healthy'
        error_count = 0
        details = {}
        
        try:
            if service['type'] == 'http':
                async with aiohttp.ClientSession() as session:
                    async with session.get(service['url'], timeout=aiohttp.ClientTimeout(total=5)) as response:
                        if response.status != 200:
                            status = 'unhealthy'
                        details['status_code'] = response.status
                        
            elif service['type'] == 'redis':
                import redis
                r = redis.Redis(host=service['host'], port=service['port'], socket_timeout=5)
                r.ping()
                details['connection'] = 'successful'
                
            elif service['type'] == 'database':
                conn = sqlite3.connect(self.db_path)
                cursor = conn.cursor()
                cursor.execute('SELECT 1')
                conn.close()
                details['connection'] = 'successful'
            
        except Exception as e:
            status = 'down'
            error_count = 1
            details['error'] = str(e)
        
        response_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        
        # Update error count if service was previously unhealthy
        if service['name'] in self.service_health:
            previous_health = self.service_health[service['name']]
            if status == 'unhealthy' or status == 'down':
                error_count = previous_health.error_count + 1
        
        return ServiceHealth(
            service_name=service['name'],
            status=status,
            response_time=response_time,
            last_check=datetime.now(),
            error_count=error_count,
            details=details
        )
    
    def _check_alerts(self, metrics: SystemMetrics):
        """Check for alert conditions and trigger alerts if necessary"""
        alerts = []
        
        # Check CPU usage
        if metrics.cpu_percent > self.thresholds['cpu_percent']:
            alerts.append({
                'type': 'cpu_high',
                'severity': 'warning',
                'message': f"CPU usage is high: {metrics.cpu_percent:.1f}%",
                'value': metrics.cpu_percent,
                'threshold': self.thresholds['cpu_percent']
            })
        
        # Check memory usage
        if metrics.memory_percent > self.thresholds['memory_percent']:
            alerts.append({
                'type': 'memory_high',
                'severity': 'warning',
                'message': f"Memory usage is high: {metrics.memory_percent:.1f}%",
                'value': metrics.memory_percent,
                'threshold': self.thresholds['memory_percent']
            })
        
        # Check disk usage
        if metrics.disk_usage_percent > self.thresholds['disk_usage_percent']:
            alerts.append({
                'type': 'disk_high',
                'severity': 'critical',
                'message': f"Disk usage is critical: {metrics.disk_usage_percent:.1f}%",
                'value': metrics.disk_usage_percent,
                'threshold': self.thresholds['disk_usage_percent']
            })
        
        # Check service health
        for service_name, health in self.service_health.items():
            if health.status == 'down':
                alerts.append({
                    'type': 'service_down',
                    'severity': 'critical',
                    'message': f"Service {service_name} is down",
                    'service': service_name,
                    'details': health.details
                })
            elif health.status == 'unhealthy':
                alerts.append({
                    'type': 'service_unhealthy',
                    'severity': 'warning',
                    'message': f"Service {service_name} is unhealthy",
                    'service': service_name,
                    'response_time': health.response_time
                })
        
        # Process alerts
        for alert in alerts:
            self._process_alert(alert)
    
    def _process_alert(self, alert: Dict):
        """Process an alert - send notifications and store in history"""
        alert_key = f"{alert['type']}_{alert.get('service', 'system')}"
        
        # Check if this alert was already sent recently (avoid spam)
        if self._should_send_alert(alert_key):
            # Store alert in history
            self._store_alert(alert)
            
            # Send email alert if configured
            if self.email_settings['username']:
                self._send_email_alert(alert)
            
            # Log the alert
            self.logger.warning(f"ALERT: {alert['message']}")
    
    def _should_send_alert(self, alert_key: str) -> bool:
        """Check if alert should be sent (prevent spam)"""
        # Check last alert time for this key
        for alert in self.alert_history:
            if alert['key'] == alert_key:
                time_since_last = datetime.now() - alert['timestamp']
                if time_since_last.total_seconds() < 3600:  # 1 hour cooldown
                    return False
        
        return True
    
    def _store_alert(self, alert: Dict):
        """Store alert in history"""
        alert_record = {
            **alert,
            'key': f"{alert['type']}_{alert.get('service', 'system')}",
            'timestamp': datetime.now()
        }
        
        self.alert_history.append(alert_record)
        
        # Keep only last 100 alerts
        if len(self.alert_history) > 100:
            self.alert_history = self.alert_history[-100:]
        
        # Store in database
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    alert_type TEXT,
                    severity TEXT,
                    message TEXT,
                    details TEXT
                )
            ''')
            
            cursor.execute('''
                INSERT INTO alerts (timestamp, alert_type, severity, message, details)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                alert_record['timestamp'],
                alert['type'],
                alert['severity'],
                alert['message'],
                json.dumps(alert.get('details', {}))
            ))
            
            conn.commit()
            conn.close()
            
        except Exception as e:
            self.logger.error(f"Error storing alert: {e}")
    
    def _send_email_alert(self, alert: Dict):
        """Send email alert notification"""
        try:
            msg = MIMEMultipart()
            msg['From'] = self.email_settings['from_email']
            msg['To'] = ', '.join(self.email_settings['to_emails'])
            msg['Subject'] = f"UltraBot Alert: {alert['type']}"
            
            body = f"""
            UltraBot System Alert
            
            Type: {alert['type']}
            Severity: {alert['severity']}
            Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
            
            Message: {alert['message']}
            
            Details: {json.dumps(alert.get('details', {}), indent=2)}
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            server = smtplib.SMTP(self.email_settings['smtp_server'], 
                                self.email_settings['smtp_port'])
            server.starttls()
            server.login(self.email_settings['username'], 
                        self.email_settings['password'])
            server.send_message(msg)
            server.quit()
            
            self.logger.info(f"Email alert sent for {alert['type']}")
            
        except Exception as e:
            self.logger.error(f"Error sending email alert: {e}")
    
    def _log_system_status(self, metrics: SystemMetrics):
        """Log system status summary"""
        status_summary = f"""
        System Status Summary:
        CPU: {metrics.cpu_percent:.1f}% | 
        Memory: {metrics.memory_percent:.1f}% | 
        Disk: {metrics.disk_usage_percent:.1f}% | 
        Processes: {metrics.process_count} | 
        Uptime: {metrics.uptime / 3600:.1f}h
        """
        
        self.logger.info(status_summary.strip())
    
    def get_system_health(self) -> Dict:
        """Get current system health status"""
        metrics = self._collect_system_metrics()
        
        health_status = {
            'timestamp': metrics.timestamp.isoformat(),
            'system_metrics': {
                'cpu_percent': metrics.cpu_percent,
                'memory_percent': metrics.memory_percent,
                'disk_usage_percent': metrics.disk_usage_percent,
                'process_count': metrics.process_count,
                'uptime_hours': metrics.uptime / 3600
            },
            'service_health': {}
        }
        
        # Add service health status
        for service_name, health in self.service_health.items():
            health_status['service_health'][service_name] = {
                'status': health.status,
                'response_time_ms': health.response_time,
                'last_check': health.last_check.isoformat(),
                'error_count': health.error_count
            }
        
        # Overall system health
        critical_services_down = sum(1 for health in self.service_health.values() 
                                   if health.status == 'down')
        
        if critical_services_down > 0:
            health_status['overall_status'] = 'unhealthy'
        elif any(health.status == 'unhealthy' for health in self.service_health.values()):
            health_status['overall_status'] = 'degraded'
        else:
            health_status['overall_status'] = 'healthy'
        
        return health_status
    
    def get_recent_alerts(self, limit: int = 50) -> List[Dict]:
        """Get recent alerts from database"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT * FROM alerts 
                ORDER BY timestamp DESC 
                LIMIT ?
            ''', (limit,))
            
            alerts = []
            for row in cursor.fetchall():
                alert = {
                    'id': row[0],
                    'timestamp': row[1],
                    'type': row[2],
                    'severity': row[3],
                    'message': row[4],
                    'details': json.loads(row[5] or '{}')
                }
                alerts.append(alert)
            
            conn.close()
            return alerts
            
        except Exception as e:
            self.logger.error(f"Error getting recent alerts: {e}")
            return []
    
    def configure_email_alerts(self, smtp_server: str, smtp_port: int,
                             username: str, password: str, from_email: str,
                             to_emails: List[str]):
        """Configure email alert settings"""
        self.email_settings.update({
            'smtp_server': smtp_server,
            'smtp_port': smtp_port,
            'username': username,
            'password': password,
            'from_email': from_email,
            'to_emails': to_emails
        })
        
        self.logger.info("Email alert settings configured")

# Global monitor instance
system_monitor = SystemMonitor()

def main():
    """Test the monitoring system"""
    # Start monitoring
    system_monitor.start_monitoring()
    
    # Let it run for a few cycles
    time.sleep(5)
    
    # Get system health
    health = system_monitor.get_system_health()
    print(f"System Health: {json.dumps(health, indent=2)}")
    
    # Get recent alerts
    alerts = system_monitor.get_recent_alerts(10)
    print(f"Recent Alerts: {json.dumps(alerts, indent=2)}")
    
    # Stop monitoring
    system_monitor.stop_monitoring()

if __name__ == "__main__":
    main()