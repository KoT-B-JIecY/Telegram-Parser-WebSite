"""
Anti-Bot Detection Module
Модуль для обхода защиты от ботов и имитации человеческого поведения
"""

import random
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging
import asyncio

logger = logging.getLogger(__name__)

@dataclass
class BrowserProfile:
    """Профиль браузера для имитации"""
    user_agent: str
    viewport: str
    platform: str
    language: str
    timezone: str
    screen_resolution: str
    color_depth: int
    cookies_enabled: bool
    javascript_enabled: bool
    
class AntiBotManager:
    """Менеджер anti-bot мер"""
    
    def __init__(self):
        self.browser_profiles = self._generate_browser_profiles()
        self.current_profile: Optional[BrowserProfile] = None
        self.request_delays = {
            'min_delay': 1.0,
            'max_delay': 5.0,
            'burst_delay': 0.5,
            'burst_count': 3
        }
        
        # Настройки имитации поведения
        self.behavior_settings = {
            'mouse_movement': True,
            'scroll_simulation': True,
            'random_delays': True,
            'user_agent_rotation': True,
            'viewport_rotation': True
        }
        
        # Статистика
        self.stats = {
            'requests_sent': 0,
            'blocks_encountered': 0,
            'captchas_solved': 0,
            'successful_bypasses': 0
        }
        
        logger.info("Anti-Bot Manager инициализирован")
    
    async def initialize(self):
        """Инициализация менеджера"""
        # Выбор случайного профиля браузера
        self.current_profile = random.choice(self.browser_profiles)
        logger.info(f"Anti-Bot Manager инициализирован с профилем: {self.current_profile.user_agent[:50]}...")
    
    async def get_headers(self, custom_headers: Optional[Dict[str, str]] = None) -> Dict[str, str]:
        """Получение HTTP заголовков с имитацией браузера"""
        if not self.current_profile:
            await self.initialize()
        
        headers = {
            'User-Agent': self.current_profile.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': self.current_profile.language,
            'Accept-Encoding': 'gzip, deflate, br',
            'DNT': '1',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Cache-Control': 'max-age=0'
        }
        
        # Добавление дополнительных заголовков для разных браузеров
        if 'Chrome' in self.current_profile.user_agent:
            headers.update({
                'sec-ch-ua': '"Chromium";v="91", " Not;A Brand";v="99"',
                'sec-ch-ua-mobile': '?0'
            })
        
        # Объединение с пользовательскими заголовками
        if custom_headers:
            headers.update(custom_headers)
        
        return headers
    
    async def get_delay(self, request_count: int = 0) -> float:
        """Получение задержки между запросами"""
        if not self.behavior_settings['random_delays']:
            return 0.0
        
        # Имитация поведения человека
        if request_count < self.request_delays['burst_count']:
            # Быстрые запросы в начале (человек быстро кликает)
            delay = random.uniform(0.1, self.request_delays['burst_delay'])
        else:
            # Задержки между запросами
            delay = random.uniform(
                self.request_delays['min_delay'],
                self.request_delays['max_delay']
            )
            
            # Добавление случайных пауз
            if random.random() < 0.1:  # 10% вероятность длинной паузы
                delay *= random.uniform(2, 5)
        
        return delay
    
    async def simulate_human_behavior(self, page_url: str) -> Dict[str, Any]:
        """Имитация человеческого поведения на странице"""
        behaviors = []
        
        if self.behavior_settings['mouse_movement']:
            # Симуляция движения мыши
            mouse_movements = self._generate_mouse_movements()
            behaviors.append({'type': 'mouse_movement', 'data': mouse_movements})
        
        if self.behavior_settings['scroll_simulation']:
            # Симуляция прокрутки
            scroll_pattern = self._generate_scroll_pattern()
            behaviors.append({'type': 'scroll', 'data': scroll_pattern})
        
        # Случайные задержки
        await asyncio.sleep(random.uniform(0.5, 3.0))
        
        return {
            'behaviors': behaviors,
            'viewport': self.current_profile.viewport if self.current_profile else '1920x1080',
            'user_agent': self.current_profile.user_agent if self.current_profile else ''
        }
    
    async def handle_bot_detection(self, response_headers: Dict[str, str]) -> bool:
        """Обработка обнаружения бота"""
        # Анализ заголовков ответа
        server_header = response_headers.get('server', '').lower()
        x_frame_options = response_headers.get('x-frame-options', '').lower()
        x_robots_tag = response_headers.get('x-robots-tag', '').lower()
        
        # Проверка на признаки блокировки
        blocking_indicators = [
            'cloudflare', 'akamai', 'incapsula', 'sucuri',
            'blocked', 'forbidden', 'captcha', 'challenge'
        ]
        
        is_blocked = any(indicator in server_header + x_frame_options + x_robots_tag 
                        for indicator in blocking_indicators)
        
        if is_blocked:
            self.stats['blocks_encountered'] += 1
            logger.warning("Обнаружена блокировка бота")
            
            # Попытка обхода
            return await self._attempt_bypass()
        
        return True
    
    async def solve_captcha(self, captcha_type: str, captcha_data: Dict[str, Any]) -> Optional[str]:
        """Решение CAPTCHA (интеграция с сервисами)"""
        try:
            # Здесь должна быть интеграция с anti-captcha сервисами
            # Например: 2captcha, anti-captcha.com, deathbycaptcha
            
            logger.info(f"Попытка решить CAPTCHA типа: {captcha_type}")
            
            # Заглушка для демонстрации
            if captcha_type == 'image':
                # В реальном приложении - отправка изображения в сервис
                solution = await self._solve_image_captcha(captcha_data.get('image_url'))
            elif captcha_type == 'recaptcha':
                # В реальном приложении - работа с reCAPTCHA
                solution = await self._solve_recaptcha(captcha_data.get('site_key'), captcha_data.get('page_url'))
            else:
                solution = None
            
            if solution:
                self.stats['captchas_solved'] += 1
                logger.info("CAPTCHA решена успешно")
            
            return solution
            
        except Exception as e:
            logger.error(f"Ошибка при решении CAPTCHA: {e}")
            return None
    
    async def rotate_profile(self):
        """Ротация профиля браузера"""
        if self.behavior_settings['user_agent_rotation']:
            old_profile = self.current_profile
            self.current_profile = random.choice(self.browser_profiles)
            
            logger.info("Ротация профиля браузера выполнена")
            logger.debug(f"Старый профиль: {old_profile.user_agent[:50]}...")
            logger.debug(f"Новый профиль: {self.current_profile.user_agent[:50]}...")
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса anti-bot системы"""
        return {
            'is_initialized': self.current_profile is not None,
            'current_profile': {
                'user_agent': self.current_profile.user_agent[:50] + "..." if self.current_profile else None,
                'platform': self.current_profile.platform if self.current_profile else None
            },
            'stats': self.stats,
            'behavior_settings': self.behavior_settings,
            'request_delays': self.request_delays
        }
    
    def _generate_browser_profiles(self) -> List[BrowserProfile]:
        """Генерация профилей браузеров"""
        profiles = []
        
        # Chrome профили
        chrome_versions = ['91.0.4472.124', '92.0.4515.107', '93.0.4577.63']
        chrome_ua_template = 'Mozilla/5.0 ({platform}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36'
        
        platforms = [
            'Windows NT 10.0; Win64; x64',
            'Macintosh; Intel Mac OS X 10_15_7',
            'X11; Linux x86_64'
        ]
        
        for version in chrome_versions:
            for platform in platforms:
                profile = BrowserProfile(
                    user_agent=chrome_ua_template.format(platform=platform, version=version),
                    viewport=self._get_random_viewport(),
                    platform=platform.split(';')[0] if 'Windows' in platform else 'macOS' if 'Mac' in platform else 'Linux',
                    language='en-US,en;q=0.9,ru;q=0.8',
                    timezone='UTC',
                    screen_resolution='1920x1080',
                    color_depth=24,
                    cookies_enabled=True,
                    javascript_enabled=True
                )
                profiles.append(profile)
        
        # Firefox профили
        firefox_versions = ['89.0', '90.0', '91.0']
        firefox_ua_template = 'Mozilla/5.0 ({platform}; rv:{version}) Gecko/20100101 Firefox/{version}'
        
        for version in firefox_versions:
            for platform in platforms:
                profile = BrowserProfile(
                    user_agent=firefox_ua_template.format(platform=platform, version=version),
                    viewport=self._get_random_viewport(),
                    platform=platform.split(';')[0] if 'Windows' in platform else 'macOS' if 'Mac' in platform else 'Linux',
                    language='en-US,en;q=0.9,ru;q=0.8',
                    timezone='UTC',
                    screen_resolution='1920x1080',
                    color_depth=24,
                    cookies_enabled=True,
                    javascript_enabled=True
                )
                profiles.append(profile)
        
        return profiles
    
    def _get_random_viewport(self) -> str:
        """Получение случайного размера viewport"""
        viewports = [
            '1920x1080',
            '1366x768',
            '1440x900',
            '1536x864',
            '1280x720',
            '1600x900'
        ]
        return random.choice(viewports)
    
    def _generate_mouse_movements(self) -> List[Dict[str, int]]:
        """Генерация траектории движения мыши"""
        movements = []
        current_x, current_y = 0, 0
        
        # Генерация 5-10 точек движения
        num_points = random.randint(5, 10)
        
        for _ in range(num_points):
            # Случайное движение с некоторой логикой
            target_x = random.randint(0, 1920)
            target_y = random.randint(0, 1080)
            
            # Плавное движение к цели
            steps = random.randint(3, 8)
            for i in range(steps):
                progress = i / steps
                x = int(current_x + (target_x - current_x) * progress)
                y = int(current_y + (target_y - current_y) * progress)
                
                movements.append({
                    'x': x,
                    'y': y,
                    'timestamp': time.time() + len(movements) * 0.1
                })
            
            current_x, current_y = target_x, target_y
        
        return movements
    
    def _generate_scroll_pattern(self) -> List[Dict[str, Any]]:
        """Генерация паттерна прокрутки"""
        scrolls = []
        current_position = 0
        
        # Случайное количество прокруток
        num_scrolls = random.randint(2, 8)
        
        for i in range(num_scrolls):
            # Разные типы прокрутки
            scroll_type = random.choice(['smooth', 'jump', 'slow'])
            
            if scroll_type == 'smooth':
                # Плавная прокрутка
                target_position = current_position + random.randint(200, 800)
                steps = random.randint(5, 15)
                
                for j in range(steps):
                    progress = j / steps
                    position = int(current_position + (target_position - current_position) * progress)
                    scrolls.append({
                        'position': position,
                        'type': 'smooth',
                        'timestamp': time.time() + len(scrolls) * 0.05
                    })
                
                current_position = target_position
            
            elif scroll_type == 'jump':
                # Резкая прокрутка
                current_position += random.randint(500, 1500)
                scrolls.append({
                    'position': current_position,
                    'type': 'jump',
                    'timestamp': time.time() + len(scrolls) * 0.1
                })
            
            else:  # slow
                # Медленная прокрутка
                current_position += random.randint(50, 200)
                scrolls.append({
                    'position': current_position,
                    'type': 'slow',
                    'timestamp': time.time() + len(scrolls) * 0.2
                })
        
        return scrolls
    
    async def _attempt_bypass(self) -> bool:
        """Попытка обхода блокировки"""
        try:
            # Смена профиля
            await self.rotate_profile()
            
            # Увеличение задержек
            self.request_delays['min_delay'] *= 2
            self.request_delays['max_delay'] *= 2
            
            # Добавление случайных действий
            await asyncio.sleep(random.uniform(5, 15))
            
            self.stats['successful_bypasses'] += 1
            logger.info("Успешный обход блокировки")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при попытке обхода: {e}")
            return False
    
    async def _solve_image_captcha(self, image_url: str) -> Optional[str]:
        """Решение изображения CAPTCHA"""
        # В реальном приложении - интеграция с anti-captcha сервисом
        logger.info(f"Решение image CAPTCHA: {image_url}")
        
        # Заглушка
        return "captcha_solution"
    
    async def _solve_recaptcha(self, site_key: str, page_url: str) -> Optional[str]:
        """Решение reCAPTCHA"""
        # В реальном приложении - интеграция с anti-captcha сервисом
        logger.info(f"Решение reCAPTCHA: {site_key}")
        
        # Заглушка
        return "recaptcha_solution"

# Глобальный экземпляр
anti_bot_manager = AntiBotManager()