import asyncio
import logging
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional
import numpy as np
from dataclasses import dataclass
import json
import hashlib

@dataclass
class OptimizationMetrics:
    engagement_rate: float
    click_through_rate: float
    conversion_rate: float
    optimal_posting_time: str
    content_length_preference: str
    audience_activity_score: float

@dataclass
class ContentVariant:
    id: str
    content: str
    variant_type: str  # A/B test variant
    metrics: Dict[str, Any]
    created_at: datetime

class MLOptimizer:
    def __init__(self, db_path: str = "optimization.db"):
        self.db_path = db_path
        self.setup_database()
        self.logger = logging.getLogger(__name__)
        self.optimization_cache = {}
        self.learning_rate = 0.01
        self.exploration_rate = 0.1  # For multi-armed bandit
        
    def setup_database(self):
        """Initialize optimization database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Performance metrics table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS performance_metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content_id TEXT,
                channel_id TEXT,
                timestamp DATETIME,
                views INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                shares INTEGER DEFAULT 0,
                likes INTEGER DEFAULT 0,
                comments INTEGER DEFAULT 0,
                engagement_rate REAL DEFAULT 0,
                click_through_rate REAL DEFAULT 0,
                conversion_rate REAL DEFAULT 0,
                optimal_time TEXT,
                audience_segment TEXT
            )
        ''')
        
        # Content variants table for A/B testing
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content_variants (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                variant_id TEXT UNIQUE,
                original_id TEXT,
                content TEXT,
                variant_type TEXT,
                created_at DATETIME,
                tested_channels TEXT,
                performance_score REAL DEFAULT 0
            )
        ''')
        
        # Optimization history
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS optimization_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                optimization_type TEXT,
                parameters TEXT,
                results TEXT,
                improvement_score REAL,
                timestamp DATETIME
            )
        ''')
        
        conn.commit()
        conn.close()
    
    async def analyze_performance(self, channel_id: str, days: int = 30) -> OptimizationMetrics:
        """Analyze channel performance and return optimization metrics"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get performance data for the last N days
        start_date = datetime.now() - timedelta(days=days)
        cursor.execute('''
            SELECT * FROM performance_metrics 
            WHERE channel_id = ? AND timestamp >= ?
            ORDER BY timestamp DESC
        ''', (channel_id, start_date))
        
        metrics_data = cursor.fetchall()
        conn.close()
        
        if not metrics_data:
            return self._get_default_metrics()
        
        # Calculate key metrics
        total_views = sum(row[4] for row in metrics_data)
        total_clicks = sum(row[5] for row in metrics_data)
        total_shares = sum(row[6] for row in metrics_data)
        total_likes = sum(row[7] for row in metrics_data)
        total_comments = sum(row[8] for row in metrics_data)
        
        # Calculate rates
        engagement_rate = (total_likes + total_comments + total_shares) / max(total_views, 1)
        click_through_rate = total_clicks / max(total_views, 1)
        conversion_rate = total_shares / max(total_views, 1)
        
        # Find optimal posting time
        optimal_time = self._calculate_optimal_posting_time(metrics_data)
        
        # Analyze content length preference
        content_length_pref = self._analyze_content_length_preference(metrics_data)
        
        # Calculate audience activity score
        activity_score = self._calculate_activity_score(metrics_data)
        
        return OptimizationMetrics(
            engagement_rate=engagement_rate,
            click_through_rate=click_through_rate,
            conversion_rate=conversion_rate,
            optimal_posting_time=optimal_time,
            content_length_preference=content_length_pref,
            audience_activity_score=activity_score
        )
    
    def _get_default_metrics(self) -> OptimizationMetrics:
        """Return default metrics when no data is available"""
        return OptimizationMetrics(
            engagement_rate=0.05,
            click_through_rate=0.02,
            conversion_rate=0.01,
            optimal_posting_time="14:00",
            content_length_preference="medium",
            audience_activity_score=0.5
        )
    
    def _calculate_optimal_posting_time(self, metrics_data: List) -> str:
        """Calculate the optimal posting time based on engagement patterns"""
        # Group metrics by hour and calculate average engagement
        hourly_engagement = {}
        
        for row in metrics_data:
            timestamp = datetime.fromisoformat(row[3])
            hour = timestamp.hour
            engagement = row[9]  # engagement_rate
            
            if hour not in hourly_engagement:
                hourly_engagement[hour] = []
            hourly_engagement[hour].append(engagement)
        
        # Find hour with highest average engagement
        best_hour = max(hourly_engagement.items(), 
                       key=lambda x: np.mean(x[1]) if x[1] else 0)[0]
        
        return f"{best_hour:02d}:00"
    
    def _analyze_content_length_preference(self, metrics_data: List) -> str:
        """Analyze content length preferences"""
        # This would typically analyze actual content length
        # For now, return a default based on engagement patterns
        avg_engagement = np.mean([row[9] for row in metrics_data])
        
        if avg_engagement > 0.1:
            return "short"
        elif avg_engagement > 0.05:
            return "medium"
        else:
            return "long"
    
    def _calculate_activity_score(self, metrics_data: List) -> float:
        """Calculate audience activity score (0-1)"""
        if not metrics_data:
            return 0.5
        
        # Calculate based on consistency and volume of interactions
        recent_activity = len([row for row in metrics_data if row[4] > 0])
        total_records = len(metrics_data)
        
        return min(recent_activity / total_records, 1.0)
    
    async def create_content_variants(self, original_content: str, 
                                    variant_types: List[str] = None) -> List[ContentVariant]:
        """Create A/B test variants of content"""
        if variant_types is None:
            variant_types = ["short", "long", "question", "emoji", "call_to_action"]
        
        variants = []
        
        for variant_type in variant_types:
            variant_content = await self._generate_variant(original_content, variant_type)
            variant_id = hashlib.md5(f"{original_content}_{variant_type}".encode()).hexdigest()[:8]
            
            variant = ContentVariant(
                id=variant_id,
                content=variant_content,
                variant_type=variant_type,
                metrics={},
                created_at=datetime.now()
            )
            
            variants.append(variant)
            await self._save_variant(variant, original_content)
        
        return variants
    
    async def _generate_variant(self, original_content: str, variant_type: str) -> str:
        """Generate a specific variant of the original content"""
        if variant_type == "short":
            # Create shorter version
            sentences = original_content.split('.')
            return '. '.join(sentences[:2]) + '.' if len(sentences) > 2 else original_content
        
        elif variant_type == "long":
            # Add more context or details
            return original_content + "\n\n💡 Поделитесь своим мнением в комментариях!"
        
        elif variant_type == "question":
            # Convert to question format
            return original_content + "\n\n❓ Как вы думаете, это работает?"
        
        elif variant_type == "emoji":
            # Add relevant emojis
            return "🚀 " + original_content + " ✨"
        
        elif variant_type == "call_to_action":
            # Add call to action
            return original_content + "\n\n👉 Не забудьте поставить лайк и подписаться!"
        
        return original_content
    
    async def _save_variant(self, variant: ContentVariant, original_id: str):
        """Save variant to database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO content_variants 
            (variant_id, original_id, content, variant_type, created_at, performance_score)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            variant.id,
            original_id,
            variant.content,
            variant.variant_type,
            variant.created_at.isoformat(),
            0.0
        ))
        
        conn.commit()
        conn.close()
    
    async def select_best_variant(self, variants: List[ContentVariant], 
                                channel_id: str) -> ContentVariant:
        """Select best variant using multi-armed bandit algorithm"""
        # Get performance scores for each variant
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        variant_scores = {}
        
        for variant in variants:
            cursor.execute('''
                SELECT performance_score FROM content_variants 
                WHERE variant_id = ?
            ''', (variant.id,))
            
            result = cursor.fetchone()
            score = result[0] if result else 0.0
            variant_scores[variant.id] = score
        
        conn.close()
        
        # Apply epsilon-greedy strategy
        if np.random.random() < self.exploration_rate:
            # Explore: random selection
            return np.random.choice(variants)
        else:
            # Exploit: select best performing variant
            best_variant_id = max(variant_scores.items(), key=lambda x: x[1])[0]
            return next(v for v in variants if v.id == best_variant_id)
    
    async def optimize_posting_schedule(self, channel_id: str, 
                                      content_queue: List[Dict]) -> List[Dict]:
        """Optimize posting schedule based on audience activity"""
        metrics = await self.analyze_performance(channel_id)
        
        optimized_schedule = []
        
        for i, content in enumerate(content_queue):
            # Calculate optimal posting time
            base_time = datetime.now() + timedelta(hours=i * 2)
            optimal_hour = int(metrics.optimal_posting_time.split(':')[0])
            
            # Adjust to optimal hour
            optimal_time = base_time.replace(hour=optimal_hour, minute=0, second=0)
            
            # Add jitter to avoid predictable patterns
            jitter_minutes = np.random.randint(-30, 30)
            optimal_time += timedelta(minutes=jitter_minutes)
            
            optimized_content = {
                **content,
                'scheduled_time': optimal_time.isoformat(),
                'confidence_score': metrics.audience_activity_score
            }
            
            optimized_schedule.append(optimized_content)
        
        return optimized_schedule
    
    async def update_optimization_model(self, performance_data: Dict):
        """Update optimization model with new performance data"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Insert performance metrics
        cursor.execute('''
            INSERT INTO performance_metrics 
            (content_id, channel_id, timestamp, views, clicks, shares, likes, 
             comments, engagement_rate, click_through_rate, conversion_rate, 
             optimal_time, audience_segment)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            performance_data.get('content_id'),
            performance_data.get('channel_id'),
            datetime.now().isoformat(),
            performance_data.get('views', 0),
            performance_data.get('clicks', 0),
            performance_data.get('shares', 0),
            performance_data.get('likes', 0),
            performance_data.get('comments', 0),
            performance_data.get('engagement_rate', 0),
            performance_data.get('click_through_rate', 0),
            performance_data.get('conversion_rate', 0),
            performance_data.get('optimal_time'),
            performance_data.get('audience_segment', 'general')
        ))
        
        # Update variant performance if applicable
        if 'variant_id' in performance_data:
            cursor.execute('''
                UPDATE content_variants 
                SET performance_score = ?
                WHERE variant_id = ?
            ''', (
                performance_data.get('performance_score', 0),
                performance_data['variant_id']
            ))
        
        conn.commit()
        conn.close()
        
        self.logger.info(f"Updated optimization model with performance data for {performance_data.get('content_id')}")
    
    async def get_optimization_report(self, channel_id: str, days: int = 30) -> Dict:
        """Generate comprehensive optimization report"""
        metrics = await self.analyze_performance(channel_id, days)
        
        report = {
            'channel_id': channel_id,
            'analysis_period_days': days,
            'metrics': {
                'engagement_rate': round(metrics.engagement_rate, 4),
                'click_through_rate': round(metrics.click_through_rate, 4),
                'conversion_rate': round(metrics.conversion_rate, 4),
                'optimal_posting_time': metrics.optimal_posting_time,
                'content_length_preference': metrics.content_length_preference,
                'audience_activity_score': round(metrics.audience_activity_score, 2)
            },
            'recommendations': await self._generate_recommendations(metrics),
            'generated_at': datetime.now().isoformat()
        }
        
        return report
    
    async def _generate_recommendations(self, metrics: OptimizationMetrics) -> List[str]:
        """Generate optimization recommendations based on metrics"""
        recommendations = []
        
        if metrics.engagement_rate < 0.05:
            recommendations.append("Повысьте вовлеченность: добавьте вопросы и интерактивные элементы")
        
        if metrics.click_through_rate < 0.02:
            recommendations.append("Улучшите CTR: оптимизируйте заголовки и превью")
        
        if metrics.audience_activity_score < 0.5:
            recommendations.append("Повысьте активность аудитории: регулируйте частоту постов")
        
        recommendations.append(f"Оптимальное время публикации: {metrics.optimal_posting_time}")
        recommendations.append(f"Предпочтительная длина контента: {metrics.content_length_preference}")
        
        return recommendations

# Global optimizer instance
optimizer = MLOptimizer()

async def main():
    """Test the optimizer"""
    # Test performance analysis
    channel_id = "test_channel_1"
    metrics = await optimizer.analyze_performance(channel_id)
    print(f"Channel metrics: {metrics}")
    
    # Test variant creation
    original_content = "Привет! Это тестовый пост для оптимизации."
    variants = await optimizer.create_content_variants(original_content)
    print(f"Created {len(variants)} variants")
    
    # Test optimization report
    report = await optimizer.get_optimization_report(channel_id)
    print(f"Optimization report: {report}")

if __name__ == "__main__":
    asyncio.run(main())