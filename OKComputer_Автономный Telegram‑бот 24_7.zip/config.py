"""
UltraBot Configuration Module
Конфигурационный файл для всех компонентов системы
"""

import os
from typing import Dict, List, Any
from dataclasses import dataclass
from pathlib import Path
from dotenv import load_dotenv

# Загрузка переменных окружения
load_dotenv()

# ==========================================
# БАЗОВЫЕ НАСТРОЙКИ
# ==========================================

@dataclass
class BaseConfig:
    """Базовая конфигурация"""
    DEBUG: bool = os.getenv('DEBUG', 'false').lower() == 'true'
    TESTING: bool = os.getenv('TESTING', 'false').lower() == 'true'
    SECRET_KEY: str = os.getenv('SECRET_KEY', 'default-secret-key')
    LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')
    
# ==========================================
# НАСТРОЙКИ БАЗЫ ДАННЫХ
# ==========================================

@dataclass
class DatabaseConfig:
    """Конфигурация базы данных"""
    DATABASE_URL: str = os.getenv('DATABASE_URL', 'postgresql://ultrabot:ultrabot123@localhost:5432/ultrabot')
    REDIS_URL: str = os.getenv('REDIS_URL', 'redis://localhost:6379')
    
    # Пул соединений
    DB_POOL_SIZE: int = 20
    DB_MAX_OVERFLOW: int = 30
    DB_POOL_TIMEOUT: int = 30
    DB_POOL_RECYCLE: int = 3600
    
    # Настройки Redis
    REDIS_POOL_SIZE: int = 10
    REDIS_TIMEOUT: int = 5
    REDIS_RETRY_ATTEMPTS: int = 3

# ==========================================
# TELEGRAM НАСТРОЙКИ
# ==========================================

@dataclass
class TelegramConfig:
    """Конфигурация Telegram"""
    BOT_TOKEN: str = os.getenv('TELEGRAM_BOT_TOKEN', '')
    API_ID: int = int(os.getenv('TELEGRAM_API_ID', '0'))
    API_HASH: str = os.getenv('TELEGRAM_API_HASH', '')
    
    # Ограничения Telegram API
    MAX_MESSAGES_PER_SECOND: int = 30
    MAX_MESSAGES_PER_MINUTE: int = 20
    MAX_MESSAGES_PER_HOUR: int = 100
    
    # Настройки медиа
    MAX_FILE_SIZE: int = 50 * 1024 * 1024  # 50MB
    MAX_PHOTO_SIZE: int = 10 * 1024 * 1024  # 10MB
    MAX_VIDEO_SIZE: int = 50 * 1024 * 1024  # 50MB
    
    # Очереди сообщений
    MESSAGE_QUEUE_SIZE: int = 1000
    MESSAGE_BATCH_SIZE: int = 10
    MESSAGE_BATCH_DELAY: float = 0.1

# ==========================================
# НАСТРОЙКИ ПАРСИНГА
# ==========================================

@dataclass
class ParserConfig:
    """Конфигурация парсера"""
    # Основные настройки
    MAX_CONCURRENT_PARSERS: int = int(os.getenv('MAX_CONCURRENT_PARSERS', '50'))
    REQUEST_TIMEOUT: int = int(os.getenv('REQUEST_TIMEOUT', '30'))
    RETRY_ATTEMPTS: int = int(os.getenv('RETRY_ATTEMPTS', '3'))
    
    # Прокси и ротация
    PROXY_ROTATION_ENABLED: bool = os.getenv('PROXY_ROTATION_ENABLED', 'true').lower() == 'true'
    USER_AGENT_ROTATION: bool = os.getenv('USER_AGENT_ROTATION', 'true').lower() == 'true'
    
    # Задержки
    REQUEST_DELAY_MIN: float = 0.5
    REQUEST_DELAY_MAX: float = 3.0
    PARSER_COOLDOWN: int = 60  # секунды
    
    # Парсинг контента
    MAX_CONTENT_LENGTH: int = 50000  # символов
    MIN_CONTENT_LENGTH: int = 100    # символов
    IMAGE_QUALITY: int = 85          # проценты
    
    # Selenium/Playwright
    BROWSER_TIMEOUT: int = 30
    BROWSER_HEADLESS: bool = True
    BROWSER_WINDOW_SIZE: str = "1920x1080"
    
    # Обход защиты
    CAPTCHA_SOLVING: bool = os.getenv('CAPTCHA_SOLVING', 'true').lower() == 'true'
    ANTI_BOT_DETECTION: bool = True
    HUMAN_BEHAVIOR_SIMULATION: bool = True

# ==========================================
# НАСТРОЙКИ РЕДАКТИРОВАНИЯ
# ==========================================

@dataclass
class EditorConfig:
    """Конфигурация редактора"""
    # NLP обработка
    MAX_TEXT_LENGTH: int = 4096  # Telegram limit
    SUMMARY_RATIO: float = 0.3
    MIN_SENTENCE_LENGTH: int = 10
    MAX_SENTENCE_LENGTH: int = 200
    
    # Оптимизация текста
    ENABLE_TEXT_OPTIMIZATION: bool = True
    ENABLE_EMOJI_INSERTION: bool = True
    ENABLE_HASHTAG_GENERATION: bool = True
    
    # Перевод
    AUTO_TRANSLATE: bool = False
    DEFAULT_LANGUAGE: str = 'ru'
    SUPPORTED_LANGUAGES: List[str] = ['ru', 'en', 'es', 'de', 'fr', 'it', 'pt', 'zh', 'ja', 'ko']
    
    # Модерация
    PROFANITY_FILTER: bool = True
    SPAM_DETECTION: bool = True
    DUPLICATE_DETECTION: bool = True
    QUALITY_THRESHOLD: float = 0.7
    
    # Форматирование
    ENABLE_MARKDOWN: bool = True
    ENABLE_HTML: bool = False
    MAX_HASHTAGS: int = 10
    HASHTAG_PLACEMENT: str = 'end'  # 'end', 'inline', 'mixed'

# ==========================================
# НАСТРОЙКИ ПУБЛИКАЦИЙ
# ==========================================

@dataclass
class PublisherConfig:
    """Конфигурация публикаций"""
    # Расписание
    AUTO_SCHEDULING_ENABLED: bool = os.getenv('AUTO_SCHEDULING_ENABLED', 'true').lower() == 'true'
    MAX_POSTS_PER_HOUR: int = int(os.getenv('MAX_POSTS_PER_HOUR', '10'))
    
    # Время публикаций (UTC)
    PUBLISHING_HOURS_START: int = 8
    PUBLISHING_HOURS_END: int = 22
    OPTIMAL_POSTING_TIMES: List[int] = [9, 12, 15, 18, 21]
    
    # Кросс-постинг
    CROSS_POSTING_ENABLED: bool = os.getenv('CROSS_POSTING_ENABLED', 'true').lower() == 'true'
    CHANNEL_COOLDOWN: int = 300  # секунды
    
    # Медиа
    MEDIA_OPTIMIZATION: bool = os.getenv('MEDIA_OPTIMIZATION', 'true').lower() == 'true'
    CREATE_COLLAGES: bool = True
    ADD_WATERMARKS: bool = False
    WATERMARK_PATH: str = ""
    
    # Очереди
    PUBLISHING_QUEUE_SIZE: int = 100
    FAILED_POST_RETRY_DELAY: int = 600  # секунды
    MAX_RETRY_ATTEMPTS: int = 3

# ==========================================
# НАСТРОЙКИ ML
# ==========================================

@dataclass
class MLConfig:
    """Конфигурация машинного обучения"""
    # Обновление моделей
    ML_MODEL_UPDATE_INTERVAL: int = int(os.getenv('ML_MODEL_UPDATE_INTERVAL', '3600'))
    PREDICTION_ACCURACY_THRESHOLD: float = float(os.getenv('PREDICTION_ACCURACY_THRESHOLD', '0.8'))
    
    # Автооптимизация
    AUTO_OPTIMIZATION_ENABLED: bool = os.getenv('AUTO_OPTIMIZATION_ENABLED', 'true').lower() == 'true'
    LEARNING_RATE: float = 0.001
    BATCH_SIZE: int = 32
    EPOCHS: int = 10
    
    # Анализ аудитории
    AUDIENCE_ANALYSIS_ENABLED: bool = True
    ENGAGEMENT_TRACKING: bool = True
    TREND_DETECTION: bool = True
    
    # Модели
    SENTIMENT_ANALYSIS_MODEL: str = "cardiffnlp/twitter-roberta-base-sentiment"
    TEXT_GENERATION_MODEL: str = "gpt-3.5-turbo"
    EMBEDDING_MODEL: str = "sentence-transformers/all-MiniLM-L6-v2"

# ==========================================
# НАСТРОЙКИ МОНИТОРИНГА
# ==========================================

@dataclass
class MonitoringConfig:
    """Конфигурация мониторинга"""
    # Health checks
    HEALTH_CHECK_INTERVAL: int = 60  # секунды
    HEALTH_CHECK_TIMEOUT: int = 10   # секунды
    
    # Метрики
    METRICS_COLLECTION_ENABLED: bool = True
    METRICS_RETENTION_DAYS: int = 30
    
    # Оповещения
    ALERT_WEBHOOK: str = os.getenv('ALERT_WEBHOOK', '')
    ALERT_EMAIL: str = os.getenv('ALERT_EMAIL', '')
    
    # Пороги оповещений
    CPU_USAGE_THRESHOLD: float = 80.0  # проценты
    RAM_USAGE_THRESHOLD: float = 85.0  # проценты
    DISK_USAGE_THRESHOLD: float = 90.0 # проценты
    
    # Системные оповещения
    SERVICE_RESTART_THRESHOLD: int = 3
    FAILED_POST_THRESHOLD: int = 5
    PARSER_ERROR_THRESHOLD: float = 10.0  # проценты

# ==========================================
# НАСТРОЙКИ БЕЗОПАСНОСТИ
# ==========================================

@dataclass
class SecurityConfig:
    """Конфигурация безопасности"""
    # Шифрование
    ENCRYPTION_KEY: str = os.getenv('ENCRYPTION_KEY', 'default-encryption-key')
    JWT_SECRET: str = os.getenv('JWT_SECRET', 'default-jwt-secret')
    JWT_EXPIRATION: int = 3600  # секунды
    
    # Доступ
    ADMIN_PASSWORD: str = os.getenv('ADMIN_PASSWORD', 'admin123')
    RATE_LIMITING_ENABLED: bool = True
    MAX_REQUESTS_PER_MINUTE: int = 60
    
    # Бэкапы
    BACKUP_ENABLED: bool = os.getenv('BACKUP_ENABLED', 'true').lower() == 'true'
    BACKUP_SCHEDULE: str = os.getenv('BACKUP_SCHEDULE', '0 2 * * *')
    BACKUP_RETENTION_DAYS: int = int(os.getenv('BACKUP_RETENTION_DAYS', '30'))
    BACKUP_CLOUD_STORAGE: bool = os.getenv('BACKUP_CLOUD_STORAGE', 'true').lower() == 'true'

# ==========================================
# НАСТРОЙКИ ВЕБ ПАНЕЛИ
# ==========================================

@dataclass
class WebPanelConfig:
    """Конфигурация веб панели"""
    PORT: int = int(os.getenv('WEB_PANEL_PORT', '8080'))
    HOST: str = os.getenv('WEB_PANEL_HOST', '0.0.0.0')
    
    # SSL
    SSL_ENABLED: bool = os.getenv('SSL_ENABLED', 'false').lower() == 'true'
    SSL_CERT_PATH: str = os.getenv('SSL_CERT_PATH', '')
    SSL_KEY_PATH: str = os.getenv('SSL_KEY_PATH', '')
    
    # Сессии
    SESSION_TIMEOUT: int = 3600  # секунды
    SESSION_SECRET: str = os.getenv('SECRET_KEY', 'default-session-secret')
    
    # CORS
    CORS_ENABLED: bool = True
    CORS_ORIGINS: List[str] = ['*']

# ==========================================
# ОБЩИЙ КОНФИГУРАЦИОННЫЙ КЛАСС
# ==========================================

class Config:
    """Главный конфигурационный класс"""
    
    # Экземпляры конфигураций
    base = BaseConfig()
    database = DatabaseConfig()
    telegram = TelegramConfig()
    parser = ParserConfig()
    editor = EditorConfig()
    publisher = PublisherConfig()
    ml = MLConfig()
    monitoring = MonitoringConfig()
    security = SecurityConfig()
    web_panel = WebPanelConfig()
    
    # API ключи
    OPENAI_API_KEY: str = os.getenv('OPENAI_API_KEY', '')
    ANTHROPIC_API_KEY: str = os.getenv('ANTHROPIC_API_KEY', '')
    DEEPL_API_KEY: str = os.getenv('DEEPL_API_KEY', '')
    ANTI_CAPTCHA_KEY: str = os.getenv('ANTI_CAPTCHA_KEY', '')
    
    # Пути
    BASE_DIR: Path = Path(__file__).parent
    LOGS_DIR: Path = BASE_DIR / 'logs'
    DATA_DIR: Path = BASE_DIR / 'data'
    MODELS_DIR: Path = BASE_DIR / 'models'
    
    # Создание директорий
    LOGS_DIR.mkdir(exist_ok=True)
    DATA_DIR.mkdir(exist_ok=True)
    MODELS_DIR.mkdir(exist_ok=True)
    
    @classmethod
    def validate_config(cls) -> Dict[str, Any]:
        """Проверка конфигурации на наличие обязательных параметров"""
        errors = {}
        warnings = {}
        
        # Проверка Telegram
        if not cls.telegram.BOT_TOKEN:
            errors['TELEGRAM_BOT_TOKEN'] = 'Отсутствует обязательный параметр'
        if not cls.telegram.API_ID:
            errors['TELEGRAM_API_ID'] = 'Отсутствует обязательный параметр'
        if not cls.telegram.API_HASH:
            errors['TELEGRAM_API_HASH'] = 'Отсутствует обязательный параметр'
            
        # Проверка базы данных
        if not cls.database.DATABASE_URL:
            errors['DATABASE_URL'] = 'Отсутствует обязательный параметр'
        if not cls.database.REDIS_URL:
            warnings['REDIS_URL'] = 'Используется Redis по умолчанию'
            
        # Проверка секретных ключей
        if cls.security.ENCRYPTION_KEY == 'default-encryption-key':
            warnings['ENCRYPTION_KEY'] = 'Используется ключ по умолчанию'
        if cls.security.SECRET_KEY == 'default-secret-key':
            warnings['SECRET_KEY'] = 'Используется ключ по умолчанию'
            
        return {
            'errors': errors,
            'warnings': warnings,
            'is_valid': len(errors) == 0
        }

# Глобальный экземпляр конфигурации
config = Config()