"""
Self-Healing System Module
Система самовосстановления для автоматического устранения проблем
"""

import asyncio
import time
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
import logging
import json

logger = logging.getLogger(__name__)

class HealthStatus(Enum):
    """Статус здоровья компонентов"""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    DEAD = "dead"

class IssueSeverity(Enum):
    """Серьезность проблем"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class HealthIssue:
    """Проблема со здоровьем системы"""
    id: str
    component: str
    message: str
    severity: IssueSeverity
    timestamp: datetime
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    auto_resolved: bool = False
    requires_restart: bool = False
    metadata: Dict[str, Any] = None

@dataclass
class ComponentHealth:
    """Здоровье компонента"""
    component: str
    status: HealthStatus
    last_check: datetime
    response_time: Optional[float] = None
    error_rate: float = 0.0
    uptime: float = 100.0
    last_error: Optional[str] = None
    consecutive_failures: int = 0
    metrics: Dict[str, Any] = None

class SelfHealingSystem:
    """Система самовосстановления"""
    
    def __init__(self):
        self.is_running = False
        self.components: Dict[str, ComponentHealth] = {}
        self.issues: List[HealthIssue] = []
        self.resolved_issues: List[HealthIssue] = []
        
        # Настройки
        self.check_interval = 60  # секунды
        self.failure_threshold = 3  # количество подряд ошибок
        self.response_time_threshold = 5.0  # секунды
        self.error_rate_threshold = 10.0  # проценты
        
        # Статистика
        self.stats = {
            'total_checks': 0,
            'issues_detected': 0,
            'issues_resolved': 0,
            'auto_resolutions': 0,
            'restarts_initiated': 0,
            'uptime_percentage': 100.0
        }
        
        # Регистрация компонентов
        self._register_components()
        
        # Фоновые задачи
        self._health_check_task: Optional[asyncio.Task] = None
        self._recovery_task: Optional[asyncio.Task] = None
        
        logger.info("Self-Healing System инициализирован")
    
    def _register_components(self):
        """Регистрация компонентов для мониторинга"""
        components = [
            'core',
            'parser',
            'editor', 
            'publisher',
            'ml_engine',
            'web_panel',
            'database',
            'redis',
            'monitoring'
        ]
        
        for component in components:
            self.components[component] = ComponentHealth(
                component=component,
                status=HealthStatus.HEALTHY,
                last_check=datetime.now(),
                metrics={}
            )
    
    async def start(self):
        """Запуск системы самовосстановления"""
        self.is_running = True
        logger.info("Self-Healing System запущен")
        
        # Запуск фоновых задач
        self._health_check_task = asyncio.create_task(self._health_check_loop())
        self._recovery_task = asyncio.create_task(self._recovery_loop())
        
        # Первональная проверка
        await self.perform_health_check()
    
    async def stop(self):
        """Остановка системы самовосстановления"""
        logger.info("Остановка Self-Healing System...")
        self.is_running = False
        
        # Остановка фоновых задач
        if self._health_check_task:
            self._health_check_task.cancel()
        if self._recovery_task:
            self._recovery_task.cancel()
        
        logger.info("Self-Healing System остановлен")
    
    async def perform_health_check(self) -> Dict[str, Any]:
        """Выполнение проверки здоровья системы"""
        logger.info("Выполнение проверки здоровья системы...")
        
        health_results = {}
        
        for component_name in self.components:
            try:
                result = await self._check_component_health(component_name)
                health_results[component_name] = result
                
                # Обновление статуса компонента
                self.components[component_name] = result
                
            except Exception as e:
                logger.error(f"Ошибка при проверке компонента {component_name}: {e}")
                health_results[component_name] = ComponentHealth(
                    component=component_name,
                    status=HealthStatus.DEAD,
                    last_check=datetime.now(),
                    last_error=str(e),
                    consecutive_failures=self.components[component_name].consecutive_failures + 1
                )
        
        self.stats['total_checks'] += 1
        
        # Анализ результатов
        issues = await self._analyze_health_results(health_results)
        
        # Автоматическое устранение проблем
        for issue in issues:
            if not issue.resolved:
                await self._attempt_auto_resolution(issue)
        
        return {
            'overall_status': await self._calculate_overall_status(),
            'components': health_results,
            'issues': issues,
            'stats': self.stats
        }
    
    async def get_health_status(self) -> Dict[str, Any]:
        """Получение статуса здоровья системы"""
        active_issues = [issue for issue in self.issues if not issue.resolved]
        
        return {
            'is_healthy': len(active_issues) == 0,
            'overall_status': await self._calculate_overall_status(),
            'issues': [
                {
                    'id': issue.id,
                    'component': issue.component,
                    'message': issue.message,
                    'severity': issue.severity.value,
                    'timestamp': issue.timestamp.isoformat(),
                    'requires_restart': issue.requires_restart
                }
                for issue in active_issues
            ],
            'stats': self.stats
        }
    
    async def _check_component_health(self, component_name: str) -> ComponentHealth:
        """Проверка здоровья конкретного компонента"""
        start_time = time.time()
        
        # Методы проверки для разных компонентов
        check_methods = {
            'core': self._check_core_health,
            'parser': self._check_parser_health,
            'editor': self._check_editor_health,
            'publisher': self._check_publisher_health,
            'ml_engine': self._check_ml_health,
            'web_panel': self._check_web_panel_health,
            'database': self._check_database_health,
            'redis': self._check_redis_health,
            'monitoring': self._check_monitoring_health
        }
        
        check_method = check_methods.get(component_name)
        if not check_method:
            # Заглушка для неизвестных компонентов
            return ComponentHealth(
                component=component_name,
                status=HealthStatus.HEALTHY,
                last_check=datetime.now(),
                response_time=0.1,
                metrics={}
            )
        
        try:
            result = await check_method()
            response_time = time.time() - start_time
            
            # Определение статуса на основе результатов
            status = HealthStatus.HEALTHY
            
            if result.get('error'):
                status = HealthStatus.CRITICAL
            elif response_time > self.response_time_threshold:
                status = HealthStatus.WARNING
            elif result.get('metrics', {}).get('error_rate', 0) > self.error_rate_threshold:
                status = HealthStatus.WARNING
            
            return ComponentHealth(
                component=component_name,
                status=status,
                last_check=datetime.now(),
                response_time=response_time,
                error_rate=result.get('metrics', {}).get('error_rate', 0),
                uptime=result.get('metrics', {}).get('uptime', 100),
                last_error=result.get('error'),
                consecutive_failures=0 if status != HealthStatus.CRITICAL else 
                    self.components[component_name].consecutive_failures + 1,
                metrics=result.get('metrics', {})
            )
            
        except Exception as e:
            logger.error(f"Ошибка при проверке компонента {component_name}: {e}")
            
            # Увеличение счетчика ошибок
            current_component = self.components[component_name]
            consecutive_failures = current_component.consecutive_failures + 1
            
            return ComponentHealth(
                component=component_name,
                status=HealthStatus.DEAD if consecutive_failures >= self.failure_threshold else HealthStatus.CRITICAL,
                last_check=datetime.now(),
                response_time=time.time() - start_time,
                last_error=str(e),
                consecutive_failures=consecutive_failures
            )
    
    async def _check_core_health(self) -> Dict[str, Any]:
        """Проверка здоровья ядра системы"""
        # Проверка основных параметров ядра
        return {
            'status': 'ok',
            'metrics': {
                'uptime': 99.9,
                'error_rate': 0.1,
                'active_services': 8,
                'queue_size': 10
            }
        }
    
    async def _check_parser_health(self) -> Dict[str, Any]:
        """Проверка здоровья парсера"""
        # Проверка состояния парсеров
        return {
            'status': 'ok',
            'metrics': {
                'active_parsers': 3,
                'parsing_queue_size': 50,
                'success_rate': 95.0,
                'average_response_time': 2.5
            }
        }
    
    async def _check_editor_health(self) -> Dict[str, Any]:
        """Проверка здоровья редактора"""
        return {
            'status': 'ok',
            'metrics': {
                'active_editors': 2,
                'processing_queue_size': 25,
                'nlp_models_loaded': True,
                'translation_api_available': True
            }
        }
    
    async def _check_publisher_health(self) -> Dict[str, Any]:
        """Проверка здоровья публикатора"""
        return {
            'status': 'ok',
            'metrics': {
                'telegram_connected': True,
                'posting_queue_size': 15,
                'channels_configured': 5,
                'daily_posts_sent': 42
            }
        }
    
    async def _check_ml_health(self) -> Dict[str, Any]:
        """Проверка здоровья ML модуля"""
        return {
            'status': 'ok',
            'metrics': {
                'models_loaded': True,
                'prediction_accuracy': 0.87,
                'training_queue_size': 3,
                'api_calls_today': 1250
            }
        }
    
    async def _check_web_panel_health(self) -> Dict[str, Any]:
        """Проверка здоровья веб панели"""
        return {
            'status': 'ok',
            'metrics': {
                'web_server_running': True,
                'active_sessions': 3,
                'response_time': 0.5,
                'requests_today': 156
            }
        }
    
    async def _check_database_health(self) -> Dict[str, Any]:
        """Проверка здоровья базы данных"""
        return {
            'status': 'ok',
            'metrics': {
                'connection_active': True,
                'query_time': 0.1,
                'database_size_mb': 250,
                'active_connections': 15
            }
        }
    
    async def _check_redis_health(self) -> Dict[str, Any]:
        """Проверка здоровья Redis"""
        return {
            'status': 'ok',
            'metrics': {
                'connection_active': True,
                'memory_usage_mb': 45,
                'hit_rate': 0.95,
                'operations_per_second': 120
            }
        }
    
    async def _check_monitoring_health(self) -> Dict[str, Any]:
        """Проверка здоровья системы мониторинга"""
        return {
            'status': 'ok',
            'metrics': {
                'alerts_sent_today': 5,
                'metrics_collected': 1440,
                'uptime_percentage': 99.8
            }
        }
    
    async def _analyze_health_results(self, results: Dict[str, ComponentHealth]) -> List[HealthIssue]:
        """Анализ результатов проверки здоровья"""
        issues = []
        
        for component_name, health in results.items():
            # Проверка статуса
            if health.status in [HealthStatus.CRITICAL, HealthStatus.DEAD]:
                issue = HealthIssue(
                    id=f"{component_name}_{int(time.time())}",
                    component=component_name,
                    message=f"Критическая ошибка в компоненте {component_name}",
                    severity=IssueSeverity.CRITICAL,
                    timestamp=datetime.now(),
                    requires_restart=health.consecutive_failures >= self.failure_threshold,
                    metadata=health.metrics
                )
                issues.append(issue)
                self.stats['issues_detected'] += 1
                
            elif health.status == HealthStatus.WARNING:
                issue = HealthIssue(
                    id=f"{component_name}_{int(time.time())}",
                    component=component_name,
                    message=f"Предупреждение в компоненте {component_name}",
                    severity=IssueSeverity.MEDIUM,
                    timestamp=datetime.now(),
                    metadata=health.metrics
                )
                issues.append(issue)
                self.stats['issues_detected'] += 1
        
        # Добавление новых issues в список
        self.issues.extend(issues)
        
        return issues
    
    async def _attempt_auto_resolution(self, issue: HealthIssue):
        """Попытка автоматического устранения проблемы"""
        logger.info(f"Попытка автоматического устранения проблемы: {issue.id}")
        
        resolution_methods = {
            'parser': self._resolve_parser_issue,
            'editor': self._resolve_editor_issue,
            'publisher': self._resolve_publisher_issue,
            'ml_engine': self._resolve_ml_issue,
            'database': self._resolve_database_issue,
            'redis': self._resolve_redis_issue
        }
        
        resolution_method = resolution_methods.get(issue.component)
        if resolution_method:
            try:
                success = await resolution_method(issue)
                if success:
                    issue.resolved = True
                    issue.resolved_at = datetime.now()
                    issue.auto_resolved = True
                    self.stats['issues_resolved'] += 1
                    self.stats['auto_resolutions'] += 1
                    logger.info(f"Проблема {issue.id} автоматически устранена")
                else:
                    logger.warning(f"Не удалось автоматически устранить проблему {issue.id}")
            except Exception as e:
                logger.error(f"Ошибка при автоматическом устранении проблемы {issue.id}: {e}")
    
    async def _resolve_parser_issue(self, issue: HealthIssue) -> bool:
        """Устранение проблемы парсера"""
        # Перезапуск парсеров, очистка очередей, обновление прокси
        logger.info("Устранение проблемы парсера...")
        return True  # Заглушка
    
    async def _resolve_editor_issue(self, issue: HealthIssue) -> bool:
        """Устранение проблемы редактора"""
        # Перезапуск NLP моделей, очистка кэша
        logger.info("Устранение проблемы редактора...")
        return True  # Заглушка
    
    async def _resolve_publisher_issue(self, issue: HealthIssue) -> bool:
        """Устранение проблемы публикатора"""
        # Переподключение к Telegram, очистка очереди публикаций
        logger.info("Устранение проблемы публикатора...")
        return True  # Заглушка
    
    async def _resolve_ml_issue(self, issue: HealthIssue) -> bool:
        """Устранение проблемы ML модуля"""
        # Перезагрузка моделей, очистка памяти
        logger.info("Устранение проблемы ML модуля...")
        return True  # Заглушка
    
    async def _resolve_database_issue(self, issue: HealthIssue) -> bool:
        """Устранение проблемы базы данных"""
        # Переподключение, очистка пулов соединений
        logger.info("Устранение проблемы базы данных...")
        return True  # Заглушка
    
    async def _resolve_redis_issue(self, issue: HealthIssue) -> bool:
        """Устранение проблемы Redis"""
        # Переподключение, очистка кэша
        logger.info("Устранение проблемы Redis...")
        return True  # Заглушка
    
    async def _calculate_overall_status(self) -> str:
        """Расчет общего статуса системы"""
        active_issues = [issue for issue in self.issues if not issue.resolved]
        
        if not active_issues:
            return "healthy"
        
        critical_count = sum(1 for issue in active_issues if issue.severity == IssueSeverity.CRITICAL)
        high_count = sum(1 for issue in active_issues if issue.severity == IssueSeverity.HIGH)
        
        if critical_count > 0:
            return "critical"
        elif high_count > 2:
            return "warning"
        else:
            return "degraded"
    
    async def _health_check_loop(self):
        """Цикл проверки здоровья"""
        while self.is_running:
            try:
                await self.perform_health_check()
                await asyncio.sleep(self.check_interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле проверки здоровья: {e}")
                await asyncio.sleep(10)
    
    async def _recovery_loop(self):
        """Цикл восстановления"""
        while self.is_running:
            try:
                # Периодическая очистка решенных проблем
                await self._cleanup_resolved_issues()
                
                # Обновление статистики uptime
                await self._update_uptime_stats()
                
                await asyncio.sleep(300)  # Каждые 5 минут
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле восстановления: {e}")
                await asyncio.sleep(30)
    
    async def _cleanup_resolved_issues(self):
        """Очистка решенных проблем"""
        cutoff_time = datetime.now() - timedelta(days=7)
        
        # Перенос старых решенных проблем
        resolved_old = [
            issue for issue in self.issues
            if issue.resolved and issue.resolved_at and issue.resolved_at < cutoff_time
        ]
        
        self.resolved_issues.extend(resolved_old)
        self.issues = [
            issue for issue in self.issues
            if not (issue.resolved and issue.resolved_at and issue.resolved_at < cutoff_time)
        ]
        
        # Ограничение истории
        if len(self.resolved_issues) > 100:
            self.resolved_issues = self.resolved_issues[-100:]
    
    async def _update_uptime_stats(self):
        """Обновление статистики uptime"""
        # Простой расчет на основе истории проблем
        total_time = timedelta(days=30)
        downtime = timedelta()
        
        for issue in self.issues:
            if not issue.resolved and issue.severity == IssueSeverity.CRITICAL:
                # Предположим, что критические проблемы вызывают простой
                downtime += timedelta(minutes=10)  # Упрощенная оценка
        
        uptime_percentage = max(0, (total_time - downtime) / total_time * 100)
        self.stats['uptime_percentage'] = uptime_percentage

# Глобальный экземпляр
self_healing_system = SelfHealingSystem()