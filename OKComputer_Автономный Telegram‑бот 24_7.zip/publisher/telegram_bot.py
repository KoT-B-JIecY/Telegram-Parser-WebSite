"""
Telegram Bot Module
Управление Telegram ботом и публикация контента
"""

import asyncio
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging
import time

from telegram import Bot, InputMediaPhoto, InputMediaVideo, InputMediaDocument
from telegram.error import TelegramError, RetryAfter, TimedOut

logger = logging.getLogger(__name__)

@dataclass
class TelegramMessage:
    """Telegram сообщение"""
    chat_id: str
    message_id: int
    text: Optional[str] = None
    media_group_id: Optional[str] = None
    date: Optional[int] = None
    views: Optional[int] = None
    reactions: Optional[int] = None

@dataclass
class PublishingResult:
    """Результат публикации"""
    success: bool
    message_ids: Dict[str, int]  # chat_id -> message_id
    error: Optional[str] = None
    published_at: Optional[float] = None

class TelegramBot:
    """Telegram Bot для публикации контента"""
    
    def __init__(self):
        self.bot: Optional[Bot] = None
        self.is_connected = False
        
        # Настройки
        self.rate_limit_delay = 1.0  # секунды между запросами
        self.max_retries = 3
        self.timeout = 30
        
        # Мониторинг лимитов
        self.request_count = 0
        self.last_request_time = 0
        
        # Кэш информации о каналах
        self.channel_cache: Dict[str, Dict[str, Any]] = {}
        self._cache_ttl = 3600  # 1 час
        
        # Статистика
        self.stats = {
            'messages_sent': 0,
            'media_sent': 0,
            'errors_encountered': 0,
            'rate_limit_hits': 0,
            'channels_joined': 0
        }
        
        logger.info("Telegram Bot инициализирован")
    
    async def initialize(self):
        """Инициализация Telegram бота"""
        try:
            from config import config
            
            if not config.telegram.BOT_TOKEN:
                raise ValueError("Telegram bot token not configured")
            
            self.bot = Bot(token=config.telegram.BOT_TOKEN)
            
            # Проверка подключения
            bot_info = await self.bot.get_me()
            self.is_connected = True
            
            logger.info(f"Telegram Bot подключен: {bot_info.first_name} (@{bot_info.username})")
            
        except Exception as e:
            logger.error(f"Ошибка при инициализации Telegram Bot: {e}")
            raise
    
    async def cleanup(self):
        """Очистка ресурсов"""
        if self.bot:
            # Закрытие сессии
            await self.bot.session.close()
        
        logger.info("Telegram Bot очищен")
    
    async def publish_post(self, content: Dict[str, Any]) -> Dict[str, int]:
        """
        Публикация поста в Telegram
        
        Args:
            content: Контент для публикации
                - title: Заголовок поста
                - content: Основной текст
                - images: Список URL изображений
                - videos: Список URL видео
                - channel_id: ID канала для публикации
                
        Returns:
            Словарь с message_id для каждого канала
        """
        if not self.is_connected:
            await self.initialize()
        
        channel_id = content.get('channel_id') or content.get('chat_id')
        if not channel_id:
            raise ValueError("Channel ID not specified")
        
        try:
            # Ожидание rate limit
            await self._respect_rate_limit()
            
            # Формирование текста сообщения
            message_text = await self._format_message_text(content)
            
            # Обработка медиа
            message_ids = {}
            
            if content.get('images') or content.get('videos'):
                # Публикация с медиа
                media_message_ids = await self._publish_with_media(
                    channel_id,
                    message_text,
                    content
                )
                message_ids.update(media_message_ids)
            else:
                # Публикация только текста
                message = await self.bot.send_message(
                    chat_id=channel_id,
                    text=message_text,
                    parse_mode='HTML',
                    disable_web_page_preview=False
                )
                message_ids[channel_id] = message.message_id
            
            # Обновление статистики
            self.stats['messages_sent'] += 1
            if content.get('images') or content.get('videos'):
                self.stats['media_sent'] += 1
            
            logger.info(f"Сообщение опубликовано в канал {channel_id}: {message_ids}")
            return message_ids
            
        except RetryAfter as e:
            logger.warning(f"Rate limit hit, waiting {e.retry_after} seconds")
            self.stats['rate_limit_hits'] += 1
            await asyncio.sleep(e.retry_after)
            return await self.publish_post(content)
            
        except TimedOut:
            logger.error("Telegram API timeout")
            self.stats['errors_encountered'] += 1
            raise
            
        except TelegramError as e:
            logger.error(f"Telegram API error: {e}")
            self.stats['errors_encountered'] += 1
            raise
            
        except Exception as e:
            logger.error(f"Unexpected error publishing post: {e}")
            self.stats['errors_encountered'] += 1
            raise
    
    async def publish_to_multiple_channels(
        self,
        content: Dict[str, Any],
        channel_ids: List[str]
    ) -> Dict[str, int]:
        """Публикация в несколько каналов"""
        all_message_ids = {}
        
        for channel_id in channel_ids:
            try:
                # Копирование контента с новым channel_id
                channel_content = content.copy()
                channel_content['channel_id'] = channel_id
                
                message_ids = await self.publish_post(channel_content)
                all_message_ids.update(message_ids)
                
                # Небольшая задержка между публикациями
                await asyncio.sleep(self.rate_limit_delay)
                
            except Exception as e:
                logger.error(f"Error publishing to channel {channel_id}: {e}")
                continue
        
        return all_message_ids
    
    async def edit_message(
        self,
        channel_id: str,
        message_id: int,
        new_text: str,
        media: Optional[List[str]] = None
    ) -> bool:
        """Редактирование опубликованного сообщения"""
        try:
            await self._respect_rate_limit()
            
            await self.bot.edit_message_text(
                chat_id=channel_id,
                message_id=message_id,
                text=new_text,
                parse_mode='HTML'
            )
            
            logger.info(f"Сообщение отредактировано: {channel_id}/{message_id}")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при редактировании сообщения: {e}")
            return False
    
    async def delete_message(self, channel_id: str, message_id: int) -> bool:
        """Удаление сообщения"""
        try:
            await self._respect_rate_limit()
            
            await self.bot.delete_message(
                chat_id=channel_id,
                message_id=message_id
            )
            
            logger.info(f"Сообщение удалено: {channel_id}/{message_id}")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при удалении сообщения: {e}")
            return False
    
    async def get_message_stats(
        self,
        channel_id: str,
        message_id: int
    ) -> Dict[str, Any]:
        """Получение статистики сообщения"""
        try:
            message = await self.bot.forward_message(
                chat_id=channel_id,  # В тот же канал
                from_chat_id=channel_id,
                message_id=message_id
            )
            
            # Получение информации о сообщении
            stats = {
                'views': getattr(message, 'views', 0),
                'forwards': getattr(message, 'forwards', 0),
                'reactions': len(getattr(message, 'reactions', []) or []),
                'date': message.date
            }
            
            # Удаление пересланного сообщения
            await self.bot.delete_message(
                chat_id=channel_id,
                message_id=message.message_id
            )
            
            return stats
            
        except Exception as e:
            logger.error(f"Ошибка при получении статистики сообщения: {e}")
            return {'views': 0, 'forwards': 0, 'reactions': 0}
    
    async def get_channel_info(self, channel_id: str) -> Dict[str, Any]:
        """Получение информации о канале"""
        try:
            # Проверка кэша
            if channel_id in self.channel_cache:
                if time.time() - self.channel_cache[channel_id].get('timestamp', 0) < self._cache_ttl:
                    return self.channel_cache[channel_id]
            
            # Получение информации о канале
            chat = await self.bot.get_chat(chat_id=channel_id)
            
            channel_info = {
                'id': chat.id,
                'title': chat.title,
                'username': getattr(chat, 'username', None),
                'description': getattr(chat, 'description', ''),
                'member_count': getattr(chat, 'members_count', 0),
                'type': chat.type,
                'timestamp': time.time()
            }
            
            # Кэширование
            self.channel_cache[channel_id] = channel_info
            
            return channel_info
            
        except Exception as e:
            logger.error(f"Ошибка при получении информации о канале {channel_id}: {e}")
            return {'id': channel_id, 'error': str(e)}
    
    async def join_channel(self, channel_id: str) -> bool:
        """Присоединение к каналу"""
        try:
            # Для публичных каналов - просто попытка получить информацию
            await self.get_channel_info(channel_id)
            self.stats['channels_joined'] += 1
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при присоединении к каналу {channel_id}: {e}")
            return False
    
    async def leave_channel(self, channel_id: str) -> bool:
        """Покидание канала"""
        try:
            # Очистка кэша
            if channel_id in self.channel_cache:
                del self.channel_cache[channel_id]
            
            logger.info(f"Покинут канал: {channel_id}")
            return True
            
        except Exception as e:
            logger.error(f"Ошибка при покидании канала {channel_id}: {e}")
            return False
    
    async def _format_message_text(self, content: Dict[str, Any]) -> str:
        """Форматирование текста сообщения"""
        parts = []
        
        # Заголовок
        if content.get('title'):
            parts.append(f"<b>{content['title']}</b>\n")
        
        # Основной контент
        if content.get('content'):
            text = content['content']
            
            # Ограничение длины для Telegram (4096 символов)
            if len(text) > 4000:
                text = text[:3997] + "..."
            
            parts.append(text)
        
        # Хештеги
        if content.get('hashtags'):
            hashtags_str = ' '.join(content['hashtags'][:10])  # Максимум 10 хештегов
            parts.append(f"\n{hashtags_str}")
        
        # Автор и источник
        footer_parts = []
        if content.get('author'):
            footer_parts.append(f"Автор: {content['author']}")
        
        if content.get('source_url'):
            footer_parts.append(f"Источник: {content['source_url']}")
        
        if footer_parts:
            parts.append(f"\n\n<i>{' | '.join(footer_parts)}</i>")
        
        return '\n'.join(parts)
    
    async def _publish_with_media(
        self,
        channel_id: str,
        text: str,
        content: Dict[str, Any]
    ) -> Dict[str, int]:
        """Публикация с медиа файлами"""
        images = content.get('images', [])[:10]  # Максимум 10 изображений
        videos = content.get('videos', [])[:1]   # Максимум 1 видео
        
        message_ids = {}
        
        if len(images) > 1:
            # Публикация группы изображений
            media_group = []
            
            for i, image_url in enumerate(images):
                if i == 0:
                    # Первое изображение с текстом
                    media_group.append(
                        InputMediaPhoto(
                            media=image_url,
                            caption=text,
                            parse_mode='HTML'
                        )
                    )
                else:
                    media_group.append(InputMediaPhoto(media=image_url))
            
            messages = await self.bot.send_media_group(
                chat_id=channel_id,
                media=media_group
            )
            
            # Возврат ID первого сообщения в группе
            if messages:
                message_ids[channel_id] = messages[0].message_id
                
        elif len(images) == 1:
            # Публикация одного изображения
            message = await self.bot.send_photo(
                chat_id=channel_id,
                photo=images[0],
                caption=text,
                parse_mode='HTML'
            )
            message_ids[channel_id] = message.message_id
            
        elif videos:
            # Публикация видео
            message = await self.bot.send_video(
                chat_id=channel_id,
                video=videos[0],
                caption=text,
                parse_mode='HTML'
            )
            message_ids[channel_id] = message.message_id
        
        else:
            # Публикация только текста если медиа не удалось
            message = await self.bot.send_message(
                chat_id=channel_id,
                text=text,
                parse_mode='HTML'
            )
            message_ids[channel_id] = message.message_id
        
        return message_ids
    
    async def _respect_rate_limit(self):
        """Соблюдение rate limit Telegram API"""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.rate_limit_delay:
            sleep_time = self.rate_limit_delay - time_since_last
            await asyncio.sleep(sleep_time)
        
        self.last_request_time = time.time()
        self.request_count += 1
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса Telegram бота"""
        return {
            'is_connected': self.is_connected,
            'stats': self.stats,
            'rate_limit_delay': self.rate_limit_delay,
            'channels_cached': len(self.channel_cache),
            'request_count': self.request_count
        }

# Глобальный экземпляр
telegram_bot = TelegramBot()