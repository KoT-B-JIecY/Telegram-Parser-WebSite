"""
Task Scheduler Module
Планировщик задач для UltraBot с приоритетами и динамическим распределением ресурсов
"""

import asyncio
import heapq
import time
import uuid
from typing import Dict, List, Any, Optional, Callable, Coroutine
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class TaskPriority(Enum):
    """Приоритеты задач"""
    CRITICAL = 1
    HIGH = 2
    NORMAL = 3
    LOW = 4
    BACKGROUND = 5

class TaskStatus(Enum):
    """Статусы задач"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"

@dataclass
class Task:
    """Класс задачи"""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""
    func: Optional[Callable] = None
    args: tuple = field(default_factory=tuple)
    kwargs: dict = field(default_factory=dict)
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    created_at: datetime = field(default_factory=datetime.now)
    scheduled_at: Optional[datetime] = None
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    max_retries: int = 3
    retry_count: int = 0
    timeout: int = 300  # секунды
    dependencies: List[str] = field(default_factory=list)
    callback: Optional[Callable] = None
    error: Optional[str] = None
    result: Any = None
    
    def __lt__(self, other):
        """Сравнение для приоритетной очереди"""
        return (self.priority.value, self.created_at) < (other.priority.value, other.created_at)

@dataclass
class ResourceUsage:
    """Использование ресурсов задачей"""
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    network_usage: float = 0.0
    io_usage: float = 0.0

class TaskScheduler:
    """Продвинутый планировщик задач"""
    
    def __init__(self):
        self.task_queue: List[Task] = []  # Приоритетная очередь
        self.running_tasks: Dict[str, Task] = {}
        self.completed_tasks: Dict[str, Task] = {}
        self.task_history: List[Task] = []
        
        # Очереди по типам
        self.parser_queue: List[Task] = []
        self.editor_queue: List[Task] = []
        self.publisher_queue: List[Task] = []
        self.ml_queue: List[Task] = []
        
        # Статистика
        self.stats = {
            'tasks_created': 0,
            'tasks_completed': 0,
            'tasks_failed': 0,
            'tasks_cancelled': 0,
            'average_execution_time': 0.0,
            'queue_size': 0
        }
        
        # Управление ресурсами
        self.max_concurrent_tasks = 10
        self.current_resource_usage = ResourceUsage()
        self.resource_limits = ResourceUsage(
            cpu_usage=80.0,
            memory_usage=85.0,
            network_usage=90.0,
            io_usage=75.0
        )
        
        # Семафор для управления concurrency
        self._semaphore = asyncio.Semaphore(self.max_concurrent_tasks)
        self._lock = asyncio.Lock()
        
        # Флаги
        self.is_running = False
        self._shutdown_event = asyncio.Event()
        
        logger.info("Task Scheduler инициализирован")
    
    async def start(self):
        """Запуск планировщика"""
        self.is_running = True
        logger.info("Task Scheduler запущен")
        
        # Запуск основных циклов
        asyncio.create_task(self._scheduling_loop())
        asyncio.create_task(self._monitoring_loop())
        asyncio.create_task(self._cleanup_loop())
        asyncio.create_task(self._resource_management_loop())
    
    async def stop(self):
        """Остановка планировщика"""
        logger.info("Остановка Task Scheduler...")
        self.is_running = False
        self._shutdown_event.set()
        
        # Отмена всех запущенных задач
        for task in self.running_tasks.values():
            await self.cancel_task(task.id)
        
        logger.info("Task Scheduler остановлен")
    
    async def schedule_task(
        self,
        name: str,
        func: Callable,
        *args,
        priority: TaskPriority = TaskPriority.NORMAL,
        delay: Optional[float] = None,
        max_retries: int = 3,
        timeout: int = 300,
        dependencies: List[str] = None,
        callback: Optional[Callable] = None,
        **kwargs
    ) -> str:
        """Планирование новой задачи"""
        
        task = Task(
            name=name,
            func=func,
            args=args,
            kwargs=kwargs,
            priority=priority,
            max_retries=max_retries,
            timeout=timeout,
            dependencies=dependencies or [],
            callback=callback
        )
        
        # Установка времени выполнения
        if delay:
            task.scheduled_at = datetime.now() + timedelta(seconds=delay)
        
        async with self._lock:
            # Проверка зависимостей
            if task.dependencies:
                pending_deps = [
                    dep for dep in task.dependencies 
                    if dep in self.running_tasks or dep in self.task_queue
                ]
                if pending_deps:
                    logger.info(f"Задача {task.id} ожидает зависимости: {pending_deps}")
                    # Поставить в очередь ожидания зависимостей
                    return task.id
            
            # Добавление в очередь
            heapq.heappush(self.task_queue, task)
            self.stats['tasks_created'] += 1
            
            # Распределение по специализированным очередям
            await self._distribute_to_specialized_queue(task)
            
            logger.info(f"Задача '{name}' запланирована с приоритетом {priority.name}")
            
        return task.id
    
    async def cancel_task(self, task_id: str) -> bool:
        """Отмена задачи"""
        async with self._lock:
            # Поиск в очереди
            for i, task in enumerate(self.task_queue):
                if task.id == task_id:
                    task.status = TaskStatus.CANCELLED
                    task.completed_at = datetime.now()
                    self.stats['tasks_cancelled'] += 1
                    del self.task_queue[i]
                    heapq.heapify(self.task_queue)
                    logger.info(f"Задача {task_id} отменена из очереди")
                    return True
            
            # Поиск в запущенных задачах
            if task_id in self.running_tasks:
                task = self.running_tasks[task_id]
                task.status = TaskStatus.CANCELLED
                task.completed_at = datetime.now()
                self.stats['tasks_cancelled'] += 1
                logger.info(f"Задача {task_id} отменена (было в процессе)")
                return True
            
            return False
    
    async def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Получение статуса задачи"""
        # Поиск в очереди
        for task in self.task_queue:
            if task.id == task_id:
                return self._task_to_dict(task)
        
        # Поиск в запущенных задачах
        if task_id in self.running_tasks:
            return self._task_to_dict(self.running_tasks[task_id])
        
        # Поиск в завершенных задачах
        if task_id in self.completed_tasks:
            return self._task_to_dict(self.completed_tasks[task_id])
        
        return None
    
    async def get_pending_tasks(self) -> List[Dict[str, Any]]:
        """Получение списка ожидающих задач"""
        return [self._task_to_dict(task) for task in self.task_queue]
    
    async def get_running_tasks(self) -> List[Dict[str, Any]]:
        """Получение списка выполняемых задач"""
        return [self._task_to_dict(task) for task in self.running_tasks.values()]
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса планировщика"""
        return {
            'is_running': self.is_running,
            'queue_size': len(self.task_queue),
            'running_tasks': len(self.running_tasks),
            'completed_tasks': len(self.completed_tasks),
            'stats': self.stats,
            'resource_usage': {
                'cpu': self.current_resource_usage.cpu_usage,
                'memory': self.current_resource_usage.memory_usage,
                'network': self.current_resource_usage.network_usage,
                'io': self.current_resource_usage.io_usage
            },
            'specialized_queues': {
                'parser': len(self.parser_queue),
                'editor': len(self.editor_queue),
                'publisher': len(self.publisher_queue),
                'ml': len(self.ml_queue)
            }
        }
    
    async def reduce_load(self):
        """Уменьшение нагрузки на систему"""
        logger.warning("Уменьшение нагрузки на планировщик...")
        
        async with self._lock:
            # Отмена задач с низким приоритетом
            cancelled_count = 0
            remaining_tasks = []
            
            for task in self.task_queue:
                if task.priority in [TaskPriority.LOW, TaskPriority.BACKGROUND]:
                    task.status = TaskStatus.CANCELLED
                    task.completed_at = datetime.now()
                    self.stats['tasks_cancelled'] += 1
                    cancelled_count += 1
                else:
                    remaining_tasks.append(task)
            
            self.task_queue = remaining_tasks
            heapq.heapify(self.task_queue)
            
            logger.info(f"Отменено {cancelled_count} задач с низким приоритетом")
    
    async def _scheduling_loop(self):
        """Основной цикл планирования"""
        while self.is_running and not self._shutdown_event.is_set():
            try:
                async with self._lock:
                    # Проверка доступности ресурсов
                    if not await self._can_execute_task():
                        await asyncio.sleep(1)
                        continue
                    
                    # Выбор следующей задачи для выполнения
                    task = await self._select_next_task()
                    if not task:
                        await asyncio.sleep(1)
                        continue
                    
                    # Проверка зависимостей
                    if not await self._check_dependencies(task):
                        await asyncio.sleep(1)
                        continue
                    
                    # Запуск задачи
                    asyncio.create_task(self._execute_task(task))
                
                await asyncio.sleep(0.1)  # Пауза для предотвращения CPU overload
                
            except Exception as e:
                logger.error(f"Ошибка в цикле планирования: {e}")
                await asyncio.sleep(1)
    
    async def _execute_task(self, task: Task):
        """Выполнение задачи"""
        async with self._semaphore:
            try:
                # Обновление статуса
                task.status = TaskStatus.RUNNING
                task.started_at = datetime.now()
                self.running_tasks[task.id] = task
                
                logger.info(f"Выполнение задачи: {task.name} (ID: {task.id})")
                
                # Выполнение с таймаутом
                if asyncio.iscoroutinefunction(task.func):
                    result = await asyncio.wait_for(
                        task.func(*task.args, **task.kwargs),
                        timeout=task.timeout
                    )
                else:
                    result = await asyncio.wait_for(
                        asyncio.get_event_loop().run_in_executor(
                            None, task.func, *task.args, **task.kwargs
                        ),
                        timeout=task.timeout
                    )
                
                # Успешное выполнение
                task.status = TaskStatus.COMPLETED
                task.completed_at = datetime.now()
                task.result = result
                self.stats['tasks_completed'] += 1
                
                logger.info(f"Задача выполнена: {task.name} (ID: {task.id})")
                
                # Callback
                if task.callback:
                    try:
                        if asyncio.iscoroutinefunction(task.callback):
                            await task.callback(task)
                        else:
                            await asyncio.get_event_loop().run_in_executor(
                                None, task.callback, task
                            )
                    except Exception as e:
                        logger.error(f"Ошибка в callback задачи {task.id}: {e}")
                
            except asyncio.TimeoutError:
                task.status = TaskStatus.FAILED
                task.error = f"Timeout after {task.timeout} seconds"
                self.stats['tasks_failed'] += 1
                logger.error(f"Задача превысила таймаут: {task.name} (ID: {task.id})")
                
                # Повторная попытка
                await self._retry_task(task)
                
            except Exception as e:
                task.status = TaskStatus.FAILED
                task.error = str(e)
                self.stats['tasks_failed'] += 1
                logger.error(f"Ошибка при выполнении задачи {task.name} (ID: {task.id}): {e}")
                
                # Повторная попытка
                await self._retry_task(task)
                
            finally:
                # Перемещение в завершенные задачи
                if task.id in self.running_tasks:
                    del self.running_tasks[task.id]
                    self.completed_tasks[task.id] = task
                    
                    # Ограничение истории
                    if len(self.completed_tasks) > 1000:
                        # Удаление самых старых задач
                        oldest_tasks = sorted(
                            self.completed_tasks.values(),
                            key=lambda t: t.completed_at
                        )[:100]
                        for old_task in oldest_tasks:
                            del self.completed_tasks[old_task.id]
    
    async def _retry_task(self, task: Task):
        """Повторная попытка выполнения задачи"""
        if task.retry_count < task.max_retries:
            task.retry_count += 1
            task.status = TaskStatus.PENDING
            task.error = None
            
            # Экспоненциальная задержка
            delay = min(2 ** task.retry_count, 300)  # максимум 5 минут
            task.scheduled_at = datetime.now() + timedelta(seconds=delay)
            
            logger.info(f"Повторная попытка задачи {task.name} (ID: {task.id}) через {delay} секунд")
            
            # Возврат в очередь с пониженным приоритетом
            task.priority = TaskPriority(min(task.priority.value + 1, 5))
            heapq.heappush(self.task_queue, task)
        else:
            logger.error(f"Задача {task.name} (ID: {task.id}) исчерпала все попытки")
    
    async def _select_next_task(self) -> Optional[Task]:
        """Выбор следующей задачи для выполнения"""
        if not self.task_queue:
            return None
        
        # Проверка времени выполнения
        current_time = datetime.now()
        
        for task in self.task_queue:
            if task.scheduled_at and task.scheduled_at > current_time:
                continue
            
            # Проверка зависимостей
            if await self._check_dependencies(task):
                # Удаление из очереди
                self.task_queue.remove(task)
                heapq.heapify(self.task_queue)
                return task
        
        return None
    
    async def _check_dependencies(self, task: Task) -> bool:
        """Проверка зависимостей задачи"""
        if not task.dependencies:
            return True
        
        for dep_id in task.dependencies:
            # Проверка, что зависимость выполнена
            if dep_id in self.running_tasks:
                return False
            if dep_id in self.task_queue:
                return False
            if dep_id not in self.completed_tasks:
                # Зависимость не найдена - считаем выполненной
                continue
            
            # Проверка, что зависимость выполнена успешно
            dep_task = self.completed_tasks[dep_id]
            if dep_task.status != TaskStatus.COMPLETED:
                return False
        
        return True
    
    async def _can_execute_task(self) -> bool:
        """Проверка возможности выполнения задачи"""
        # Проверка лимитов ресурсов
        if self.current_resource_usage.cpu_usage > self.resource_limits.cpu_usage:
            return False
        if self.current_resource_usage.memory_usage > self.resource_limits.memory_usage:
            return False
        if self.current_resource_usage.network_usage > self.resource_limits.network_usage:
            return False
        if self.current_resource_usage.io_usage > self.resource_limits.io_usage:
            return False
        
        # Проверка количества concurrent задач
        if len(self.running_tasks) >= self.max_concurrent_tasks:
            return False
        
        return True
    
    async def _distribute_to_specialized_queue(self, task: Task):
        """Распределение задачи в специализированную очередь"""
        task_name_lower = task.name.lower()
        
        if any(keyword in task_name_lower for keyword in ['parse', 'scrape', 'fetch']):
            heapq.heappush(self.parser_queue, task)
        elif any(keyword in task_name_lower for keyword in ['edit', 'process', 'optimize']):
            heapq.heappush(self.editor_queue, task)
        elif any(keyword in task_name_lower for keyword in ['publish', 'post', 'send']):
            heapq.heappush(self.publisher_queue, task)
        elif any(keyword in task_name_lower for keyword in ['ml', 'analyze', 'predict']):
            heapq.heappush(self.ml_queue, task)
    
    async def _monitoring_loop(self):
        """Цикл мониторинга"""
        while self.is_running and not self._shutdown_event.is_set():
            try:
                # Обновление статистики
                self.stats['queue_size'] = len(self.task_queue)
                
                # Мониторинг ресурсов (заглушка для реальной реализации)
                # self.current_resource_usage = await self._get_resource_usage()
                
                await asyncio.sleep(10)
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга: {e}")
                await asyncio.sleep(1)
    
    async def _cleanup_loop(self):
        """Цикл очистки"""
        while self.is_running and not self._shutdown_event.is_set():
            try:
                # Очистка старых завершенных задач
                current_time = datetime.now()
                cutoff_time = current_time - timedelta(hours=24)
                
                to_remove = [
                    task_id for task_id, task in self.completed_tasks.items()
                    if task.completed_at and task.completed_at < cutoff_time
                ]
                
                for task_id in to_remove:
                    del self.completed_tasks[task_id]
                
                if to_remove:
                    logger.info(f"Удалено {len(to_remove)} старых задач")
                
                await asyncio.sleep(3600)  # Каждый час
            except Exception as e:
                logger.error(f"Ошибка в цикле очистки: {e}")
                await asyncio.sleep(60)
    
    async def _resource_management_loop(self):
        """Цикл управления ресурсами"""
        while self.is_running and not self._shutdown_event.is_set():
            try:
                # Адаптивное управление concurrency
                if self.current_resource_usage.cpu_usage < 50:
                    self.max_concurrent_tasks = min(self.max_concurrent_tasks + 1, 20)
                elif self.current_resource_usage.cpu_usage > 80:
                    self.max_concurrent_tasks = max(self.max_concurrent_tasks - 1, 5)
                
                await asyncio.sleep(30)
            except Exception as e:
                logger.error(f"Ошибка в цикле управления ресурсами: {e}")
                await asyncio.sleep(5)
    
    def _task_to_dict(self, task: Task) -> Dict[str, Any]:
        """Преобразование задачи в словарь"""
        return {
            'id': task.id,
            'name': task.name,
            'priority': task.priority.name,
            'status': task.status.value,
            'created_at': task.created_at.isoformat(),
            'scheduled_at': task.scheduled_at.isoformat() if task.scheduled_at else None,
            'started_at': task.started_at.isoformat() if task.started_at else None,
            'completed_at': task.completed_at.isoformat() if task.completed_at else None,
            'max_retries': task.max_retries,
            'retry_count': task.retry_count,
            'timeout': task.timeout,
            'dependencies': task.dependencies,
            'error': task.error,
            'result': str(task.result) if task.result else None
        }