"""
Resource Manager Module
Управление ресурсами системы с динамическим распределением
"""

import asyncio
import psutil
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

@dataclass
class ResourceMetrics:
    """Метрики ресурсов"""
    timestamp: datetime
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_io: Dict[str, int]
    process_count: int
    thread_count: int
    open_files: int
    load_average: Optional[List[float]] = None

@dataclass
class ResourceLimits:
    """Лимиты ресурсов"""
    cpu_warning: float = 80.0
    cpu_critical: float = 95.0
    memory_warning: float = 85.0
    memory_critical: float = 95.0
    disk_warning: float = 90.0
    disk_critical: float = 95.0
    process_limit: int = 1000
    thread_limit: int = 10000
    open_files_limit: int = 10000

class ResourceManager:
    """Менеджер ресурсов системы"""
    
    def __init__(self):
        self.is_running = False
        self.metrics_history: List[ResourceMetrics] = []
        self.current_metrics: Optional[ResourceMetrics] = None
        
        # Лимиты ресурсов
        self.limits = ResourceLimits()
        
        # Статистика
        self.stats = {
            'peak_cpu_usage': 0.0,
            'peak_memory_usage': 0.0,
            'peak_disk_usage': 0.0,
            'resource_warnings': 0,
            'resource_critical': 0,
            'cleanup_operations': 0
        }
        
        # Кэш
        self._cache: Dict[str, Any] = {}
        self._cache_max_size = 1000
        self._cache_ttl = 3600  # секунды
        
        # Фоновые задачи
        self._monitoring_task: Optional[asyncio.Task] = None
        self._cleanup_task: Optional[asyncio.Task] = None
        
        logger.info("Resource Manager инициализирован")
    
    async def start(self):
        """Запуск менеджера ресурсов"""
        self.is_running = True
        logger.info("Resource Manager запущен")
        
        # Запуск фоновых задач
        self._monitoring_task = asyncio.create_task(self._monitoring_loop())
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())
        
        # Начальное измерение
        await self._collect_metrics()
    
    async def stop(self):
        """Остановка менеджера ресурсов"""
        logger.info("Остановка Resource Manager...")
        self.is_running = False
        
        # Остановка фоновых задач
        if self._monitoring_task:
            self._monitoring_task.cancel()
        if self._cleanup_task:
            self._cleanup_task.cancel()
        
        logger.info("Resource Manager остановлен")
    
    async def get_metrics(self) -> Dict[str, Any]:
        """Получение текущих метрик ресурсов"""
        if not self.current_metrics:
            await self._collect_metrics()
        
        return {
            'cpu_usage': self.current_metrics.cpu_usage,
            'memory_usage': self.current_metrics.memory_usage,
            'disk_usage': self.current_metrics.disk_usage,
            'network_io': self.current_metrics.network_io,
            'process_count': self.current_metrics.process_count,
            'thread_count': self.current_metrics.thread_count,
            'open_files': self.current_metrics.open_files,
            'load_average': self.current_metrics.load_average,
            'timestamp': self.current_metrics.timestamp.isoformat()
        }
    
    async def is_overloaded(self) -> bool:
        """Проверка перегрузки системы"""
        if not self.current_metrics:
            await self._collect_metrics()
        
        return (
            self.current_metrics.cpu_usage > self.limits.cpu_critical or
            self.current_metrics.memory_usage > self.limits.memory_critical or
            self.current_metrics.disk_usage > self.limits.disk_critical
        )
    
    async def get_resource_availability(self) -> Dict[str, Any]:
        """Получение доступности ресурсов"""
        metrics = await self.get_metrics()
        
        return {
            'cpu_available': 100 - metrics['cpu_usage'],
            'memory_available': 100 - metrics['memory_usage'],
            'disk_available': 100 - metrics['disk_usage'],
            'can_start_tasks': not await self.is_overloaded(),
            'should_reduce_load': (
                metrics['cpu_usage'] > self.limits.cpu_warning or
                metrics['memory_usage'] > self.limits.memory_warning
            )
        }
    
    async def optimize_resources(self):
        """Оптимизация использования ресурсов"""
        logger.info("Оптимизация ресурсов...")
        
        # Очистка кэша
        await self.clear_cache()
        
        # Очистка старых метрик
        await self._cleanup_old_metrics()
        
        # Сборка мусора
        await self._run_garbage_collection()
        
        # Закрытие неиспользуемых файлов
        await self._close_unused_files()
        
        self.stats['cleanup_operations'] += 1
        logger.info("Оптимизация ресурсов завершена")
    
    async def clear_cache(self):
        """Очистка кэша"""
        current_time = time.time()
        
        # Удаление устаревших записей
        expired_keys = [
            key for key, (value, timestamp) in self._cache.items()
            if current_time - timestamp > self._cache_ttl
        ]
        
        for key in expired_keys:
            del self._cache[key]
        
        # Удаление старых записей при превышении размера
        if len(self._cache) > self._cache_max_size:
            # Удаление 20% самых старых записей
            items = list(self._cache.items())
            items.sort(key=lambda x: x[1][1])  # Сортировка по времени
            
            remove_count = int(len(items) * 0.2)
            for key, _ in items[:remove_count]:
                del self._cache[key]
        
        logger.info(f"Кэш очищен. Удалено {len(expired_keys)} устаревших записей")
    
    async def set_cache_value(self, key: str, value: Any, ttl: Optional[int] = None):
        """Установка значения в кэш"""
        if ttl is None:
            ttl = self._cache_ttl
        
        self._cache[key] = (value, time.time() + ttl)
    
    async def get_cache_value(self, key: str) -> Optional[Any]:
        """Получение значения из кэша"""
        if key in self._cache:
            value, expiry_time = self._cache[key]
            if time.time() < expiry_time:
                return value
            else:
                del self._cache[key]
        
        return None
    
    async def get_statistics(self) -> Dict[str, Any]:
        """Получение статистики ресурсов"""
        if not self.metrics_history:
            return self.stats
        
        # Анализ истории метрик
        cpu_values = [m.cpu_usage for m in self.metrics_history]
        memory_values = [m.memory_usage for m in self.metrics_history]
        disk_values = [m.disk_usage for m in self.metrics_history]
        
        return {
            **self.stats,
            'current_metrics': await self.get_metrics(),
            'avg_cpu_usage': sum(cpu_values) / len(cpu_values),
            'avg_memory_usage': sum(memory_values) / len(memory_values),
            'avg_disk_usage': sum(disk_values) / len(disk_values),
            'cache_size': len(self._cache),
            'cache_hit_rate': await self._calculate_cache_hit_rate()
        }
    
    async def _collect_metrics(self):
        """Сбор метрик системы"""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)
            
            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            
            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = (disk.used / disk.total) * 100
            
            # Network I/O
            net_io = psutil.net_io_counters()
            network_io = {
                'bytes_sent': net_io.bytes_sent,
                'bytes_recv': net_io.bytes_recv,
                'packets_sent': net_io.packets_sent,
                'packets_recv': net_io.packets_recv
            }
            
            # Процессы и потоки
            current_process = psutil.Process()
            process_count = len(psutil.pids())
            thread_count = current_process.num_threads()
            open_files = len(current_process.open_files())
            
            # Load average (для Unix систем)
            load_average = None
            if hasattr(psutil, 'getloadavg'):
                load_average = list(psutil.getloadavg())
            
            # Создание объекта метрик
            metrics = ResourceMetrics(
                timestamp=datetime.now(),
                cpu_usage=cpu_percent,
                memory_usage=memory_percent,
                disk_usage=disk_percent,
                network_io=network_io,
                process_count=process_count,
                thread_count=thread_count,
                open_files=open_files,
                load_average=load_average
            )
            
            # Обновление текущих метрик
            self.current_metrics = metrics
            
            # Добавление в историю
            self.metrics_history.append(metrics)
            
            # Обновление пиковых значений
            self.stats['peak_cpu_usage'] = max(self.stats['peak_cpu_usage'], cpu_percent)
            self.stats['peak_memory_usage'] = max(self.stats['peak_memory_usage'], memory_percent)
            self.stats['peak_disk_usage'] = max(self.stats['peak_disk_usage'], disk_percent)
            
            # Проверка порогов
            if cpu_percent > self.limits.cpu_warning or memory_percent > self.limits.memory_warning:
                self.stats['resource_warnings'] += 1
                logger.warning(f"Предупреждение о ресурсах: CPU={cpu_percent}%, Memory={memory_percent}%")
            
            if cpu_percent > self.limits.cpu_critical or memory_percent > self.limits.memory_critical:
                self.stats['resource_critical'] += 1
                logger.critical(f"Критический уровень ресурсов: CPU={cpu_percent}%, Memory={memory_percent}%")
            
        except Exception as e:
            logger.error(f"Ошибка при сборе метрик: {e}")
    
    async def _monitoring_loop(self):
        """Цикл мониторинга ресурсов"""
        while self.is_running:
            try:
                await self._collect_metrics()
                await asyncio.sleep(10)  # Сбор метрик каждые 10 секунд
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга: {e}")
                await asyncio.sleep(5)
    
    async def _cleanup_loop(self):
        """Цикл очистки ресурсов"""
        while self.is_running:
            try:
                # Очистка каждый час
                await asyncio.sleep(3600)
                await self.optimize_resources()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле очистки: {e}")
                await asyncio.sleep(60)
    
    async def _cleanup_old_metrics(self):
        """Очистка старых метрик"""
        cutoff_time = datetime.now() - timedelta(days=7)
        
        self.metrics_history = [
            metrics for metrics in self.metrics_history
            if metrics.timestamp > cutoff_time
        ]
        
        logger.info(f"Очистка метрик. Осталось {len(self.metrics_history)} записей")
    
    async def _run_garbage_collection(self):
        """Запуск сборки мусора"""
        try:
            import gc
            before = len(gc.get_objects())
            gc.collect()
            after = len(gc.get_objects())
            
            logger.info(f"Сборка мусора: {before - after} объектов удалено")
        except Exception as e:
            logger.error(f"Ошибка при сборке мусора: {e}")
    
    async def _close_unused_files(self):
        """Закрытие неиспользуемых файлов"""
        try:
            current_process = psutil.Process()
            open_files = current_process.open_files()
            
            # Закрытие файлов, которые не используются дольше 1 часа
            # Это требует дополнительной логики для отслеживания времени использования
            
            logger.info(f"Открыто файлов: {len(open_files)}")
        except Exception as e:
            logger.error(f"Ошибка при закрытии файлов: {e}")
    
    async def _calculate_cache_hit_rate(self) -> float:
        """Расчет процента попаданий в кэш"""
        # Это упрощенная реализация
        # В реальном приложении нужно отслеживать hits/misses
        if not self._cache:
            return 0.0
        
        # Предположим, что чем больше кэш, тем выше hit rate
        return min(len(self._cache) / self._cache_max_size, 1.0)

# Глобальный экземпляр
resource_manager = ResourceManager()