"""
Proxy Manager Module
Управление прокси серверами с ротацией и проверкой работоспособности
"""

import asyncio
import aiohttp
import random
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
import json

logger = logging.getLogger(__name__)

@dataclass
class ProxyServer:
    """Прокси сервер"""
    id: str
    host: str
    port: int
    username: Optional[str] = None
    password: Optional[str] = None
    protocol: str = 'http'  # http, https, socks4, socks5
    country: Optional[str] = None
    region: Optional[str] = None
    city: Optional[str] = None
    speed: Optional[float] = None  # мс
    reliability: float = 1.0  # 0-1
    last_checked: Optional[datetime] = None
    consecutive_failures: int = 0
    max_failures: int = 3
    is_active: bool = True
    tags: List[str] = None

@dataclass
class ProxyStats:
    """Статистика прокси"""
    total_proxies: int = 0
    active_proxies: int = 0
    failed_proxies: int = 0
    avg_response_time: float = 0.0
    success_rate: float = 0.0
    last_update: Optional[datetime] = None

class ProxyManager:
    """Менеджер прокси серверов"""
    
    def __init__(self):
        self.proxies: List[ProxyServer] = []
        self.proxy_pool: List[ProxyServer] = []
        self.current_proxy_index = 0
        
        # Настройки
        self.check_interval = 300  # 5 минут
        self.timeout = 10  # секунд
        self.max_concurrent_checks = 10
        
        # Статистика
        self.stats = ProxyStats()
        self.usage_stats: Dict[str, Dict[str, Any]] = {}
        
        # Кэш
        self._proxy_cache: Dict[str, ProxyServer] = {}
        self._cache_ttl = 3600  # 1 час
        
        # Фоновые задачи
        self._monitoring_task: Optional[asyncio.Task] = None
        self._validation_task: Optional[asyncio.Task] = None
        
        logger.info("Proxy Manager инициализирован")
    
    async def initialize(self):
        """Инициализация менеджера прокси"""
        # Загрузка прокси из различных источников
        await self._load_proxies_from_sources()
        
        # Инициализация пула активных прокси
        await self._update_proxy_pool()
        
        # Запуск фоновых задач
        self._monitoring_task = asyncio.create_task(self._monitoring_loop())
        self._validation_task = asyncio.create_task(self._validation_loop())
        
        logger.info(f"Proxy Manager инициализирован с {len(self.proxies)} прокси")
    
    async def cleanup(self):
        """Очистка ресурсов"""
        if self._monitoring_task:
            self._monitoring_task.cancel()
        if self._validation_task:
            self._validation_task.cancel()
        
        logger.info("Proxy Manager очищен")
    
    async def get_proxy(self, requirements: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """Получение прокси сервера по требованиям"""
        if not self.proxy_pool:
            logger.warning("Нет доступных прокси")
            return None
        
        # Фильтрация по требованиям
        suitable_proxies = await self._filter_proxies(requirements)
        
        if not suitable_proxies:
            logger.warning("Нет прокси, соответствующих требованиям")
            suitable_proxies = self.proxy_pool
        
        # Выбор прокси с учетом весов (надежность и скорость)
        proxy = await self._select_weighted_proxy(suitable_proxies)
        
        if proxy:
            # Формирование URL прокси
            proxy_url = self._format_proxy_url(proxy)
            
            # Обновление статистики использования
            await self._update_usage_stats(proxy.id, 'used')
            
            logger.debug(f"Выбран прокси: {proxy.host}:{proxy.port}")
            return proxy_url
        
        return None
    
    async def get_multiple_proxies(self, count: int, requirements: Optional[Dict[str, Any]] = None) -> List[str]:
        """Получение нескольких прокси серверов"""
        proxies = []
        attempts = 0
        max_attempts = count * 3
        
        while len(proxies) < count and attempts < max_attempts:
            proxy = await self.get_proxy(requirements)
            if proxy and proxy not in proxies:
                proxies.append(proxy)
            attempts += 1
        
        return proxies
    
    async def report_failure(self, proxy_url: str):
        """Сообщение о неудачном использовании прокси"""
        proxy_id = self._extract_proxy_id(proxy_url)
        if proxy_id in self.usage_stats:
            self.usage_stats[proxy_id]['failures'] += 1
            
            # Поиск прокси в списке
            for proxy in self.proxies:
                if proxy.id == proxy_id:
                    proxy.consecutive_failures += 1
                    proxy.reliability = max(0.0, proxy.reliability - 0.1)
                    
                    # Деактивация при превышении лимита ошибок
                    if proxy.consecutive_failures >= proxy.max_failures:
                        proxy.is_active = False
                        logger.warning(f"Прокси деактивирован: {proxy.host}:{proxy.port}")
                    
                    break
        
        # Обновление пула прокси
        await self._update_proxy_pool()
    
    async def report_success(self, proxy_url: str, response_time: float):
        """Сообщение об успешном использовании прокси"""
        proxy_id = self._extract_proxy_id(proxy_url)
        if proxy_id in self.usage_stats:
            self.usage_stats[proxy_id]['successes'] += 1
            self.usage_stats[proxy_id]['avg_response_time'] = (
                (self.usage_stats[proxy_id]['avg_response_time'] * 
                 (self.usage_stats[proxy_id]['successes'] - 1) + response_time) /
                self.usage_stats[proxy_id]['successes']
            )
            
            # Поиск прокси в списке
            for proxy in self.proxies:
                if proxy.id == proxy_id:
                    proxy.consecutive_failures = 0
                    proxy.speed = response_time
                    proxy.reliability = min(1.0, proxy.reliability + 0.05)
                    proxy.last_checked = datetime.now()
                    break
    
    async def validate_proxies(self):
        """Валидация работоспособности прокси"""
        logger.info("Начало валидации прокси...")
        
        # Фильтрация активных прокси
        active_proxies = [p for p in self.proxies if p.is_active]
        
        # Проверка в параллель
        semaphore = asyncio.Semaphore(self.max_concurrent_checks)
        
        async def check_proxy(proxy: ProxyServer):
            async with semaphore:
                return await self._check_proxy_health(proxy)
        
        # Выполнение проверок
        tasks = [check_proxy(proxy) for proxy in active_proxies]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Обработка результатов
        valid_count = 0
        for proxy, result in zip(active_proxies, results):
            if isinstance(result, Exception):
                logger.error(f"Ошибка проверки прокси {proxy.host}:{proxy.port}: {result}")
                proxy.is_active = False
            elif result:
                proxy.is_active = True
                proxy.last_checked = datetime.now()
                valid_count += 1
            else:
                proxy.is_active = False
                proxy.consecutive_failures += 1
        
        # Обновление пула
        await self._update_proxy_pool()
        
        # Обновление статистики
        self._update_stats()
        
        logger.info(f"Валидация завершена. Активных прокси: {valid_count}/{len(active_proxies)}")
    
    async def get_status(self) -> Dict[str, Any]:
        """Получение статуса менеджера прокси"""
        return {
            'total_proxies': len(self.proxies),
            'active_proxies': len(self.proxy_pool),
            'stats': {
                'total_proxies': self.stats.total_proxies,
                'active_proxies': self.stats.active_proxies,
                'failed_proxies': self.stats.failed_proxies,
                'avg_response_time': self.stats.avg_response_time,
                'success_rate': self.stats.success_rate
            },
            'usage_stats': dict(list(self.usage_stats.items())[:10])  # Первые 10 для примера
        }
    
    async def _load_proxies_from_sources(self):
        """Загрузка прокси из различных источников"""
        # 1. Бесплатные прокси списки
        await self._load_free_proxies()
        
        # 2. Платные прокси сервисы (если есть API ключи)
        await self._load_premium_proxies()
        
        # 3. Локальные прокси из конфигурации
        await self._load_configured_proxies()
        
        # 4. Динамическое обнаружение прокси
        await self._discover_proxies()
    
    async def _load_free_proxies(self):
        """Загрузка бесплатных прокси"""
        # Список известных бесплатных прокси
        free_proxy_sources = [
            # Это примеры - в реальном приложении нужно использовать API
            {'host': '103.151.246.85', 'port': 8080, 'country': 'ID'},
            {'host': '182.52.83.30', 'port': 8080, 'country': 'TH'},
            {'host': '103.250.153.22', 'port': 8080, 'country': 'ID'},
            {'host': '103.78.36.133', 'port': 8080, 'country': 'BD'},
            {'host': '103.148.178.228', 'port': 8080, 'country': 'ID'},
        ]
        
        for proxy_data in free_proxy_sources:
            proxy = ProxyServer(
                id=f"free_{proxy_data['host']}_{proxy_data['port']}",
                host=proxy_data['host'],
                port=proxy_data['port'],
                country=proxy_data.get('country'),
                protocol='http',
                tags=['free', 'public']
            )
            self.proxies.append(proxy)
    
    async def _load_premium_proxies(self):
        """Загрузка премиум прокси (если есть API ключи)"""
        # В реальном приложении - интеграция с платными сервисами
        # Например: Luminati, Oxylabs, Smartproxy и т.д.
        pass
    
    async def _load_configured_proxies(self):
        """Загрузка прокси из конфигурации"""
        # Загрузка из config.py или .env файла
        from config import config
        
        # Если в конфигурации есть список прокси
        if hasattr(config, 'PROXY_LIST') and config.PROXY_LIST:
            for proxy_data in config.PROXY_LIST:
                proxy = ProxyServer(**proxy_data)
                self.proxies.append(proxy)
    
    async def _discover_proxies(self):
        """Динамическое обнаружение прокси"""
        # В реальном приложении - парсинг веб-сайтов с прокси списками
        # Или использование API сервисов
        pass
    
    async def _filter_proxies(self, requirements: Optional[Dict[str, Any]] = None) -> List[ProxyServer]:
        """Фильтрация прокси по требованиям"""
        if not requirements:
            return self.proxy_pool
        
        filtered = []
        for proxy in self.proxy_pool:
            # Фильтрация по стране
            if requirements.get('country') and proxy.country != requirements['country']:
                continue
            
            # Фильтрация по скорости
            if requirements.get('max_response_time') and proxy.speed and proxy.speed > requirements['max_response_time']:
                continue
            
            # Фильтрация по надежности
            if requirements.get('min_reliability') and proxy.reliability < requirements['min_reliability']:
                continue
            
            # Фильтрация по протоколу
            if requirements.get('protocol') and proxy.protocol != requirements['protocol']:
                continue
            
            filtered.append(proxy)
        
        return filtered
    
    async def _select_weighted_proxy(self, proxies: List[ProxyServer]) -> Optional[ProxyServer]:
        """Выбор прокси с учетом весов (надежность и скорость)"""
        if not proxies:
            return None
        
        # Расчет весов на основе надежности и скорости
        weights = []
        for proxy in proxies:
            # Вес = надежность * коэффициент скорости
            speed_factor = 1.0 if not proxy.speed else min(1.0, 1000 / max(proxy.speed, 1))
            weight = proxy.reliability * speed_factor
            weights.append(weight)
        
        # Выбор с учетом весов
        return random.choices(proxies, weights=weights, k=1)[0]
    
    def _format_proxy_url(self, proxy: ProxyServer) -> str:
        """Форматирование URL прокси"""
        if proxy.username and proxy.password:
            return f"{proxy.protocol}://{proxy.username}:{proxy.password}@{proxy.host}:{proxy.port}"
        else:
            return f"{proxy.protocol}://{proxy.host}:{proxy.port}"
    
    def _extract_proxy_id(self, proxy_url: str) -> str:
        """Извлечение ID прокси из URL"""
        # Простая реализация - в реальном приложении нужен парсинг URL
        return proxy_url.replace('://', '_').replace('@', '_').replace(':', '_')
    
    async def _check_proxy_health(self, proxy: ProxyServer) -> bool:
        """Проверка работоспособности прокси"""
        try:
            start_time = time.time()
            
            # Проверка через простой HTTP запрос
            proxy_url = self._format_proxy_url(proxy)
            
            timeout = aiohttp.ClientTimeout(total=self.timeout)
            connector = aiohttp.TCPConnector(limit=1)
            
            async with aiohttp.ClientSession(
                connector=connector,
                timeout=timeout
            ) as session:
                # Проверка на httpbin.org или аналогичном сервисе
                async with session.get(
                    'http://httpbin.org/ip',
                    proxy=proxy_url
                ) as response:
                    if response.status == 200:
                        response_time = (time.time() - start_time) * 1000  # в миллисекундах
                        proxy.speed = response_time
                        return True
                    else:
                        return False
                        
        except Exception as e:
            logger.debug(f"Прокси {proxy.host}:{proxy.port} не работает: {e}")
            return False
    
    async def _update_proxy_pool(self):
        """Обновление пула активных прокси"""
        # Фильтрация активных и работающих прокси
        active_proxies = [
            proxy for proxy in self.proxies
            if proxy.is_active and proxy.consecutive_failures < proxy.max_failures
        ]
        
        self.proxy_pool = active_proxies
        
        # Инициализация статистики использования
        for proxy in active_proxies:
            if proxy.id not in self.usage_stats:
                self.usage_stats[proxy.id] = {
                    'used': 0,
                    'successes': 0,
                    'failures': 0,
                    'avg_response_time': 0.0
                }
    
    async def _update_usage_stats(self, proxy_id: str, stat_type: str):
        """Обновление статистики использования"""
        if proxy_id not in self.usage_stats:
            self.usage_stats[proxy_id] = {
                'used': 0,
                'successes': 0,
                'failures': 0,
                'avg_response_time': 0.0
            }
        
        if stat_type == 'used':
            self.usage_stats[proxy_id]['used'] += 1
        elif stat_type == 'success':
            self.usage_stats[proxy_id]['successes'] += 1
        elif stat_type == 'failure':
            self.usage_stats[proxy_id]['failures'] += 1
    
    def _update_stats(self):
        """Обновление общей статистики"""
        active_proxies = [p for p in self.proxies if p.is_active]
        failed_proxies = [p for p in self.proxies if not p.is_active]
        
        self.stats.total_proxies = len(self.proxies)
        self.stats.active_proxies = len(active_proxies)
        self.stats.failed_proxies = len(failed_proxies)
        self.stats.last_update = datetime.now()
        
        # Расчет среднего времени отклика
        response_times = [p.speed for p in active_proxies if p.speed]
        self.stats.avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        # Расчет процента успешных операций
        total_operations = sum(
            stats['successes'] + stats['failures']
            for stats in self.usage_stats.values()
        )
        successful_operations = sum(
            stats['successes']
            for stats in self.usage_stats.values()
        )
        
        if total_operations > 0:
            self.stats.success_rate = successful_operations / total_operations
    
    async def _monitoring_loop(self):
        """Цикл мониторинга прокси"""
        while True:
            try:
                await asyncio.sleep(self.check_interval)
                await self.validate_proxies()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга прокси: {e}")
                await asyncio.sleep(60)
    
    async def _validation_loop(self):
        """Цикл валидации прокси"""
        while True:
            try:
                # Полная валидация каждые 30 минут
                await asyncio.sleep(1800)
                await self.validate_proxies()
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Ошибка в цикле валидации прокси: {e}")
                await asyncio.sleep(300)

# Глобальный экземпляр
proxy_manager = ProxyManager()