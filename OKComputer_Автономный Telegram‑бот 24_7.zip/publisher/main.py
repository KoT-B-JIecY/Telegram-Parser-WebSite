"""
Publisher Service Main Module
Главный модуль сервиса публикации в Telegram
"""

import asyncio
import signal
import sys
from typing import Dict, List, Any, Optional
import logging
from pathlib import Path
from datetime import datetime, timedelta

from config import config
from telegram_bot import TelegramBot
from scheduler import PublishingScheduler
from media_optimizer import MediaOptimizer
from cross_poster import CrossPoster

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOGS_DIR / 'publisher.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class PublisherService:
    """Сервис публикации в Telegram"""
    
    def __init__(self):
        self.is_running = False
        self.telegram_bot = TelegramBot()
        self.scheduler = PublishingScheduler()
        self.media_optimizer = MediaOptimizer()
        self.cross_poster = CrossPoster()
        
        # Очереди
        self.publishing_queue: List[Dict[str, Any]] = []
        self.published_queue: List[Dict[str, Any]] = []
        self.failed_queue: List[Dict[str, Any]] = []
        
        # Статистика
        self.stats = {
            'posts_published': 0,
            'posts_failed': 0,
            'total_reach': 0,
            'avg_engagement': 0.0,
            'channels_managed': 0,
            'publishing_time_avg': 0.0
        }
        
        # Настройки
        self.max_queue_size = 1000
        self.batch_size = 5
        self.retry_attempts = 3
        self.retry_delay = 300  # 5 минут
        
        # Флаги управления
        self._shutdown_event = asyncio.Event()
        
        logger.info("Publisher Service инициализирован")
    
    async def start(self):
        """Запуск сервиса публикации"""
        try:
            logger.info("Запуск Publisher Service...")
            
            # Инициализация компонентов
            await self.telegram_bot.initialize()
            await self.scheduler.initialize()
            await self.media_optimizer.initialize()
            await self.cross_poster.initialize()
            
            # Обновление статуса
            self.is_running = True
            
            # Запуск рабочих циклов
            asyncio.create_task(self._publishing_loop())
            asyncio.create_task(self._monitoring_loop())
            asyncio.create_task(self._analytics_loop())
            
            logger.info("Publisher Service успешно запущен")
            
            # Ожидание завершения
            await self._shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"Ошибка при запуске Publisher Service: {e}")
            raise
    
    async def stop(self):
        """Остановка сервиса публикации"""
        logger.info("Остановка Publisher Service...")
        self.is_running = False
        self._shutdown_event.set()
        
        # Очистка ресурсов
        await self.telegram_bot.cleanup()
        await self.scheduler.cleanup()
        
        logger.info("Publisher Service остановлен")
    
    async def schedule_post(self, post_data: Dict[str, Any]) -> str:
        """Добавление поста в очередь публикации"""
        if len(self.publishing_queue) >= self.max_queue_size:
            raise Exception("Очередь публикации переполнена")
        
        task_id = post_data.get('id', f"publish_task_{len(self.publishing_queue)}")
        task = {
            'id': task_id,
            'content': post_data,
            'status': 'pending',
            'created_at': datetime.now(),
            'scheduled_time': post_data.get('scheduled_time'),
            'channels': post_data.get('channels', []),
            'retry_count': 0
        }
        
        self.publishing_queue.append(task)
        logger.info(f"Добавлен пост в очередь публикации: {task_id}")
        
        return task_id
    
    async def get_publishing_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Получение статуса публикации"""
        # Поиск в очереди на публикацию
        for task in self.publishing_queue:
            if task['id'] == task_id:
                return {
                    'id': task_id,
                    'status': task['status'],
                    'scheduled_time': task.get('scheduled_time'),
                    'channels': task.get('channels', []),
                    'queue_position': self.publishing_queue.index(task)
                }
        
        # Поиск в опубликованных
        for task in self.published_queue:
            if task['id'] == task_id:
                return {
                    'id': task_id,
                    'status': 'published',
                    'published_at': task.get('published_at'),
                    'channels': task.get('channels', []),
                    'message_ids': task.get('message_ids', {}),
                    'engagement_stats': task.get('engagement_stats', {})
                }
        
        # Поиск в неудачных
        for task in self.failed_queue:
            if task['id'] == task_id:
                return {
                    'id': task_id,
                    'status': 'failed',
                    'failed_at': task.get('failed_at'),
                    'error': task.get('error'),
                    'retry_count': task.get('retry_count', 0)
                }
        
        return None
    
    async def get_service_status(self) -> Dict[str, Any]:
        """Получение статуса сервиса"""
        return {
            'is_running': self.is_running,
            'queue_size': len(self.publishing_queue),
            'published_count': len(self.published_queue),
            'failed_count': len(self.failed_queue),
            'stats': self.stats,
            'bot_status': await self.telegram_bot.get_status(),
            'scheduler_status': await self.scheduler.get_status()
        }
    
    async def _publishing_loop(self):
        """Основной цикл публикации"""
        while self.is_running:
            try:
                current_time = datetime.now()
                
                # Поиск постов готовых к публикации
                ready_posts = [
                    task for task in self.publishing_queue
                    if (not task.get('scheduled_time') or task['scheduled_time'] <= current_time)
                    and task['status'] == 'pending'
                ]
                
                if ready_posts:
                    # Ограничение количества одновременных публикаций
                    batch = ready_posts[:self.batch_size]
                    
                    # Публикация батча
                    await self._publish_batch(batch)
                
                await asyncio.sleep(10)  # Пауза для предотвращения CPU overload
                
            except Exception as e:
                logger.error(f"Ошибка в цикле публикации: {e}")
                await asyncio.sleep(30)
    
    async def _publish_batch(self, batch: List[Dict[str, Any]]):
        """Публикация батча постов"""
        logger.info(f"Публикация батча из {len(batch)} постов")
        
        for task in batch:
            try:
                task['status'] = 'publishing'
                
                # Оптимизация медиа
                if task['content'].get('images') or task['content'].get('videos'):
                    task['content'] = await self.media_optimizer.optimize_for_telegram(
                        task['content']
                    )
                
                # Публикация в Telegram
                message_ids = await self.telegram_bot.publish_post(task['content'])
                
                # Кросс-постинг в другие каналы если необходимо
                if task.get('channels'):
                    await self.cross_poster.cross_post(
                        task['content'],
                        task['channels'],
                        message_ids
                    )
                
                # Успешная публикация
                task['status'] = 'published'
                task['published_at'] = datetime.now()
                task['message_ids'] = message_ids
                
                # Перемещение в очередь опубликованных
                self.published_queue.append(task)
                self.publishing_queue.remove(task)
                
                # Обновление статистики
                self.stats['posts_published'] += 1
                self.stats['channels_managed'] = max(
                    self.stats['channels_managed'],
                    len(task.get('channels', [])) + 1
                )
                
                logger.info(f"Успешно опубликован пост: {task['id']}")
                
            except Exception as e:
                logger.error(f"Ошибка при публикации поста {task['id']}: {e}")
                await self._handle_publishing_error(task, str(e))
    
    async def _handle_publishing_error(self, task: Dict[str, Any], error: str):
        """Обработка ошибки публикации"""
        task['retry_count'] += 1
        task['last_error'] = error
        
        if task['retry_count'] < self.retry_attempts:
            # Повторная попытка через задержку
            task['status'] = 'pending'
            task['scheduled_time'] = datetime.now() + timedelta(seconds=self.retry_delay)
            logger.info(f"Повторная попытка публикации {task['id']} через {self.retry_delay} секунд")
        else:
            # Исчерпаны все попытки
            task['status'] = 'failed'
            task['failed_at'] = datetime.now()
            
            # Перемещение в очередь неудачных
            self.failed_queue.append(task)
            self.publishing_queue.remove(task)
            
            # Обновление статистики
            self.stats['posts_failed'] += 1
            
            logger.error(f"Пост {task['id']} не удалось опубликовать после {self.retry_attempts} попыток")
    
    async def _monitoring_loop(self):
        """Цикл мониторинга публикаций"""
        while self.is_running:
            try:
                # Мониторинг каждые 5 минут
                await asyncio.sleep(300)
                
                # Обновление статистики вовлеченности
                await self._update_engagement_stats()
                
                # Очистка старых записей
                await self._cleanup_old_records()
                
                # Логирование статистики
                logger.info(f"Publisher Service Stats: {self.stats}")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга: {e}")
    
    async def _analytics_loop(self):
        """Цикл аналитики"""
        while self.is_running:
            try:
                # Аналитика каждый час
                await asyncio.sleep(3600)
                
                # Анализ эффективности публикаций
                await self._analyze_publishing_effectiveness()
                
                # Обновление рекомендаций по времени публикации
                await self.scheduler.update_publishing_recommendations()
                
            except Exception as e:
                logger.error(f"Ошибка в цикле аналитики: {e}")
    
    async def _update_engagement_stats(self):
        """Обновление статистики вовлеченности"""
        # Получение статистики от Telegram
        recent_posts = self.published_queue[-50:]  # Последние 50 постов
        
        total_views = 0
        total_reactions = 0
        
        for post in recent_posts:
            if 'message_ids' in post:
                for channel_id, message_id in post['message_ids'].items():
                    try:
                        stats = await self.telegram_bot.get_message_stats(
                            channel_id, message_id
                        )
                        total_views += stats.get('views', 0)
                        total_reactions += stats.get('reactions', 0)
                    except:
                        pass
        
        if len(recent_posts) > 0:
            self.stats['total_reach'] = total_views
            self.stats['avg_engagement'] = total_reactions / len(recent_posts)
    
    async def _cleanup_old_records(self):
        """Очистка старых записей"""
        cutoff_date = datetime.now() - timedelta(days=30)
        
        # Очистка опубликованных постов
        self.published_queue = [
            post for post in self.published_queue
            if post.get('published_at', datetime.now()) > cutoff_date
        ]
        
        # Очистка неудачных попыток
        self.failed_queue = [
            post for post in self.failed_queue
            if post.get('failed_at', datetime.now()) > cutoff_date
        ]
    
    async def _analyze_publishing_effectiveness(self):
        """Анализ эффективности публикаций"""
        # Анализ времени публикаций с наибольшей вовлеченностью
        engagement_by_hour = {}
        
        for post in self.published_queue[-100:]:  # Последние 100 постов
            if 'published_at' in post:
                hour = post['published_at'].hour
                engagement = post.get('engagement_stats', {}).get('total_reactions', 0)
                
                if hour not in engagement_by_hour:
                    engagement_by_hour[hour] = []
                engagement_by_hour[hour].append(engagement)
        
        # Вычисление средней вовлеченности по часам
        best_hours = []
        for hour, engagements in engagement_by_hour.items():
            avg_engagement = sum(engagements) / len(engagements)
            best_hours.append((hour, avg_engagement))
        
        # Сортировка по эффективности
        best_hours.sort(key=lambda x: x[1], reverse=True)
        
        # Обновление рекомендаций для планировщика
        optimal_hours = [hour for hour, _ in best_hours[:5]]
        await self.scheduler.update_optimal_hours(optimal_hours)
        
        logger.info(f"Обновлены оптимальные часы публикации: {optimal_hours}")

# Обработка сигналов
def signal_handler(signum, frame):
    """Обработчик системных сигналов"""
    logger.info(f"Получен сигнал {signum}")
    
    if signum == signal.SIGTERM:
        asyncio.create_task(publisher_service.stop())
    elif signum == signal.SIGINT:
        asyncio.create_task(publisher_service.stop())

# Глобальный экземпляр
publisher_service = PublisherService()

async def main():
    """Главная функция"""
    # Установка обработчиков сигналов
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        await publisher_service.start()
    except KeyboardInterrupt:
        logger.info("Получено прерывание от пользователя")
        await publisher_service.stop()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        await publisher_service.stop()

if __name__ == "__main__":
    asyncio.run(main())