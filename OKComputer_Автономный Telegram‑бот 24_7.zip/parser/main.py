"""
Parser Service Main Module
Главный модуль сервиса парсинга
"""

import asyncio
import signal
import sys
from typing import Dict, List, Any, Optional
import logging
from pathlib import Path

from config import config
from universal_parser import UniversalParser
from content_extractor import ContentExtractor
from anti_bot import AntiBotManager
from proxy_manager import ProxyManager

# Настройка логирования
logging.basicConfig(
    level=getattr(logging, config.LOG_LEVEL),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(config.LOGS_DIR / 'parser.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class ParserService:
    """Сервис парсинга контента"""
    
    def __init__(self):
        self.is_running = False
        self.parser = UniversalParser()
        self.extractor = ContentExtractor()
        self.anti_bot = AntiBotManager()
        self.proxy_manager = ProxyManager()
        
        # Статистика
        self.stats = {
            'pages_parsed': 0,
            'content_extracted': 0,
            'errors_encountered': 0,
            'parsing_time_avg': 0.0,
            'success_rate': 100.0
        }
        
        # Очереди
        self.parsing_queue: List[Dict[str, Any]] = []
        self.results_queue: List[Dict[str, Any]] = []
        
        # Флаги управления
        self._shutdown_event = asyncio.Event()
        
        logger.info("Parser Service инициализирован")
    
    async def start(self):
        """Запуск сервиса парсинга"""
        try:
            logger.info("Запуск Parser Service...")
            
            # Инициализация компонентов
            await self.parser.initialize()
            await self.proxy_manager.initialize()
            await self.anti_bot.initialize()
            
            # Обновление статуса
            self.is_running = True
            
            # Запуск рабочих циклов
            asyncio.create_task(self._parsing_loop())
            asyncio.create_task(self._monitoring_loop())
            asyncio.create_task(self._cleanup_loop())
            
            logger.info("Parser Service успешно запущен")
            
            # Ожидание завершения
            await self._shutdown_event.wait()
            
        except Exception as e:
            logger.error(f"Ошибка при запуске Parser Service: {e}")
            raise
    
    async def stop(self):
        """Остановка сервиса парсинга"""
        logger.info("Остановка Parser Service...")
        self.is_running = False
        self._shutdown_event.set()
        
        # Очистка ресурсов
        await self.parser.cleanup()
        await self.proxy_manager.cleanup()
        
        logger.info("Parser Service остановлен")
    
    async def add_parsing_task(self, task: Dict[str, Any]) -> str:
        """Добавление задачи парсинга"""
        task_id = task.get('id', f"task_{len(self.parsing_queue)}")
        task['id'] = task_id
        task['status'] = 'pending'
        task['created_at'] = asyncio.get_event_loop().time()
        
        self.parsing_queue.append(task)
        logger.info(f"Добавлена задача парсинга: {task_id}")
        
        return task_id
    
    async def get_parsing_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Получение статуса задачи парсинга"""
        # Поиск в очереди на парсинг
        for task in self.parsing_queue:
            if task['id'] == task_id:
                return {
                    'id': task_id,
                    'status': task['status'],
                    'url': task.get('url'),
                    'created_at': task.get('created_at')
                }
        
        # Поиск в очереди результатов
        for result in self.results_queue:
            if result.get('task_id') == task_id:
                return {
                    'id': task_id,
                    'status': 'completed',
                    'url': result.get('url'),
                    'completed_at': result.get('completed_at'),
                    'content_preview': result.get('content', {}).get('title', '')[:100]
                }
        
        return None
    
    async def get_service_status(self) -> Dict[str, Any]:
        """Получение статуса сервиса"""
        return {
            'is_running': self.is_running,
            'queue_size': len(self.parsing_queue),
            'results_queue_size': len(self.results_queue),
            'stats': self.stats,
            'proxy_status': await self.proxy_manager.get_status(),
            'anti_bot_status': await self.anti_bot.get_status()
        }
    
    async def _parsing_loop(self):
        """Основной цикл парсинга"""
        while self.is_running:
            try:
                if self.parsing_queue:
                    # Получение задачи из очереди
                    task = self.parsing_queue.pop(0)
                    task['status'] = 'processing'
                    
                    # Выполнение парсинга
                    result = await self._parse_content(task)
                    
                    # Добавление результата в очередь
                    self.results_queue.append(result)
                    
                    # Обновление статистики
                    self._update_stats(result)
                    
                    logger.info(f"Завершена задача парсинга: {task['id']}")
                
                await asyncio.sleep(1)  # Пауза для предотвращения CPU overload
                
            except Exception as e:
                logger.error(f"Ошибка в цикле парсинга: {e}")
                await asyncio.sleep(5)
    
    async def _parse_content(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Парсинг контента по задаче"""
        url = task.get('url')
        source_type = task.get('source_type', 'auto')
        selectors = task.get('selectors', {})
        
        try:
            logger.info(f"Начало парсинга: {url}")
            
            # Определение типа источника
            if source_type == 'auto':
                source_type = await self.parser.detect_source_type(url)
            
            # Получение прокси
            proxy = await self.proxy_manager.get_proxy()
            
            # Настройка anti-bot мер
            headers = await self.anti_bot.get_headers()
            
            # Парсинг страницы
            parsed_data = await self.parser.parse(
                url=url,
                source_type=source_type,
                proxy=proxy,
                headers=headers,
                selectors=selectors
            )
            
            # Извлечение контента
            extracted_content = await self.extractor.extract(
                parsed_data,
                task.get('extraction_rules', {})
            )
            
            result = {
                'task_id': task['id'],
                'url': url,
                'source_type': source_type,
                'status': 'success',
                'content': extracted_content,
                'parsing_time': asyncio.get_event_loop().time() - task['created_at'],
                'completed_at': asyncio.get_event_loop().time(),
                'metadata': parsed_data.get('metadata', {})
            }
            
            logger.info(f"Успешно спарсен контент: {url}")
            
        except Exception as e:
            logger.error(f"Ошибка при парсинге {url}: {e}")
            
            result = {
                'task_id': task['id'],
                'url': url,
                'source_type': source_type,
                'status': 'failed',
                'error': str(e),
                'completed_at': asyncio.get_event_loop().time()
            }
        
        return result
    
    async def _monitoring_loop(self):
        """Цикл мониторинга сервиса"""
        while self.is_running:
            try:
                # Обновление статистики каждые 60 секунд
                await asyncio.sleep(60)
                
                # Очистка старых результатов (старше 1 часа)
                current_time = asyncio.get_event_loop().time()
                self.results_queue = [
                    result for result in self.results_queue
                    if current_time - result.get('completed_at', 0) < 3600
                ]
                
                # Логирование статистики
                logger.info(f"Parser Service Stats: {self.stats}")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле мониторинга: {e}")
    
    async def _cleanup_loop(self):
        """Цикл очистки ресурсов"""
        while self.is_running:
            try:
                # Очистка каждые 5 минут
                await asyncio.sleep(300)
                
                # Очистка кэша парсера
                await self.parser.cleanup_cache()
                
                # Проверка и обновление прокси
                await self.proxy_manager.validate_proxies()
                
                logger.info("Ресурсы сервиса парсинга очищены")
                
            except Exception as e:
                logger.error(f"Ошибка в цикле очистки: {e}")
    
    def _update_stats(self, result: Dict[str, Any]):
        """Обновление статистики"""
        if result['status'] == 'success':
            self.stats['pages_parsed'] += 1
            self.stats['content_extracted'] += 1
            
            # Обновление среднего времени парсинга
            parsing_time = result.get('parsing_time', 0)
            total_parsed = self.stats['pages_parsed']
            self.stats['parsing_time_avg'] = (
                (self.stats['parsing_time_avg'] * (total_parsed - 1) + parsing_time) / total_parsed
            )
        else:
            self.stats['errors_encountered'] += 1
        
        # Обновление процента успешности
        total_attempts = self.stats['pages_parsed'] + self.stats['errors_encountered']
        if total_attempts > 0:
            self.stats['success_rate'] = (self.stats['pages_parsed'] / total_attempts) * 100

# Обработка сигналов
def signal_handler(signum, frame):
    """Обработчик системных сигналов"""
    logger.info(f"Получен сигнал {signum}")
    
    if signum == signal.SIGTERM:
        asyncio.create_task(parser_service.stop())
    elif signum == signal.SIGINT:
        asyncio.create_task(parser_service.stop())

# Глобальный экземпляр
parser_service = ParserService()

async def main():
    """Главная функция"""
    # Установка обработчиков сигналов
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    
    try:
        await parser_service.start()
    except KeyboardInterrupt:
        logger.info("Получено прерывание от пользователя")
        await parser_service.stop()
    except Exception as e:
        logger.error(f"Критическая ошибка: {e}")
        await parser_service.stop()

if __name__ == "__main__":
    asyncio.run(main())