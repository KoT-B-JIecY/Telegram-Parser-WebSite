import asyncio
import logging
import sqlite3
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import joblib
import json
import hashlib

@dataclass
class PredictionResult:
    predicted_engagement: float
    predicted_reach: int
    confidence_score: float
    feature_importance: Dict[str, float]
    recommendations: List[str]

class MLPredictor:
    def __init__(self, db_path: str = "optimization.db", model_path: str = "models/"):
        self.db_path = db_path
        self.model_path = model_path
        self.setup_directories()
        self.logger = logging.getLogger(__name__)
        
        # Model instances
        self.engagement_model = None
        self.reach_model = None
        self.scaler = StandardScaler()
        
        # Feature definitions
        self.feature_columns = [
            'content_length', 'has_hashtags', 'has_mentions', 'has_media',
            'posting_hour', 'day_of_week', 'channel_size', 'recent_activity',
            'content_sentiment', 'has_call_to_action', 'is_question',
            'trending_topics_count'
        ]
        
        self.models_trained = False
        
    def setup_directories(self):
        """Create necessary directories"""
        import os
        os.makedirs(self.model_path, exist_ok=True)
    
    async def extract_features(self, content: str, metadata: Dict) -> np.ndarray:
        """Extract features from content and metadata for prediction"""
        features = {}
        
        # Content features
        features['content_length'] = len(content)
        features['has_hashtags'] = 1 if '#' in content else 0
        features['has_mentions'] = 1 if '@' in content else 0
        features['has_media'] = 1 if metadata.get('has_media', False) else 0
        features['has_call_to_action'] = 1 if any(cta in content.lower() for cta in ['подпишись', 'лайк', 'коммент', 'поделись']) else 0
        features['is_question'] = 1 if '?' in content else 0
        
        # Temporal features
        posting_time = metadata.get('posting_time', datetime.now())
        features['posting_hour'] = posting_time.hour
        features['day_of_week'] = posting_time.weekday()
        
        # Channel features
        features['channel_size'] = metadata.get('channel_size', 1000)
        features['recent_activity'] = metadata.get('recent_activity', 0.5)
        
        # Content analysis features
        features['content_sentiment'] = await self._analyze_sentiment(content)
        features['trending_topics_count'] = await self._count_trending_topics(content)
        
        # Convert to numpy array in correct order
        feature_array = np.array([features[col] for col in self.feature_columns])
        
        return feature_array.reshape(1, -1)
    
    async def _analyze_sentiment(self, content: str) -> float:
        """Analyze sentiment of content (simplified)"""
        positive_words = ['отлично', 'замечательно', 'прекрасно', 'лучшее', 'супер', 'круто', 'восхитительно']
        negative_words = ['плохо', 'ужас', 'отвратительно', 'скучно', 'неинтересно', 'разочарование']
        
        content_lower = content.lower()
        positive_count = sum(1 for word in positive_words if word in content_lower)
        negative_count = sum(1 for word in negative_words if word in content_lower)
        
        # Normalize to [-1, 1] range
        sentiment = (positive_count - negative_count) / max(len(content.split()), 1)
        return max(-1, min(1, sentiment))
    
    async def _count_trending_topics(self, content: str) -> int:
        """Count trending topics in content (simplified)"""
        # This would typically use a trending topics API
        # For now, count hashtags as trending topics
        return content.count('#')
    
    async def train_models(self, force_retrain: bool = False) -> bool:
        """Train ML models on historical data"""
        try:
            # Load training data
            training_data = await self._load_training_data()
            
            if len(training_data) < 50:  # Need minimum data for training
                self.logger.warning("Insufficient data for training models")
                return False
            
            # Prepare features and targets
            X = np.array([row[:-2] for row in training_data])  # All columns except last 2
            y_engagement = np.array([row[-2] for row in training_data])  # Second to last
            y_reach = np.array([row[-1] for row in training_data])  # Last column
            
            # Split data
            X_train, X_test, y_eng_train, y_eng_test, y_reach_train, y_reach_test = train_test_split(
                X, y_engagement, y_reach, test_size=0.2, random_state=42
            )
            
            # Scale features
            X_train_scaled = self.scaler.fit_transform(X_train)
            X_test_scaled = self.scaler.transform(X_test)
            
            # Train engagement model
            self.engagement_model = GradientBoostingRegressor(
                n_estimators=100, random_state=42, learning_rate=0.1
            )
            self.engagement_model.fit(X_train_scaled, y_eng_train)
            
            # Train reach model
            self.reach_model = RandomForestRegressor(
                n_estimators=100, random_state=42
            )
            self.reach_model.fit(X_train_scaled, y_reach_train)
            
            # Evaluate models
            eng_pred = self.engagement_model.predict(X_test_scaled)
            reach_pred = self.reach_model.predict(X_test_scaled)
            
            engagement_r2 = r2_score(y_eng_test, eng_pred)
            reach_r2 = r2_score(y_reach_test, reach_pred)
            
            self.logger.info(f"Model training completed. Engagement R²: {engagement_r2:.3f}, Reach R²: {reach_r2:.3f}")
            
            # Save models
            await self._save_models()
            
            self.models_trained = True
            return True
            
        except Exception as e:
            self.logger.error(f"Error training models: {e}")
            return False
    
    async def _load_training_data(self) -> List[List]:
        """Load training data from database"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get historical performance data with features
        cursor.execute('''
            SELECT 
                content_length, has_hashtags, has_mentions, has_media,
                posting_hour, day_of_week, channel_size, recent_activity,
                content_sentiment, has_call_to_action, is_question,
                trending_topics_count, engagement_rate, reach
            FROM ml_training_data 
            WHERE created_at >= datetime('now', '-30 days')
            ORDER BY created_at DESC
            LIMIT 1000
        ''')
        
        data = cursor.fetchall()
        conn.close()
        
        # If no training data exists, generate synthetic data for demonstration
        if not data:
            data = await self._generate_synthetic_training_data()
        
        return data
    
    async def _generate_synthetic_training_data(self) -> List[List]:
        """Generate synthetic training data for demonstration"""
        np.random.seed(42)
        synthetic_data = []
        
        for _ in range(200):
            # Generate random features
            features = [
                np.random.randint(50, 500),  # content_length
                np.random.randint(0, 2),     # has_hashtags
                np.random.randint(0, 2),     # has_mentions
                np.random.randint(0, 2),     # has_media
                np.random.randint(0, 24),    # posting_hour
                np.random.randint(0, 7),     # day_of_week
                np.random.randint(100, 50000),  # channel_size
                np.random.uniform(0.1, 1.0),    # recent_activity
                np.random.uniform(-1, 1),       # content_sentiment
                np.random.randint(0, 2),        # has_call_to_action
                np.random.randint(0, 2),        # is_question
                np.random.randint(0, 5),        # trending_topics_count
            ]
            
            # Generate targets with some correlation to features
            engagement = (
                features[0] * 0.0001 +  # content_length has small positive effect
                features[3] * 0.1 +     # media has positive effect
                features[8] * 0.05 +    # sentiment has effect
                features[9] * 0.15 +    # CTA has positive effect
                np.random.uniform(-0.1, 0.1)  # random noise
            )
            
            reach = (
                features[6] * 0.5 +     # channel size affects reach
                features[3] * 1000 +    # media boosts reach
                features[10] * 500 +    # questions boost reach
                np.random.uniform(-500, 500)  # random noise
            )
            
            features.extend([
                max(0, min(1, engagement)),  # engagement_rate (0-1)
                max(0, int(reach))           # reach (positive integer)
            ])
            
            synthetic_data.append(features)
        
        return synthetic_data
    
    async def _save_models(self):
        """Save trained models to disk"""
        try:
            joblib.dump(self.engagement_model, f"{self.model_path}engagement_model.pkl")
            joblib.dump(self.reach_model, f"{self.model_path}reach_model.pkl")
            joblib.dump(self.scaler, f"{self.model_path}feature_scaler.pkl")
            
            self.logger.info("Models saved successfully")
        except Exception as e:
            self.logger.error(f"Error saving models: {e}")
    
    async def load_models(self) -> bool:
        """Load trained models from disk"""
        try:
            self.engagement_model = joblib.load(f"{self.model_path}engagement_model.pkl")
            self.reach_model = joblib.load(f"{self.model_path}reach_model.pkl")
            self.scaler = joblib.load(f"{self.model_path}feature_scaler.pkl")
            
            self.models_trained = True
            self.logger.info("Models loaded successfully")
            return True
            
        except Exception as e:
            self.logger.warning(f"Could not load models: {e}")
            return await self.train_models()
    
    async def predict_performance(self, content: str, metadata: Dict) -> PredictionResult:
        """Predict content performance using trained models"""
        if not self.models_trained:
            await self.load_models()
        
        if not self.models_trained:
            # Return fallback prediction if models not available
            return PredictionResult(
                predicted_engagement=0.05,
                predicted_reach=1000,
                confidence_score=0.3,
                feature_importance={},
                recommendations=["Недостаточно данных для точного предсказания"]
            )
        
        try:
            # Extract features
            features = await self.extract_features(content, metadata)
            features_scaled = self.scaler.transform(features)
            
            # Make predictions
            engagement_pred = self.engagement_model.predict(features_scaled)[0]
            reach_pred = self.reach_model.predict(features_scaled)[0]
            
            # Calculate confidence score based on prediction uncertainty
            confidence = await self._calculate_confidence(features_scaled)
            
            # Get feature importance
            feature_importance = await self._get_feature_importance()
            
            # Generate recommendations
            recommendations = await self._generate_recommendations(
                content, metadata, engagement_pred, reach_pred
            )
            
            return PredictionResult(
                predicted_engagement=max(0, min(1, engagement_pred)),
                predicted_reach=max(0, int(reach_pred)),
                confidence_score=confidence,
                feature_importance=feature_importance,
                recommendations=recommendations
            )
            
        except Exception as e:
            self.logger.error(f"Error making prediction: {e}")
            return PredictionResult(
                predicted_engagement=0.05,
                predicted_reach=1000,
                confidence_score=0.1,
                feature_importance={},
                recommendations=["Ошибка при предсказании производительности"]
            )
    
    async def _calculate_confidence(self, features_scaled: np.ndarray) -> float:
        """Calculate prediction confidence based on feature similarity to training data"""
        # This is a simplified confidence calculation
        # In practice, you might use model uncertainty estimation techniques
        
        # For now, return a baseline confidence
        return 0.7
    
    async def _get_feature_importance(self) -> Dict[str, float]:
        """Get feature importance from models"""
        if not self.models_trained:
            return {}
        
        importance = {}
        
        # Get importance from engagement model
        if hasattr(self.engagement_model, 'feature_importances_'):
            for i, col in enumerate(self.feature_columns):
                importance[col] = self.engagement_model.feature_importances_[i]
        
        return importance
    
    async def _generate_recommendations(self, content: str, metadata: Dict, 
                                      predicted_engagement: float, 
                                      predicted_reach: int) -> List[str]:
        """Generate content optimization recommendations"""
        recommendations = []
        
        if predicted_engagement < 0.05:
            recommendations.append("Низкая ожидаемая вовлеченность. Добавьте интерактивные элементы.")
        
        if predicted_reach < 500:
            recommendations.append("Низкий ожидаемый охват. Используйте трендовые хэштеги.")
        
        if len(content) < 100:
            recommendations.append("Контент слишком короткий. Добавьте больше деталей.")
        
        if '#' not in content:
            recommendations.append("Добавьте релевантные хэштеги для увеличения охвата.")
        
        if '?' not in content.lower():
            recommendations.append("Добавьте вопросы для повышения вовлеченности.")
        
        if any(cta in content.lower() for cta in ['подпишись', 'лайк', 'коммент']):
            recommendations.append("Хорошо! Призыв к действию увеличивает вовлеченность.")
        
        return recommendations
    
    async def predict_trending_topics(self, timeframe: str = "24h") -> List[str]:
        """Predict trending topics for content creation"""
        # This would typically use external APIs or analyze social media trends
        # For now, return some example trending topics
        
        trending_topics = [
            "#технологии", "#искусственныйинтеллект", "#машинноеобучение",
            "#цифроваятрансформация", "#инновации", "#будущее",
            "#автоматизация", "#данные", "#аналитика"
        ]
        
        return trending_topics[:5]  # Return top 5
    
    async def predict_optimal_content_type(self, channel_id: str, 
                                         audience_segment: str = None) -> Dict:
        """Predict optimal content type for specific channel and audience"""
        # Analyze historical performance by content type
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT 
                content_type,
                AVG(engagement_rate) as avg_engagement,
                AVG(reach) as avg_reach,
                COUNT(*) as post_count
            FROM content_performance 
            WHERE channel_id = ? 
            AND created_at >= datetime('now', '-30 days')
            GROUP BY content_type
            ORDER BY avg_engagement DESC
        ''', (channel_id,))
        
        results = cursor.fetchall()
        conn.close()
        
        if results:
            best_content_type = results[0][0]
            avg_engagement = results[0][1]
            avg_reach = results[0][2]
        else:
            best_content_type = "text_with_media"
            avg_engagement = 0.05
            avg_reach = 1000
        
        return {
            'optimal_content_type': best_content_type,
            'expected_engagement': round(avg_engagement, 4),
            'expected_reach': int(avg_reach),
            'confidence': min(len(results) / 10, 1.0) if results else 0.3
        }

# Global predictor instance
predictor = MLPredictor()

async def main():
    """Test the predictor"""
    # Train models
    training_success = await predictor.train_models()
    print(f"Model training success: {training_success}")
    
    # Test prediction
    test_content = "Привет! Это тестовый пост про технологии будущего. Как вы думаете, что нас ждет? #технологии #будущее"
    test_metadata = {
        'has_media': True,
        'posting_time': datetime.now(),
        'channel_size': 5000,
        'recent_activity': 0.7
    }
    
    prediction = await predictor.predict_performance(test_content, test_metadata)
    print(f"Prediction result: {prediction}")
    
    # Test trending topics
    trending = await predictor.predict_trending_topics()
    print(f"Trending topics: {trending}")

if __name__ == "__main__":
    asyncio.run(main())